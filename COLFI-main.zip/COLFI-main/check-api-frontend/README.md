# 🚀 Contract Management API Frontend Tester

A beautiful, modern web interface for testing your Contract Management API endpoints. This frontend provides a Swagger-like experience with an intuitive UI for testing all CRUD operations.

## ✨ Features

- **🎨 Beautiful UI** - Modern, responsive design with gradient backgrounds
- **📱 Mobile Friendly** - Works perfectly on desktop and mobile devices
- **🔄 Real-time Testing** - Test all API endpoints with live results
- **📊 Visual Results** - Color-coded success/error responses
- **⚡ Quick Actions** - Load sample data and clear forms instantly
- **🛡️ Input Validation** - Built-in form validation and error handling

## 🚀 Quick Start

### 1. Start the Frontend Server
```bash
cd /root/frontend
npm start
```

### 2. Open in Browser
Navigate to: **http://localhost:3001**

### 3. Start Testing!
The frontend will automatically check if your API is running and show the status.

## 📋 Available Endpoints

### ✅ **GET Endpoints**
- **Health Check** - `/health` - Check API status
- **Get All Contracts** - `/api/contracts` - Retrieve all contracts
- **Get Contract by ID** - `/api/contracts/:id` - Get specific contract
- **Get Contracts by Email** - `/api/contracts/email/:email` - Filter by email

### ✅ **POST Endpoints**
- **Create Contract** - `/api/contracts` - Create new contract

### ✅ **PUT Endpoints**
- **Update Contract** - `/api/contracts/:id` - Update existing contract

### ✅ **DELETE Endpoints**
- **Delete Contract** - `/api/contracts/:id` - Remove contract

## 🎯 How to Use

### 1. **Test Health Check**
- Click on the Health Check section
- Click "Test Health" button
- See if your API is running

### 2. **Get All Contracts**
- Expand the "Get All Contracts" section
- Click "Get All Contracts" button
- View all contracts in the blockchain

### 3. **Create New Contract**
- Expand the "Create Contract" section
- Click "Load Sample" to fill with sample data
- Modify fields as needed
- Click "Create Contract" button

### 4. **Update Contract**
- Expand the "Update Contract" section
- Enter the contract ID to update
- Enter new values for fields you want to change
- Click "Update Contract" button

### 5. **Delete Contract**
- Expand the "Delete Contract" section
- Enter the contract ID to delete
- Click "Delete Contract" button
- Confirm the deletion

## 🎨 UI Features

- **📱 Responsive Design** - Works on all screen sizes
- **🎨 Modern Styling** - Beautiful gradients and animations
- **⚡ Loading States** - Visual feedback during API calls
- **✅ Success/Error Indicators** - Clear visual feedback
- **🔄 Collapsible Sections** - Organized interface
- **📝 Form Validation** - Built-in input validation

## 🔧 Technical Details

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Server**: Express.js
- **Styling**: Modern CSS with gradients and animations
- **Icons**: Font Awesome
- **API Communication**: Fetch API

## 🌐 Access URLs

- **Frontend**: http://localhost:3001
- **API Backend**: http://localhost:3000
- **API Health**: http://localhost:3000/health

## 📸 Screenshots

The interface includes:
- Beautiful gradient header with API status
- Collapsible endpoint sections
- Color-coded HTTP method badges
- Input forms with validation
- Real-time result display
- Loading animations
- Success/error indicators

## 🎉 Enjoy Testing!

This frontend makes it super easy to test your Contract Management API. No more command line testing - everything is visual and intuitive!

**Happy Testing! 🚀**










