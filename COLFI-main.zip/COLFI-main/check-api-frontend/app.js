// Contract Management API Tester
const API_BASE = 'https://backend.colfi.io';

// Sample contract data
const sampleContract = {
    legalName: "TechCorp Solutions",
    address: "456 Innovation Drive, Tech City, TC 54321",
    phone: "+1-555-987-6543",
    email: "contracts@techcorp.com",
    assetType: "Cloud Infrastructure Services",
    termsAndConditionsOfTransaction: "Annual cloud hosting and maintenance services",
    transactionAmount: 75000.00,
    quantity: "Quarterly payments",
    obligationDetails: "Provide cloud infrastructure and 24/7 support",
    deliveryTimelines: "12 months service agreement",
    precedentCondition: "Client infrastructure assessment completed",
    terminationCondition: "Either party may terminate with 60 days notice",
    terminationEventDefault: "Non-payment or service level breach",
    terminationNotice: "60 days written notice required",
    lawGoverning: "State of Texas",
    jurisdictionForDispute: "Austin County, Texas",
    specificRepresentation: "Both parties have authority to enter this agreement",
    representationDisclaimer: "No other representations made beyond this contract",
    collateralDetails: "Cloud infrastructure and data",
    collateralConditions: "Client retains ownership of their data",
    signingAuthority: "Jane Smith, CTO",
    requiredSupportingDocuments: "Business License, Technical Specifications",
    conditionsOfRatings: "Monthly performance reviews",
    thirdPartyInvolvementDetails: "AWS as cloud provider",
    miscellaneousClauses: "Data protection and privacy compliance required",
    methodOfExecution: "Electronic signature via Adobe Sign",
    effectiveDateOfContract: "2024-03-01",
    maturityDate: "2024-03-15",
    contractOwner: "Jane Smith"
};

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    checkApiStatus();
    loadSampleContract();
});

// Check API status on load
async function checkApiStatus() {
    try {
        const response = await fetch(`${API_BASE}/health`);
        const statusElement = document.getElementById('apiStatus');
        
        if (response.ok) {
            statusElement.innerHTML = '<i class="fas fa-circle"></i> API Connected';
            statusElement.className = 'api-status';
        } else {
            throw new Error('API not responding');
        }
    } catch (error) {
        const statusElement = document.getElementById('apiStatus');
        statusElement.innerHTML = '<i class="fas fa-circle"></i> API Disconnected';
        statusElement.className = 'api-status error';
    }
}

// Toggle endpoint sections
function toggleEndpoint(endpoint) {
    const content = document.getElementById(`${endpoint}-content`);
    const icon = content.previousElementSibling.querySelector('i');
    
    if (content.classList.contains('active')) {
        content.classList.remove('active');
        icon.classList.remove('fa-chevron-up');
        icon.classList.add('fa-chevron-down');
    } else {
        content.classList.add('active');
        icon.classList.remove('fa-chevron-down');
        icon.classList.add('fa-chevron-up');
    }
}


// Show loading state
function showLoading(endpoint) {
    const resultSection = document.getElementById(`${endpoint}-result`);
    resultSection.innerHTML = `
        <div class="loading show">
            <div class="spinner"></div>
            <p>Processing request...</p>
        </div>
    `;
    resultSection.classList.add('show');
}

// Show result
function showResult(endpoint, data, isError = false) {
    const resultSection = document.getElementById(`${endpoint}-result`);
    
    if (isError) {
        resultSection.innerHTML = `
            <div class="result-section show result-error">
                <div class="result-header">
                    <i class="fas fa-exclamation-triangle"></i>
                    Error Response
                </div>
                <div class="result-content">${JSON.stringify(data, null, 2)}</div>
            </div>
        `;
    } else {
        resultSection.innerHTML = `
            <div class="result-section show result-success">
                <div class="result-header">
                    <i class="fas fa-check-circle"></i>
                    Success Response
                </div>
                <div class="result-content">${JSON.stringify(data, null, 2)}</div>
            </div>
        `;
    }
}

// Test Health Check
async function testHealth() {
    showLoading('health');
    
    try {
        const response = await fetch(`${API_BASE}/health`);
        const data = await response.json();
        
        if (response.ok) {
            showResult('health', data);
        } else {
            showResult('health', data, true);
        }
    } catch (error) {
        showResult('health', { error: error.message }, true);
    }
}

// Test Get All Contracts
async function testGetAll() {
    showLoading('getAll');
    
    try {
        const response = await fetch(`${API_BASE}/api/contracts`);
        const data = await response.json();
        
        if (response.ok) {
            showResult('getAll', data);
        } else {
            showResult('getAll', data, true);
        }
    } catch (error) {
        showResult('getAll', { error: error.message }, true);
    }
}

// Test Get Contract by ID
async function testGetById() {
    const contractId = document.getElementById('contractId').value;
    
    if (!contractId) {
        showResult('getById', { error: 'Please enter a contract ID' }, true);
        return;
    }
    
    showLoading('getById');
    
    try {
        const response = await fetch(`${API_BASE}/api/contracts/${contractId}`);
        const data = await response.json();
        
        if (response.ok) {
            showResult('getById', data);
        } else {
            showResult('getById', data, true);
        }
    } catch (error) {
        showResult('getById', { error: error.message }, true);
    }
}


// Load sample contract data
function loadSampleContract() {
    const jsonInput = document.getElementById('contractJsonInput');
    jsonInput.value = JSON.stringify(sampleContract, null, 2);
}

// Clear contract form
function clearContractForm() {
    const jsonInput = document.getElementById('contractJsonInput');
    jsonInput.value = '';
}

// Test Create Contract
async function testCreate() {
    const jsonInput = document.getElementById('contractJsonInput');
    const jsonText = jsonInput.value.trim();
    
    if (!jsonText) {
        showResult('create', { error: 'Please enter JSON data' }, true);
        return;
    }
    
    let contractData;
    try {
        contractData = JSON.parse(jsonText);
    } catch (error) {
        showResult('create', { error: 'Invalid JSON format: ' + error.message }, true);
        return;
    }
    
    showLoading('create');
    
    try {
        const response = await fetch(`${API_BASE}/api/contracts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(contractData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('create', data);
        } else {
            showResult('create', data, true);
        }
    } catch (error) {
        showResult('create', { error: error.message }, true);
    }
}

// Load sample contract data for update
function loadSampleContractForUpdate() {
    const jsonInput = document.getElementById('updateJsonInput');
    jsonInput.value = JSON.stringify(sampleContract, null, 2);
}

// Clear update form
function clearUpdateForm() {
    const jsonInput = document.getElementById('updateJsonInput');
    jsonInput.value = '';
}

// Test Update Contract
async function testUpdate() {
    const contractId = document.getElementById('updateContractId').value;
    const jsonInput = document.getElementById('updateJsonInput');
    const jsonText = jsonInput.value.trim();
    
    if (!contractId) {
        showResult('update', { error: 'Please enter a contract ID' }, true);
        return;
    }
    
    if (!jsonText) {
        showResult('update', { error: 'Please enter JSON data' }, true);
        return;
    }
    
    let updateData;
    try {
        updateData = JSON.parse(jsonText);
    } catch (error) {
        showResult('update', { error: 'Invalid JSON format: ' + error.message }, true);
        return;
    }
    
    showLoading('update');
    
    try {
        const response = await fetch(`${API_BASE}/api/contracts/${contractId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updateData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('update', data);
        } else {
            showResult('update', data, true);
        }
    } catch (error) {
        showResult('update', { error: error.message }, true);
    }
}

// Test Delete Contract
async function testDelete() {
    const contractId = document.getElementById('deleteContractId').value;
    
    if (!contractId) {
        showResult('delete', { error: 'Please enter a contract ID' }, true);
        return;
    }
    
    if (!confirm(`Are you sure you want to delete contract "${contractId}"?`)) {
        return;
    }
    
    showLoading('delete');
    
    try {
        const response = await fetch(`${API_BASE}/api/contracts/${contractId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('delete', data);
        } else {
            showResult('delete', data, true);
        }
    } catch (error) {
        showResult('delete', { error: error.message }, true);
    }
}

// Utility function to format JSON nicely
function formatJSON(obj) {
    return JSON.stringify(obj, null, 2);
}

// Test Login
async function testLogin() {
    const userId = document.getElementById('loginId').value;
    const userName = document.getElementById('loginName').value;
    
    if (!userId || !userName) {
        showResult('login', { error: 'Please enter both User ID and User Name' }, true);
        return;
    }
    
    showLoading('login');
    
    try {
        const response = await fetch(`${API_BASE}/api/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: userId, name: userName })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('login', data);
        } else {
            showResult('login', data, true);
        }
    } catch (error) {
        showResult('login', { error: error.message }, true);
    }
}

// Test Get All Users
async function testGetUsers() {
    showLoading('getUsers');
    
    try {
        const response = await fetch(`${API_BASE}/api/users`);
        const data = await response.json();
        
        if (response.ok) {
            showResult('getUsers', data);
        } else {
            showResult('getUsers', data, true);
        }
    } catch (error) {
        showResult('getUsers', { error: error.message }, true);
    }
}

// Test Create User
async function testCreateUser() {
    const userId = document.getElementById('createUserId').value;
    const userName = document.getElementById('createUserName').value;
    
    if (!userId || !userName) {
        showResult('createUser', { error: 'Please enter both User ID and User Name' }, true);
        return;
    }
    
    showLoading('createUser');
    
    try {
        const response = await fetch(`${API_BASE}/api/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: userId, name: userName })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('createUser', data);
        } else {
            showResult('createUser', data, true);
        }
    } catch (error) {
        showResult('createUser', { error: error.message }, true);
    }
}

// Test Delete User
async function testDeleteUser() {
    const userId = document.getElementById('deleteUserId').value;
    
    if (!userId) {
        showResult('deleteUser', { error: 'Please enter a User ID' }, true);
        return;
    }
    
    if (!confirm(`Are you sure you want to delete user "${userId}"?`)) {
        return;
    }
    
    showLoading('deleteUser');
    
    try {
        const response = await fetch(`${API_BASE}/api/users/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('deleteUser', data);
        } else {
            showResult('deleteUser', data, true);
        }
    } catch (error) {
        showResult('deleteUser', { error: error.message }, true);
    }
}

// Test Get All Assets
async function testGetAssets() {
    showLoading('getAssets');
    
    try {
        const response = await fetch(`${API_BASE}/api/assets`);
        const data = await response.json();
        
        if (response.ok) {
            showResult('getAssets', data);
        } else {
            showResult('getAssets', data, true);
        }
    } catch (error) {
        showResult('getAssets', { error: error.message }, true);
    }
}

// Test Create Asset
async function testCreateAsset() {
    const assetId = document.getElementById('createAssetId').value;
    const assetType = document.getElementById('createAssetType').value;
    const assetName = document.getElementById('createAssetName').value;
    const assetValue = document.getElementById('createAssetValue').value;
    const assetCurrency = document.getElementById('createAssetCurrency').value;
    
    if (!assetId || !assetType || !assetName || !assetCurrency) {
        showResult('createAsset', { error: 'Please fill in all required fields (ID, Type, Name, Currency)' }, true);
        return;
    }
    
    showLoading('createAsset');
    
    try {
        const assetData = {
            id: assetId,
            type: assetType,
            name: assetName,
            currency: assetCurrency
        };
        
        // Only include value if it's provided and not empty
        if (assetValue && assetValue.trim() !== '') {
            assetData.value = assetValue;
        }
        
        const response = await fetch(`${API_BASE}/api/assets`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(assetData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('createAsset', data);
        } else {
            showResult('createAsset', data, true);
        }
    } catch (error) {
        showResult('createAsset', { error: error.message }, true);
    }
}

// Test Update Asset
async function testUpdateAsset() {
    const assetId = document.getElementById('updateAssetId').value;
    const assetType = document.getElementById('updateAssetType').value;
    const assetName = document.getElementById('updateAssetName').value;
    const assetValue = document.getElementById('updateAssetValue').value;
    const assetCurrency = document.getElementById('updateAssetCurrency').value;
    
    if (!assetId) {
        showResult('updateAsset', { error: 'Please enter an Asset ID to update' }, true);
        return;
    }
    
    showLoading('updateAsset');
    
    try {
        const updateData = {};
        
        // Only include fields that have values
        if (assetType && assetType.trim() !== '') {
            updateData.type = assetType;
        }
        if (assetName && assetName.trim() !== '') {
            updateData.name = assetName;
        }
        if (assetValue && assetValue.trim() !== '') {
            updateData.value = assetValue;
        }
        if (assetCurrency && assetCurrency.trim() !== '') {
            updateData.currency = assetCurrency;
        }
        
        const response = await fetch(`${API_BASE}/api/assets/${assetId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updateData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('updateAsset', data);
        } else {
            showResult('updateAsset', data, true);
        }
    } catch (error) {
        showResult('updateAsset', { error: error.message }, true);
    }
}

// Test Delete Asset
async function testDeleteAsset() {
    const assetId = document.getElementById('deleteAssetId').value;
    
    if (!assetId) {
        showResult('deleteAsset', { error: 'Please enter an Asset ID' }, true);
        return;
    }
    
    if (!confirm(`Are you sure you want to delete asset "${assetId}"?`)) {
        return;
    }
    
    showLoading('deleteAsset');
    
    try {
        const response = await fetch(`${API_BASE}/api/assets/${assetId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showResult('deleteAsset', data);
        } else {
            showResult('deleteAsset', data, true);
        }
    } catch (error) {
        showResult('deleteAsset', { error: error.message }, true);
    }
}
