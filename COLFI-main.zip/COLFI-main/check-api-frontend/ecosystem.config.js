module.exports = {
  apps: [{
    name: 'contract-management-frontend',
    script: 'server.js',
    cwd: '/root/frontend',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    },
    error_file: '/root/frontend/logs/err.log',
    out_file: '/root/frontend/logs/out.log',
    log_file: '/root/frontend/logs/combined.log',
    time: true,
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z'
  }]
};










