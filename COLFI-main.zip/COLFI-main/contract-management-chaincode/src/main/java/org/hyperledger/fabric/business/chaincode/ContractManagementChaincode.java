package org.hyperledger.fabric.business.chaincode;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.hibernate.validator.messageinterpolation.ParameterMessageInterpolator;
import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.contract.ContractInterface;
import org.hyperledger.fabric.contract.annotation.*;
import org.hyperledger.fabric.shim.ChaincodeException;
import org.hyperledger.fabric.shim.ChaincodeStub;
import org.hyperledger.fabric.shim.ledger.KeyValue;
import org.hyperledger.fabric.shim.ledger.QueryResultsIterator;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Contract(name = "ContractManagementChaincode", info = @Info(title = "Contract Management Chaincode", description = "Contract Management Chaincode", version = "1.0.0", license = @License(name = "Apache 2.0 License", url = "http://www.apache.org/licenses/LICENSE-2.0.html"), contact = @Contact(email = "mdibrahimk935@gmail.com", name = "Contract Management Chaincode", url = "https://hyperledger.example.com")))
@Default
public final class ContractManagementChaincode implements ContractInterface {

    private final Gson genson = new Gson();

    private static final ValidatorFactory factory = Validation.byDefaultProvider().configure()
            .messageInterpolator(new ParameterMessageInterpolator()).buildValidatorFactory();
    private static final Validator validator = factory.getValidator();

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public TransactionContract contractRegistration(final Context ctx, String contractData) {
        ChaincodeStub stub = ctx.getStub();
        Gson gson = new Gson();
        TransactionContract transactionContract = gson.fromJson(contractData, TransactionContract.class);

        String validationErrors = validate(transactionContract);
        if (validationErrors != null)
            throw new ChaincodeException(validationErrors);

        long count = 0;
        try {
            count = Long.parseLong(stub.getStringState(Keys.CONTRACT_COUNT)) + 1;
        } catch (Exception e) {
            count = 1;
        }
        String contractId = String.format(Keys.CONTRACT_ID, count);
        transactionContract.setId(contractId);
        transactionContract.setCreationTransactionHash(stub.getTxId());
        transactionContract.setCreationTimeStamp(stub.getTxTimestamp().toEpochMilli());
        stub.putStringState(contractId, gson.toJson(transactionContract));
        stub.putStringState(Keys.CONTRACT_COUNT, String.valueOf(count));
        return transactionContract;
    }

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public TransactionContract contractUpdate(final Context ctx, String contractData) {
        ChaincodeStub stub = ctx.getStub();
        Gson gson = new Gson();
        TransactionContract transactionContract = gson.fromJson(contractData, TransactionContract.class);
        String validationErrors = validate(transactionContract);
        if (validationErrors != null)
            throw new ChaincodeException("failed to execute chaincode", validationErrors);

        String asset = stub.getStringState(transactionContract.getId());
        if (asset == null || asset.isEmpty()) {
            throw new ChaincodeException("failed to execute chaincode", "No contract found by given id");
        }
        TransactionContract tc = genson.fromJson(asset, TransactionContract.class);

        transactionContract.setCreationTransactionHash(tc.getCreationTransactionHash());
        transactionContract.setCreationTimeStamp(tc.getCreationTimeStamp());

        transactionContract.setLastUpdateTimeStamp(stub.getTxTimestamp().toEpochMilli());
        transactionContract.setLastTransactionHash(stub.getTxId());

        stub.putStringState(transactionContract.getId(), gson.toJson(transactionContract));
        return transactionContract;
    }

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public Boolean deleteContractById(final Context ctx, String contractId) {
        ChaincodeStub stub = ctx.getStub();
        String assetJSON = stub.getStringState(contractId);

        if (assetJSON == null || assetJSON.isEmpty()) {
            String errorMessage = String.format("contract %s does not exist", contractId);
            System.out.println(errorMessage);
            throw new ChaincodeException(errorMessage, "contract not found");
        }
        stub.delState(contractId);
        return true;
    }

    @Transaction(intent = Transaction.TYPE.EVALUATE)
    public String getAllContracts(final Context ctx) {
        ChaincodeStub stub = ctx.getStub();
        ArrayList<TransactionContract> transactionContracts = new ArrayList<>();
        int count = 0;
        try {
            count = Integer.parseInt(stub.getStringState(Keys.CONTRACT_COUNT));
        } catch (Exception ex) {
            count = 0;
        }
        
        // Query all contracts from contract.1 to contract.{count}
        for (int i = 1; i <= count; i++) {
            String contractId = String.format(Keys.CONTRACT_ID, i);
            String contractJSON = stub.getStringState(contractId);
            if (contractJSON != null && !contractJSON.isEmpty()) {
                try {
                    TransactionContract contract = genson.fromJson(contractJSON, TransactionContract.class);
                    transactionContracts.add(contract);
                } catch (Exception e) {
                    System.out.println("Error parsing contract " + contractId + ": " + e.getMessage());
                }
            }
        }
        
        return genson.toJson(transactionContracts);
    }

    @Transaction(intent = Transaction.TYPE.EVALUATE)
    public TransactionContract getContractById(final Context ctx, String contractId) {
        ChaincodeStub stub = ctx.getStub();
        String assetJSON = stub.getStringState(contractId);

        if (assetJSON == null || assetJSON.isEmpty()) {
            String errorMessage = String.format("contract %s does not exist", contractId);
            System.out.println(errorMessage);
            throw new ChaincodeException(errorMessage, "contract not found");
        }
        return genson.fromJson(assetJSON, TransactionContract.class);
    }

    @Transaction(intent = Transaction.TYPE.EVALUATE)
    public String getContractsByEmail(final Context ctx, String email) {
        ChaincodeStub stub = ctx.getStub();
        ArrayList<TransactionContract> transactionContracts = new ArrayList<>();
        QueryResultsIterator<KeyValue> results = stub.getQueryResult("{\"selector\":{\"email\":\"" + email + "\" }}");
        for (KeyValue value : results) {
            transactionContracts.add(genson.fromJson(value.getStringValue(), TransactionContract.class));
        }
        return genson.toJson(transactionContracts);
    }

    public String validate(TransactionContract transactionContract) {
        Set<ConstraintViolation<TransactionContract>> violations = validator.validate(transactionContract);
        if (!violations.isEmpty()) {
            JsonObject errorJson = new JsonObject();
            errorJson.addProperty("status", "error");
            errorJson.addProperty("message", "Validation failed");

            JsonArray errors = new JsonArray();
            for (ConstraintViolation<TransactionContract> violation : violations) {
                JsonObject fieldError = new JsonObject();
                fieldError.addProperty("field", violation.getPropertyPath().toString());
                fieldError.addProperty("error", violation.getMessage());
                errors.add(fieldError);
            }
            errorJson.add("errors", errors);
            System.out.println(errorJson.toString());
            return errorJson.toString();
        }
        return null;
    }
}
