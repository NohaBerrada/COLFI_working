package org.hyperledger.fabric.business.chaincode;

public class Keys {

    public static String CONTRACT_ID = "contract.%s";
    public static String CONTRACT_COUNT = "contract.count";
}
