package org.hyperledger.fabric.business.chaincode;

import java.io.Serializable;

import jakarta.validation.constraints.*;
import org.hyperledger.fabric.contract.annotation.DataType;
import org.hyperledger.fabric.contract.annotation.Property;

@DataType()
public class TransactionContract implements Serializable {

    @Property()
    private String id;

    @Property()
    @NotBlank(message = "Legal name is required")
    private String legalName;

    @Property()
    private String address;

    @Property()
    private String phone;

    @Property()
    private String email;

    @Property()
    @NotBlank(message = "Asset type is required")
    private String assetType;

    @Property()
    private String termsAndConditionsOfTransaction;

    @Property()
    @NotNull(message = "Transaction amount cannot be null")
    @Positive(message = "Transaction amount must be positive")
    private Double transactionAmount;

    @Property()
    private String quantity;

    @Property()
    private String obligationDetails;

    @Property()
    private String deliveryTimelines;

    @Property()
    private String precedentCondition;

    @Property()
    private String terminationCondition;

    @Property()
    private String terminationEventDefault;

    @Property()
    private String terminationNotice;

    @Property()
    private String lawGoverning;

    @Property()
    private String jurisdictionForDispute;

    @Property()
    private String specificRepresentation;

    @Property()
    private String representationDisclaimer;

    @Property()
    private String collateralDetails;

    @Property()
    private String collateralConditions;

    @Property()
    private String signingAuthority;

    @Property()
    private String requiredSupportingDocuments;

    @Property()
    private String conditionsOfRatings;

    @Property()
    private String thirdPartyInvolvementDetails;

    @Property()
    private String miscellaneousClauses;

    @Property()
    private String methodOfExecution;

    @Property()
    @NotBlank(message = "Effective date is required")
    private String effectiveDateOfContract;

    @Property()
    private String maturityDate;

    @Property()
    private String contractOwner;

    @Property()
    private String lastTransactionHash;

    @Property()
    private String creationTransactionHash;

    @Property()
    private long creationTimeStamp;

    @Property()
    private long lastUpdateTimeStamp;

    // No-args constructor
    public TransactionContract() {}

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getLegalName() { return legalName; }
    public void setLegalName(String legalName) { this.legalName = legalName; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAssetType() { return assetType; }
    public void setAssetType(String assetType) { this.assetType = assetType; }

    public String getTermsAndConditionsOfTransaction() { return termsAndConditionsOfTransaction; }
    public void setTermsAndConditionsOfTransaction(String termsAndConditionsOfTransaction) { this.termsAndConditionsOfTransaction = termsAndConditionsOfTransaction; }

    public Double getTransactionAmount() { return transactionAmount; }
    public void setTransactionAmount(Double transactionAmount) { this.transactionAmount = transactionAmount; }

    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }

    public String getObligationDetails() { return obligationDetails; }
    public void setObligationDetails(String obligationDetails) { this.obligationDetails = obligationDetails; }

    public String getDeliveryTimelines() { return deliveryTimelines; }
    public void setDeliveryTimelines(String deliveryTimelines) { this.deliveryTimelines = deliveryTimelines; }

    public String getPrecedentCondition() { return precedentCondition; }
    public void setPrecedentCondition(String precedentCondition) { this.precedentCondition = precedentCondition; }

    public String getTerminationCondition() { return terminationCondition; }
    public void setTerminationCondition(String terminationCondition) { this.terminationCondition = terminationCondition; }

    public String getTerminationEventDefault() { return terminationEventDefault; }
    public void setTerminationEventDefault(String terminationEventDefault) { this.terminationEventDefault = terminationEventDefault; }

    public String getTerminationNotice() { return terminationNotice; }
    public void setTerminationNotice(String terminationNotice) { this.terminationNotice = terminationNotice; }

    public String getLawGoverning() { return lawGoverning; }
    public void setLawGoverning(String lawGoverning) { this.lawGoverning = lawGoverning; }

    public String getJurisdictionForDispute() { return jurisdictionForDispute; }
    public void setJurisdictionForDispute(String jurisdictionForDispute) { this.jurisdictionForDispute = jurisdictionForDispute; }

    public String getSpecificRepresentation() { return specificRepresentation; }
    public void setSpecificRepresentation(String specificRepresentation) { this.specificRepresentation = specificRepresentation; }

    public String getRepresentationDisclaimer() { return representationDisclaimer; }
    public void setRepresentationDisclaimer(String representationDisclaimer) { this.representationDisclaimer = representationDisclaimer; }

    public String getCollateralDetails() { return collateralDetails; }
    public void setCollateralDetails(String collateralDetails) { this.collateralDetails = collateralDetails; }

    public String getCollateralConditions() { return collateralConditions; }
    public void setCollateralConditions(String collateralConditions) { this.collateralConditions = collateralConditions; }

    public String getSigningAuthority() { return signingAuthority; }
    public void setSigningAuthority(String signingAuthority) { this.signingAuthority = signingAuthority; }

    public String getRequiredSupportingDocuments() { return requiredSupportingDocuments; }
    public void setRequiredSupportingDocuments(String requiredSupportingDocuments) { this.requiredSupportingDocuments = requiredSupportingDocuments; }

    public String getConditionsOfRatings() { return conditionsOfRatings; }
    public void setConditionsOfRatings(String conditionsOfRatings) { this.conditionsOfRatings = conditionsOfRatings; }

    public String getThirdPartyInvolvementDetails() { return thirdPartyInvolvementDetails; }
    public void setThirdPartyInvolvementDetails(String thirdPartyInvolvementDetails) { this.thirdPartyInvolvementDetails = thirdPartyInvolvementDetails; }

    public String getMiscellaneousClauses() { return miscellaneousClauses; }
    public void setMiscellaneousClauses(String miscellaneousClauses) { this.miscellaneousClauses = miscellaneousClauses; }

    public String getMethodOfExecution() { return methodOfExecution; }
    public void setMethodOfExecution(String methodOfExecution) { this.methodOfExecution = methodOfExecution; }

    public String getEffectiveDateOfContract() { return effectiveDateOfContract; }
    public void setEffectiveDateOfContract(String effectiveDateOfContract) { this.effectiveDateOfContract = effectiveDateOfContract; }

    public String getMaturityDate() { return maturityDate; }
    public void setMaturityDate(String maturityDate) { this.maturityDate = maturityDate; }

    public String getContractOwner() { return contractOwner; }
    public void setContractOwner(String contractOwner) { this.contractOwner = contractOwner; }

    public String getLastTransactionHash() { return lastTransactionHash; }
    public void setLastTransactionHash(String lastTransactionHash) { this.lastTransactionHash = lastTransactionHash; }

    public String getCreationTransactionHash() { return creationTransactionHash; }
    public void setCreationTransactionHash(String creationTransactionHash) { this.creationTransactionHash = creationTransactionHash; }

    public long getCreationTimeStamp() { return creationTimeStamp; }
    public void setCreationTimeStamp(long creationTimeStamp) { this.creationTimeStamp = creationTimeStamp; }

    public long getLastUpdateTimeStamp() { return lastUpdateTimeStamp; }
    public void setLastUpdateTimeStamp(long lastUpdateTimeStamp) { this.lastUpdateTimeStamp = lastUpdateTimeStamp; }
}
