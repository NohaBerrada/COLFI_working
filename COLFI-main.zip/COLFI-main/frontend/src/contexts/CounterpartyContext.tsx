import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getAllCounterparties, addCounterparty as addCounterpartyAPI, removeCounterparty as removeCounterpartyAPI, Counterparty } from '../utils/backendApi';

interface CounterpartyContextType {
  counterparties: Counterparty[];
  loading: boolean;
  error: string | null;
  addCounterparty: (counterparty: Counterparty) => Promise<void>;
  removeCounterparty: (id: string) => Promise<void>;
  getCounterpartyById: (id: string) => Counterparty | undefined;
  refreshCounterparties: () => Promise<void>;
}

const CounterpartyContext = createContext<CounterpartyContextType | undefined>(undefined);

interface CounterpartyProviderProps {
  children: ReactNode;
}

export const CounterpartyProvider: React.FC<CounterpartyProviderProps> = ({ children }) => {
  const [counterparties, setCounterparties] = useState<Counterparty[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Ensure counterparties is always an array
  const safeCounterparties = Array.isArray(counterparties) ? counterparties : [];

  // Load counterparties on component mount
  useEffect(() => {
    loadCounterparties();
  }, []);

  const loadCounterparties = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await getAllCounterparties();
      
      if (result.success && result.data) {
        setCounterparties(result.data);
      } else {
        setError(result.error || 'Failed to load counterparties');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  const addCounterparty = async (counterparty: Counterparty) => {
    try {
      setError(null);
      const result = await addCounterpartyAPI(counterparty);
      
      if (result.success) {
        // Refresh the list to get the updated data
        await loadCounterparties();
      } else {
        setError(result.error || 'Failed to add counterparty');
        throw new Error(result.error || 'Failed to add counterparty');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      throw err;
    }
  };

  const removeCounterparty = async (id: string) => {
    try {
      setError(null);
      const result = await removeCounterpartyAPI(id);
      
      if (result.success) {
        // Refresh the list to get the updated data
        await loadCounterparties();
      } else {
        setError(result.error || 'Failed to remove counterparty');
        throw new Error(result.error || 'Failed to remove counterparty');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      throw err;
    }
  };

  const getCounterpartyById = (id: string) => {
    return safeCounterparties.find(cp => cp.id === id);
  };

  const refreshCounterparties = async () => {
    await loadCounterparties();
  };

  return (
    <CounterpartyContext.Provider value={{
      counterparties: safeCounterparties,
      loading,
      error,
      addCounterparty,
      removeCounterparty,
      getCounterpartyById,
      refreshCounterparties
    }}>
      {children}
    </CounterpartyContext.Provider>
  );
};

export const useCounterparty = () => {
  const context = useContext(CounterpartyContext);
  if (context === undefined) {
    throw new Error('useCounterparty must be used within a CounterpartyProvider');
  }
  return context;
};
