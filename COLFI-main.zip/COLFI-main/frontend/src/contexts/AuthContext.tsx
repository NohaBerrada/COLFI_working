import React, { createContext, useContext, useState, ReactNode } from 'react';
import { loginUser, User } from '../utils/backendApi';

interface AuthContextType {
  isAuthenticated: boolean;
  currentUser: User | null;
  login: (credentials: { id: string; name: string }) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
  error: string | null;
  isInitializing: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  const login = async (credentials: { id: string; name: string }): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);
      
      const result = await loginUser(credentials);
      
      if (result.success && result.data) {
        setCurrentUser(result.data);
        setIsAuthenticated(true);
        // Store in localStorage for persistence
        localStorage.setItem('currentUser', JSON.stringify(result.data));
        localStorage.setItem('isAuthenticated', 'true');
        return true;
      } else {
        setError(result.error || 'Login failed');
        return false;
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
    setError(null);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('isAuthenticated');
  };

  // Check for existing authentication on mount
  React.useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    const storedAuth = localStorage.getItem('isAuthenticated');
    
    if (storedUser && storedAuth === 'true') {
      try {
        const user = JSON.parse(storedUser);
        setCurrentUser(user);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('currentUser');
        localStorage.removeItem('isAuthenticated');
      }
    }
    
    // Mark initialization as complete
    setIsInitializing(false);
  }, []);

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      currentUser,
      login,
      logout,
      loading,
      error,
      isInitializing
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
