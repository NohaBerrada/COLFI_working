import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface ContractFormData {
  // Step 1: Client Information
  legalName: string;
  address: string;
  email: string;
  phone: string;
  contractOwner: string;

  // Step 2: Transaction Details
  assetType: string;
  assetName: string;
  termsAndConditionsOfTransaction: string;
  nominalValue: string;
  quantity: string;
  obligationDetails: string;
  deliveryTimelines: string;
  precedentCondition: string;
  terminationCondition: string;
  terminationEventDefault: string;
  terminationNotice: string;
  lawGoverning: string;
  jurisdictionForDispute: string;

  // Step 3: Security & Warranties
  specificRepresentation: string;
  representationDisclaimer: string;
  collateralDetails: string;
  collateralConditions: string;
  signingAuthority: string;
  requiredSupportingDocuments: string;

  // Step 4: Additional Provisions
  conditionsOfRatings: string;
  thirdPartyInvolvementDetails: string;
  miscellaneousClauses: string;

  // Step 5: Execution Details
  methodOfExecution: string;
  effectiveDateOfContract: string;
  maturityDate: string;
}

interface ContractFormContextType {
  formData: ContractFormData;
  updateField: (field: keyof ContractFormData, value: string) => void;
  updateMultipleFields: (fields: Partial<ContractFormData>) => void;
  resetForm: () => void;
  getFormData: () => ContractFormData;
}

const defaultFormData: ContractFormData = {
  legalName: "",
  address: "",
  email: "",
  phone: "",
  contractOwner: "",
  assetType: "",
  assetName: "",
  termsAndConditionsOfTransaction: "",
  nominalValue: "",
  quantity: "",
  obligationDetails: "",
  deliveryTimelines: "",
  precedentCondition: "",
  terminationCondition: "",
  terminationEventDefault: "",
  terminationNotice: "",
  lawGoverning: "",
  jurisdictionForDispute: "",
  specificRepresentation: "",
  representationDisclaimer: "",
  collateralDetails: "",
  collateralConditions: "",
  signingAuthority: "",
  requiredSupportingDocuments: "",
  conditionsOfRatings: "",
  thirdPartyInvolvementDetails: "",
  miscellaneousClauses: "",
  methodOfExecution: "",
  effectiveDateOfContract: "",
  maturityDate: ""
};

const ContractFormContext = createContext<ContractFormContextType | undefined>(undefined);

export const useContractForm = (): ContractFormContextType => {
  const context = useContext(ContractFormContext);
  if (!context) {
    throw new Error('useContractForm must be used within a ContractFormProvider');
  }
  return context;
};

interface ContractFormProviderProps {
  children: ReactNode;
}

export const ContractFormProvider: React.FC<ContractFormProviderProps> = ({ children }) => {
  const [formData, setFormData] = useState<ContractFormData>(defaultFormData);

  const updateField = (field: keyof ContractFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateMultipleFields = (fields: Partial<ContractFormData>) => {
    setFormData(prev => ({ ...prev, ...fields }));
  };

  const resetForm = () => {
    setFormData(defaultFormData);
  };

  const getFormData = () => {
    return formData;
  };

  const value: ContractFormContextType = {
    formData,
    updateField,
    updateMultipleFields,
    resetForm,
    getFormData,
  };

  return (
    <ContractFormContext.Provider value={value}>
      {children}
    </ContractFormContext.Provider>
  );
};
