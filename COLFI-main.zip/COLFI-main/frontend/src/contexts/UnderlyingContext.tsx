import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getAllUnderlyings, addUnderlying as addUnderlyingAPI, removeUnderlying as removeUnderlyingAPI, Underlying } from '../utils/backendApi';
import { getQuote, getMultipleQuotes, getCacheInfo } from '../utils/finnhubApi';

// Helper function to check if a symbol has a default value
const hasDefaultValue = (symbol: string): boolean => {
  const defaultValues = ["TTE.PA", "SAN.PA", "XAU/USD"];
  return defaultValues.includes(symbol);
};

// Helper function to get default value for a symbol
const getDefaultValue = (symbol: string): number | null => {
  const defaultValues: Record<string, number> = {
    "TTE.PA": 51.57,
    "SAN.PA": 0.66,
    "XAU/USD": 3754
  };
  return defaultValues[symbol] || null;
};

interface UnderlyingContextType {
  underlyings: Underlying[];
  loading: boolean;
  error: string | null;
  priceLoading: Record<string, boolean>;
  addUnderlying: (underlying: Underlying) => Promise<void>;
  removeUnderlying: (id: string) => Promise<void>;
  getUnderlyingById: (id: string) => Underlying | undefined;
  refreshUnderlyings: () => Promise<void>;
  fetchPriceForUnderlying: (id: string) => Promise<void>;
  fetchPricesForZeroValueUnderlyings: (forceRefresh?: boolean) => Promise<void>;
}

const UnderlyingContext = createContext<UnderlyingContextType | undefined>(undefined);

interface UnderlyingProviderProps {
  children: ReactNode;
}

export const UnderlyingProvider: React.FC<UnderlyingProviderProps> = ({ children }) => {
  const [underlyings, setUnderlyings] = useState<Underlying[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [priceLoading, setPriceLoading] = useState<Record<string, boolean>>({});

  // Ensure underlyings is always an array
  const safeUnderlyings = Array.isArray(underlyings) ? underlyings : [];

  const loadUnderlyings = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await getAllUnderlyings();
      
      if (result.success && result.data) {
        // Set default values immediately for symbols that have them
        const processedUnderlyings = result.data.map(ul => {
          if (ul.value === 0 && hasDefaultValue(ul.id)) {
            const defaultValue = getDefaultValue(ul.id);
            if (defaultValue !== null) {
              console.log(`Setting default value for ${ul.id}: ${defaultValue}`);
              return { ...ul, value: defaultValue };
            }
          }
          return ul;
        });
        
        setUnderlyings(processedUnderlyings);
        
        // Auto-fetch prices for remaining zero-value underlyings after a short delay
        setTimeout(() => {
          const zeroValueUnderlyings = processedUnderlyings.filter(ul => ul.value === 0);
          if (zeroValueUnderlyings.length > 0) {
            console.log(`Auto-fetching prices for ${zeroValueUnderlyings.length} zero-value underlyings`);
            fetchPricesForZeroValueUnderlyings(false);
            
            // Retry failed fetches after 5 seconds
            setTimeout(() => {
              const stillZeroValueUnderlyings = underlyings.filter(ul => ul.value === 0);
              if (stillZeroValueUnderlyings.length > 0) {
                console.log(`Retrying failed fetches for ${stillZeroValueUnderlyings.length} underlyings`);
                fetchPricesForZeroValueUnderlyings(true); // Force refresh
              }
            }, 5000);
          }
        }, 1000);
      } else {
        setError(result.error || 'Failed to load underlyings');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  const addUnderlying = async (underlying: Underlying) => {
    try {
      setError(null);
      const result = await addUnderlyingAPI(underlying);

      if (result.success) {
        // Refresh the list to get the updated data
        await loadUnderlyings();
      } else {
        setError(result.error || 'Failed to add underlying');
        throw new Error(result.error || 'Failed to add underlying');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      throw err;
    }
  };

  const removeUnderlying = async (id: string) => {
    try {
      setError(null);
      const result = await removeUnderlyingAPI(id);

      if (result.success) {
        // Refresh the list to get the updated data
        await loadUnderlyings();
      } else {
        setError(result.error || 'Failed to remove underlying');
        throw new Error(result.error || 'Failed to remove underlying');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      throw err;
    }
  };

  // Load underlyings on component mount
  useEffect(() => {
    loadUnderlyings();
  }, []);


  const getUnderlyingById = (id: string) => {
    return safeUnderlyings.find(ul => ul.id === id);
  };

  const refreshUnderlyings = async () => {
    await loadUnderlyings();
  };

  const fetchPriceForUnderlying = async (id: string) => {
    const underlying = safeUnderlyings.find(ul => ul.id === id);
    if (!underlying || underlying.value !== 0) {
      console.log(`Skipping fetch for ${id}: underlying not found or value not 0`);
      return;
    }

    // Use FRED API for Gov Bond type underlyings
    if (underlying.type === "Gov Bond") {
      console.log(`Using FRED API for ${id}: Gov Bond type`);
      setPriceLoading(prev => ({ ...prev, [id]: true }));
      
      try {
        // Import FRED function dynamically to avoid circular imports
        const { getFredBondData } = await import('../utils/finnhubApi');
        const result = await getFredBondData(id);
        
        if (result.success && result.data) {
          const newPrice = result.data.c;
          console.log(`Updating ${id} with FRED price: ${newPrice}`);
          
          setUnderlyings(prev => prev.map(ul => 
            ul.id === id 
              ? { ...ul, value: newPrice }
              : ul
          ));
        } else {
          console.warn(`Failed to fetch FRED data for ${id}:`, result.error);
          // Keep value at 0, don't update UI
        }
      } catch (error) {
        console.error(`Error fetching FRED data for ${id}:`, error);
      } finally {
        setPriceLoading(prev => ({ ...prev, [id]: false }));
      }
      return;
    }

    console.log(`Fetching price for ${id}...`);
    
    // Skip loading state for symbols with default values (they get values immediately)
    if (!hasDefaultValue(id)) {
      setPriceLoading(prev => ({ ...prev, [id]: true }));
    }
    
    try {
      const result = await getQuote(id);
      console.log(`Price fetch result for ${id}:`, result);
      
      if (result.success && result.data) {
        const newPrice = result.data.c;
        console.log(`Updating ${id} with price: ${newPrice}`);
        
        // Update the underlying with the new price
        setUnderlyings(prev => prev.map(ul => 
          ul.id === id 
            ? { ...ul, value: newPrice }
            : ul
        ));
        
        console.log(`Successfully updated ${id} with price ${newPrice}`);
      } else {
        console.warn(`Failed to fetch price for ${id}:`, result.error);
        // Keep value at 0, don't update UI
      }
    } catch (error) {
      console.error(`Error fetching price for ${id}:`, error);
    } finally {
      setPriceLoading(prev => ({ ...prev, [id]: false }));
    }
  };

  const fetchPricesForZeroValueUnderlyings = async (forceRefresh: boolean = false) => {
    const zeroValueUnderlyings = safeUnderlyings.filter(ul => ul.value === 0);
    console.log(`Found ${zeroValueUnderlyings.length} zero-value underlyings:`, zeroValueUnderlyings.map(ul => ul.id));
    
    if (zeroValueUnderlyings.length === 0) {
      console.log('No zero-value underlyings to fetch prices for');
      return;
    }

    // Separate Gov Bond types (use FRED API) from others (use Finnhub)
    // Also exclude symbols with default values (they get values automatically)
    const fetchableUnderlyings = zeroValueUnderlyings.filter(ul => 
      ul.type !== "Gov Bond" && !hasDefaultValue(ul.id)
    );
    const govBondUnderlyings = zeroValueUnderlyings.filter(ul => ul.type === "Gov Bond");
    
    if (govBondUnderlyings.length > 0) {
      console.log(`Processing ${govBondUnderlyings.length} Gov Bond underlyings with FRED API:`, govBondUnderlyings.map(ul => ul.id));
      
      // Set loading state for Gov Bond underlyings
      const govBondLoadingState = govBondUnderlyings.reduce((acc, ul) => {
        acc[ul.id] = true;
        return acc;
      }, {} as Record<string, boolean>);
      setPriceLoading(prev => ({ ...prev, ...govBondLoadingState }));
      
      // Fetch FRED data for Gov Bonds
      try {
        const { getFredBondData } = await import('../utils/finnhubApi');
        const fredPromises = govBondUnderlyings.map(async (ul) => {
          const result = await getFredBondData(ul.id);
          return { id: ul.id, result };
        });
        
        const fredResults = await Promise.all(fredPromises);
        
        // Update underlyings with FRED data (only on success)
        setUnderlyings(prev => prev.map(ul => {
          const fredResult = fredResults.find(r => r.id === ul.id);
          if (fredResult && fredResult.result.success && fredResult.result.data) {
            const newPrice = fredResult.result.data.c;
            console.log(`Updating ${ul.id} with FRED price: ${newPrice}`);
            return { ...ul, value: newPrice };
          } else if (fredResult) {
            console.warn(`Failed to fetch FRED data for ${ul.id}:`, fredResult.result.error);
            // Keep value at 0, don't update UI
          }
          return ul;
        }));
        
        // Clear loading state for Gov Bond underlyings
        const clearGovBondLoadingState = govBondUnderlyings.reduce((acc, ul) => {
          acc[ul.id] = false;
          return acc;
        }, {} as Record<string, boolean>);
        setPriceLoading(prev => ({ ...prev, ...clearGovBondLoadingState }));
        
      } catch (error) {
        console.error('Error fetching FRED data for Gov Bonds:', error);
        // Clear loading state on error
        const clearGovBondLoadingState = govBondUnderlyings.reduce((acc, ul) => {
          acc[ul.id] = false;
          return acc;
        }, {} as Record<string, boolean>);
        setPriceLoading(prev => ({ ...prev, ...clearGovBondLoadingState }));
      }
    }
    
    if (fetchableUnderlyings.length === 0) {
      console.log('No fetchable underlyings (all are Gov Bonds)');
      return;
    }

    // Show cache info
    const cacheInfo = getCacheInfo();
    console.log(`Cache info: ${cacheInfo.validEntries} valid, ${cacheInfo.expiredEntries} expired entries`);

    console.log(`Starting ${forceRefresh ? 'forced refresh' : 'cached'} price fetch for ${fetchableUnderlyings.length} fetchable underlyings...`);

    // Set loading state for fetchable underlyings only
    const loadingState = fetchableUnderlyings.reduce((acc, ul) => {
      acc[ul.id] = true;
      return acc;
    }, {} as Record<string, boolean>);
    
    setPriceLoading(prev => ({ ...prev, ...loadingState }));

    try {
      const symbols = fetchableUnderlyings.map(ul => ul.id);
      console.log(`Fetching prices for symbols:`, symbols);
      const results = await getMultipleQuotes(symbols, forceRefresh);
      console.log(`Bulk fetch results:`, results);

      // Update underlyings with fetched prices (only on success)
      setUnderlyings(prev => prev.map(ul => {
        if (ul.value === 0 && results[ul.id]?.success && results[ul.id].data) {
          const newPrice = results[ul.id].data!.c;
          console.log(`Updating ${ul.id} with price: ${newPrice}`);
          return { ...ul, value: newPrice };
        } else if (ul.value === 0 && results[ul.id] && !results[ul.id].success) {
          console.warn(`Failed to fetch price for ${ul.id}:`, results[ul.id].error);
          // Keep value at 0, don't update UI
        }
        return ul;
      }));

      // Log any failures
      Object.entries(results).forEach(([symbol, result]) => {
        if (!result.success) {
          console.warn(`Failed to fetch price for ${symbol}:`, result.error);
        } else {
          console.log(`Successfully fetched price for ${symbol}:`, result.data?.c);
        }
      });
    } catch (error) {
      console.error('Error fetching prices for zero-value underlyings:', error);
    } finally {
      // Clear loading state for fetchable underlyings only
      const clearLoadingState = fetchableUnderlyings.reduce((acc, ul) => {
        acc[ul.id] = false;
        return acc;
      }, {} as Record<string, boolean>);
      
      setPriceLoading(prev => ({ ...prev, ...clearLoadingState }));
    }
  };

  return (
    <UnderlyingContext.Provider value={{
      underlyings: safeUnderlyings,
      loading,
      error,
      priceLoading,
      addUnderlying,
      removeUnderlying,
      getUnderlyingById,
      refreshUnderlyings,
      fetchPriceForUnderlying,
      fetchPricesForZeroValueUnderlyings
    }}>
      {children}
    </UnderlyingContext.Provider>
  );
};

export const useUnderlying = () => {
  const context = useContext(UnderlyingContext);
  if (context === undefined) {
    throw new Error('useUnderlying must be used within an UnderlyingProvider');
  }
  return context;
};
