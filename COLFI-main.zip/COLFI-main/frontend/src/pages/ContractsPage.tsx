import React from "react";
import { PlusIcon, FileTextIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { mockContracts } from "../data/mockData";
import { useSearch } from "../hooks/useSearch";

export const ContractsPage = (): JSX.Element => {
  const { filteredItems: contracts } = useSearch(
    mockContracts,
    ['title', 'customer'],
    ''
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100';
      case 'completed':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-100';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="[font-family:'Montserrat',Helvetica] font-bold text-h-1 text-[27px] tracking-[0] leading-[normal] mb-2">
            Contracts
          </h1>
          <p className="[font-family:'Montserrat',Helvetica] font-normal text-h-2 text-lg tracking-[0] leading-[normal]">
            Manage collateral agreements and contracts
          </p>
        </div>
        <Button className="bg-[#070e27] hover:bg-[#070e27]/90 text-white">
          <PlusIcon className="w-4 h-4 mr-2" />
          Create Contract
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {contracts.map((contract) => (
          <Card key={contract.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#070e27] rounded-full flex items-center justify-center">
                    <FileTextIcon className="w-5 h-5 text-white" />
                  </div>
                  <CardTitle className="text-lg">{contract.title}</CardTitle>
                </div>
                <Badge className={getStatusColor(contract.status)}>
                  {contract.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Customer:</span>
                  <span className="text-sm font-medium">{contract.customer}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Value:</span>
                  <span className="text-sm font-medium">
                    ${contract.value.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Start Date:</span>
                  <span className="text-sm font-medium">
                    {new Date(contract.startDate).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};