import { useState, useEffect } from "react";
import { PlusIcon, AlertTriangleIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { getAllContracts } from "../utils/backendApi";
import { useCounterparty } from "../contexts/CounterpartyContext";
import { useAuth } from "../contexts/AuthContext";
import { useSearch } from "../hooks/useSearch";

interface BankPartner {
  id: string;
  name: string;
  type: string;
  logo: string;
  contractsValue: string;
  signedContracts: string;
  bgColor: string;
}

export const CustomersPage = (): JSX.Element => {
  const { counterparties } = useCounterparty();
  const { currentUser } = useAuth();
  const [bankPartners, setBankPartners] = useState<BankPartner[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { filteredItems: customers } = useSearch(
    bankPartners,
    ['name', 'type'],
    ''
  );

  // Fetch contracts and transform to bank partner data
  useEffect(() => {
    console.log('Fetching bank partners data...', new Date().toISOString());
    const fetchBankPartners = async () => {
      try {
        setLoading(true);
        setError(null);
        // Clear any existing data first
        setBankPartners([]);
        const result = await getAllContracts();
        
        if (result.success && result.data) {
          console.log('API Response:', result.data);
          // Handle the actual API response structure
          let contractsData;
          if (result.data.data && Array.isArray(result.data.data)) {
            contractsData = result.data.data;
          } else if (Array.isArray(result.data)) {
            contractsData = result.data;
          } else {
            contractsData = [result.data];
          }
          console.log('Contracts Data:', contractsData);
          
          // Filter contracts by logged-in user's ID (contractOwner) OR name (legalName)
          const userContracts = contractsData.filter((contract: any) => {
            return contract.contractOwner === currentUser?.id || contract.legalName === currentUser?.name;
          });
          
          console.log('Filtered contracts for user:', currentUser?.id, userContracts);
          
          // Group filtered contracts by appropriate name (legalName or contractOwner)
          const contractsByLegalName = userContracts.reduce((acc: any, contract: any) => {
            let displayName;
            
            // If contract was sent TO current user, show the sender (contractOwner) as the bank name
            if (contract.legalName === currentUser?.name) {
              // Find counterparty by ID to get the proper name
              const counterparty = counterparties.find(cp => cp.id === contract.contractOwner);
              displayName = counterparty?.name || contract.contractOwner || 'Unknown Company';
            } else {
              // If current user owns the contract, show the recipient (legalName) as the bank name
              displayName = contract.legalName || 'Unknown Company';
            }
            
            if (!acc[displayName]) {
              acc[displayName] = [];
            }
            acc[displayName].push(contract);
            return acc;
          }, {});
          
          // Transform to bank partner format
          const bankPartnersData = Object.entries(contractsByLegalName)
            .map(([legalName, contracts]: [string, any]) => {
              // Calculate total contract value (nominalValue * quantity)
              const totalValue = contracts.reduce((sum: number, contract: any) => {
                const nominalValue = contract.transactionAmount || contract.nominalValue || 0;
                const quantityStr = contract.quantity || '1';
                const quantityMatch = quantityStr.match(/(\d+)/);
                const quantity = quantityMatch ? parseFloat(quantityMatch[1]) : 1;
                return sum + (nominalValue * quantity);
              }, 0);
              
              // Count signed contracts
              const signedContractsCount = contracts.length;
              
              // Find counterparty for logo
              const counterparty = counterparties.find(cp => cp.name === legalName);
              const logo = counterparty?.logo || `https://via.placeholder.com/40x40/4F46E5/FFFFFF?text=${legalName.charAt(0)}`;
              
              // Format contract value
              const formatValue = (value: number) => {
                if (value >= 1000000000) {
                  return `${(value / 1000000000).toFixed(0)} B$`;
                } else if (value >= 1000000) {
                  return `${(value / 1000000).toFixed(0)} M$`;
                } else if (value >= 1000) {
                  return `${(value / 1000).toFixed(0)} K$`;
                } else {
                  return `${value.toFixed(0)}$`;
                }
              };
              
              // Generate background colors
              const bgColors = ['bg-red-50', 'bg-green-50', 'bg-purple-50', 'bg-blue-50', 'bg-gray-50', 'bg-yellow-50'];
              const bgColor = bgColors[Math.floor(Math.random() * bgColors.length)];
              
              return {
                id: legalName.replace(/\s+/g, '-').toUpperCase(),
                name: legalName,
                type: 'Investment Bank', // Default type, could be enhanced with more logic
                logo: logo,
                contractsValue: formatValue(totalValue),
                signedContracts: signedContractsCount.toString(),
                bgColor: bgColor
              };
            })
            .sort((a, b) => a.name.localeCompare(b.name)); // Sort by legalName
          
          console.log('Final Bank Partners Data:', bankPartnersData);
          
          // Ensure we only set data from backend, not mock data
          if (bankPartnersData.length > 0) {
            console.log('Setting backend data - NO MOCK DATA USED');
            setBankPartners(bankPartnersData);
          } else {
            console.log('No contracts found in backend data');
            setBankPartners([]);
          }
        } else {
          setError(result.error || 'Failed to fetch contracts');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchBankPartners();
  }, [counterparties, currentUser]);

  // Loading screen
  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#070e27] mx-auto mb-4"></div>
            <p className="text-gray-600">Loading customers...</p>
          </div>
        </div>
      </div>
    );
  }

  // Error screen
  if (error) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="text-red-500 mb-4">
              <AlertTriangleIcon className="w-12 h-12 mx-auto" />
            </div>
            <p className="text-gray-600 mb-4">Error loading customers: {error}</p>
            <Button onClick={() => window.location.reload()} className="bg-[#070e27] hover:bg-[#070e27]/90">
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="[font-family:'Montserrat',Helvetica] font-bold text-h-1 text-[27px] tracking-[0] leading-[normal] mb-2">
            Customers
          </h1>
          <p className="[font-family:'Montserrat',Helvetica] font-normal text-h-2 text-lg tracking-[0] leading-[normal]">
            Manage your customer relationships
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={() => {
              setBankPartners([]);
              setLoading(true);
              setError(null);
              // Trigger a re-fetch instead of full page reload
              const fetchBankPartners = async () => {
                try {
                  setLoading(true);
                  setError(null);
                  const result = await getAllContracts();
                  
                  if (result.success && result.data) {
                    console.log('API Response:', result.data);
                    let contractsData;
                    if (result.data.data && Array.isArray(result.data.data)) {
                      contractsData = result.data.data;
                    } else if (Array.isArray(result.data)) {
                      contractsData = result.data;
                    } else {
                      contractsData = [result.data];
                    }
                    console.log('Contracts Data:', contractsData);
                    
                    // Filter contracts by logged-in user's ID (contractOwner) OR name (legalName)
                    const userContracts = contractsData.filter((contract: any) => {
                      return contract.contractOwner === currentUser?.id || contract.legalName === currentUser?.name;
                    });
                    
                    console.log('Filtered contracts for user:', currentUser?.id, userContracts);
                    
                    const contractsByLegalName = userContracts.reduce((acc: any, contract: any) => {
                      let displayName;
                      
                      // If contract was sent TO current user, show the sender (contractOwner) as the bank name
                      if (contract.legalName === currentUser?.name) {
                        // Find counterparty by ID to get the proper name
                        const counterparty = counterparties.find(cp => cp.id === contract.contractOwner);
                        displayName = counterparty?.name || contract.contractOwner || 'Unknown Company';
                      } else {
                        // If current user owns the contract, show the recipient (legalName) as the bank name
                        displayName = contract.legalName || 'Unknown Company';
                      }
                      
                      if (!acc[displayName]) {
                        acc[displayName] = [];
                      }
                      acc[displayName].push(contract);
                      return acc;
                    }, {});
                    
                    const bankPartnersData = Object.entries(contractsByLegalName)
                      .map(([legalName, contracts]: [string, any]) => {
                        const totalValue = contracts.reduce((sum: number, contract: any) => {
                          const nominalValue = contract.transactionAmount || contract.nominalValue || 0;
                          const quantityStr = contract.quantity || '1';
                          const quantityMatch = quantityStr.match(/(\d+)/);
                          const quantity = quantityMatch ? parseFloat(quantityMatch[1]) : 1;
                          return sum + (nominalValue * quantity);
                        }, 0);
                        
                        const signedContractsCount = contracts.length;
                        const counterparty = counterparties.find(cp => cp.name === legalName);
                        const logo = counterparty?.logo || `https://via.placeholder.com/40x40/4F46E5/FFFFFF?text=${legalName.charAt(0)}`;
                        
                        const formatValue = (value: number) => {
                          if (value >= 1000000000) {
                            return `${(value / 1000000000).toFixed(0)} B$`;
                          } else if (value >= 1000000) {
                            return `${(value / 1000000).toFixed(0)} M$`;
                          } else if (value >= 1000) {
                            return `${(value / 1000).toFixed(0)} K$`;
                          } else {
                            return `${value.toFixed(0)}$`;
                          }
                        };
                        
                        const bgColors = ['bg-red-50', 'bg-green-50', 'bg-purple-50', 'bg-blue-50', 'bg-gray-50', 'bg-yellow-50'];
                        const bgColor = bgColors[Math.floor(Math.random() * bgColors.length)];
                        
                        return {
                          id: legalName.replace(/\s+/g, '-').toUpperCase(),
                          name: legalName,
                          type: 'Investment Bank',
                          logo: logo,
                          contractsValue: formatValue(totalValue),
                          signedContracts: signedContractsCount.toString(),
                          bgColor: bgColor
                        };
                      })
                      .sort((a, b) => a.name.localeCompare(b.name));
                    
                    console.log('Final Bank Partners Data:', bankPartnersData);
                    
                    if (bankPartnersData.length > 0) {
                      console.log('Setting backend data - NO MOCK DATA USED');
                      setBankPartners(bankPartnersData);
                    } else {
                      console.log('No contracts found in backend data');
                      setBankPartners([]);
                    }
                  } else {
                    setError(result.error || 'Failed to fetch contracts');
                  }
                } catch (err) {
                  setError(err instanceof Error ? err.message : 'Unknown error occurred');
                } finally {
                  setLoading(false);
                }
              };
              fetchBankPartners();
            }} 
            variant="outline"
            className="border-[#070e27] text-[#070e27] hover:bg-[#070e27] hover:text-white"
          >
            Force Refresh
          </Button>
          <Button className="bg-[#070e27] hover:bg-[#070e27]/90 text-white">
            <PlusIcon className="w-4 h-4 mr-2" />
            Add Customer
          </Button>
        </div>
      </div>

      {/* Debug Info */}
      <div className="mb-4 p-4 bg-gray-100 rounded-lg">
        <p className="text-sm text-gray-600">
          <strong>Debug Info:</strong> Showing {customers.length} customers from backend data
        </p>
        <p className="text-xs text-gray-500">
          Data source: Backend API | Last updated: {new Date().toLocaleTimeString()}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {customers.map((customer) => (
          <Card key={customer.id} className={`hover:shadow-lg transition-shadow cursor-pointer ${customer.bgColor}`}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden">
                    <img
                      src={customer.logo}
                      alt={customer.name}
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://via.placeholder.com/40x40/4F46E5/FFFFFF?text=${customer.name.charAt(0)}`;
                      }}
                    />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{customer.name}</CardTitle>
                    <p className="text-sm text-gray-600">{customer.type}</p>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Contract Value:</span>
                  <span className="font-semibold text-lg">{customer.contractsValue}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Signed Contracts:</span>
                  <Badge className="bg-[#070e27] text-white hover:bg-[#070e27]/90">
                    {customer.signedContracts}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};