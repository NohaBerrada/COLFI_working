import React from "react";
import { PlusIcon, SettingsIcon, ClockIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { mockOperations } from "../data/mockData";
import { useSearch } from "../hooks/useSearch";

export const OperationsPage = (): JSX.Element => {
  const { filteredItems: operations } = useSearch(
    mockOperations,
    ['type', 'description'],
    ''
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-100';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="[font-family:'Montserrat',Helvetica] font-bold text-h-1 text-[27px] tracking-[0] leading-[normal] mb-2">
            Operations
          </h1>
          <p className="[font-family:'Montserrat',Helvetica] font-normal text-h-2 text-lg tracking-[0] leading-[normal]">
            Track and manage operational activities
          </p>
        </div>
        <Button className="bg-[#070e27] hover:bg-[#070e27]/90 text-white">
          <PlusIcon className="w-4 h-4 mr-2" />
          New Operation
        </Button>
      </div>

      <div className="space-y-4">
        {operations.map((operation) => (
          <Card key={operation.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#070e27] rounded-full flex items-center justify-center">
                    <SettingsIcon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{operation.type}</CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{operation.description}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <ClockIcon className="w-4 h-4" />
                    {new Date(operation.createdAt).toLocaleDateString()}
                  </div>
                  <Badge className={getStatusColor(operation.status)}>
                    {operation.status.replace('-', ' ')}
                  </Badge>
                </div>
              </div>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  );
};