import { MainContentSection } from "../screens/VueCollateral/sections/MainContentSection/MainContentSection";

export const WelcomePage = (): JSX.Element => {
  return (
    <div className="p-6 max-w-[1162px] w-full mx-auto">
      <div className="[font-family:'Montserrat',Helvetica] font-bold text-h-1 text-[27px] tracking-[0] leading-[normal] mb-2">
        Hello Thomas,
      </div>
      <div className="[font-family:'Montserrat',Helvetica] font-normal text-h-2 text-xl tracking-[0] leading-[normal] mb-8">
        What do you want to do today?
      </div>
      <MainContentSection />
    </div>
  );
};