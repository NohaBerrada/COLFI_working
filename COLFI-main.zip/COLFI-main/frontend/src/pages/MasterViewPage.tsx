import { useState, useEffect } from "react";
import { SearchIcon, AlertTriangleIcon, ArrowLeftIcon, EyeIcon } from "lucide-react";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { getAllContracts } from "../utils/backendApi";
import { useCounterparty } from "../contexts/CounterpartyContext";
import { useAuth } from "../contexts/AuthContext";

interface BankPartner {
  id: string;
  name: string;
  type: string;
  logo: string;
  contractsValue: string;
  signedContracts: string;
  bgColor: string;
}

interface Contract {
  id: string;
  legalName: string;
  assetType: string;
  effectiveDateOfContract: string;
  maturityDate: string;
  transactionAmount: number;
  quantity: string;
  nominalValue: number;
  contractOwner?: string;
}

export const MasterViewPage = (): JSX.Element => {
  const { counterparties } = useCounterparty();
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [bankPartners, setBankPartners] = useState<BankPartner[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedBank, setSelectedBank] = useState<BankPartner | null>(null);
  const [bankContracts, setBankContracts] = useState<Contract[]>([]);
  const [allContracts, setAllContracts] = useState<Contract[]>([]);

  const filteredBanks = bankPartners.filter((bank) => {
    return bank.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           bank.type.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Fetch contracts and transform to bank partner data
  useEffect(() => {
    console.log('Fetching bank partners data...', new Date().toISOString());
    const fetchBankPartners = async () => {
      try {
        setLoading(true);
        setError(null);
        // Clear any existing data first
        setBankPartners([]);
        const result = await getAllContracts();
        
        if (result.success && result.data) {
          console.log('API Response:', result.data);
          // Handle the actual API response structure
          let contractsData;
          if (result.data.data && Array.isArray(result.data.data)) {
            contractsData = result.data.data;
          } else if (Array.isArray(result.data)) {
            contractsData = result.data;
          } else {
            contractsData = [result.data];
          }
          console.log('Contracts Data:', contractsData);
          
          // Filter contracts by logged-in user's ID (contractOwner) OR name (legalName)
          const userContracts = contractsData.filter((contract: any) => {
            return contract.contractOwner === currentUser?.id || contract.legalName === currentUser?.name;
          });
          
          console.log('Filtered contracts for user:', currentUser?.id, userContracts);
          
          // Group filtered contracts by appropriate name (legalName or contractOwner)
          const contractsByLegalName = userContracts.reduce((acc: any, contract: any) => {
            let displayName;
            
            // If contract was sent TO current user, show the sender (contractOwner) as the bank name
            if (contract.legalName === currentUser?.name) {
              // Find counterparty by ID to get the proper name
              const counterparty = counterparties.find(cp => cp.id === contract.contractOwner);
              displayName = counterparty?.name || contract.contractOwner || 'Unknown Company';
            } else {
              // If current user owns the contract, show the recipient (legalName) as the bank name
              displayName = contract.legalName || 'Unknown Company';
            }
            
            if (!acc[displayName]) {
              acc[displayName] = [];
            }
            acc[displayName].push(contract);
            return acc;
          }, {});
          
          // Transform to bank partner format
          const bankPartnersData = Object.entries(contractsByLegalName)
            .map(([legalName, contracts]: [string, any]) => {
              // Calculate total contract value (nominalValue * quantity)
              const totalValue = contracts.reduce((sum: number, contract: any) => {
                const nominalValue = contract.transactionAmount || contract.nominalValue || 0;
                const quantityStr = contract.quantity || '1';
                const quantityMatch = quantityStr.match(/(\d+)/);
                const quantity = quantityMatch ? parseFloat(quantityMatch[1]) : 1;
                return sum + (nominalValue * quantity);
              }, 0);
              
              // Count signed contracts
              const signedContractsCount = contracts.length;
              
              // Find counterparty for logo using the display name
              const counterparty = counterparties.find(cp => cp.name === legalName);
              const logo = counterparty?.logo || `https://via.placeholder.com/94x94/4F46E5/FFFFFF?text=${legalName.charAt(0)}`;
              
              // Format contract value
              const formatValue = (value: number) => {
                if (value >= 1000000000) {
                  return `${(value / 1000000000).toFixed(0)} B$`;
                } else if (value >= 1000000) {
                  return `${(value / 1000000).toFixed(0)} M$`;
                } else if (value >= 1000) {
                  return `${(value / 1000).toFixed(0)} K$`;
                } else {
                  return `${value.toFixed(0)}$`;
                }
              };
              
              // Generate background colors
              const bgColors = ['bg-red-50', 'bg-green-50', 'bg-purple-50', 'bg-blue-50', 'bg-gray-50', 'bg-yellow-50'];
              const bgColor = bgColors[Math.floor(Math.random() * bgColors.length)];
              
              return {
                id: legalName.replace(/\s+/g, '-').toUpperCase(),
                name: legalName,
                type: 'Investment Bank', // Default type, could be enhanced with more logic
                logo: logo,
                contractsValue: formatValue(totalValue),
                signedContracts: signedContractsCount.toString(),
                bgColor: bgColor
              };
            })
            .sort((a, b) => a.name.localeCompare(b.name)); // Sort by legalName
          
          console.log('Final Bank Partners Data:', bankPartnersData);
          
          // Store filtered contracts for filtering later
          setAllContracts(userContracts);
          
          // Ensure we only set data from backend, not mock data
          if (bankPartnersData.length > 0) {
            console.log('Setting backend data - NO MOCK DATA USED');
            setBankPartners(bankPartnersData);
          } else {
            console.log('No contracts found in backend data');
            setBankPartners([]);
          }
        } else {
          setError(result.error || 'Failed to fetch contracts');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchBankPartners();
  }, [counterparties, currentUser]);

  // Handle bank click to show contracts
  const handleBankClick = (bank: BankPartner) => {
    setSelectedBank(bank);
    // Filter contracts by display name (which could be legalName or counterparty name)
    const filteredContracts = allContracts.filter(contract => {
      let displayName;
      
      // If contract was sent TO current user, show the sender (contractOwner) as the bank name
      if (contract.legalName === currentUser?.name) {
        // Find counterparty by ID to get the proper name
        const counterparty = counterparties.find(cp => cp.id === contract.contractOwner);
        displayName = counterparty?.name || contract.contractOwner || 'Unknown Company';
      } else {
        // If current user owns the contract, show the recipient (legalName) as the bank name
        displayName = contract.legalName || 'Unknown Company';
      }
      
      return displayName === bank.name;
    });
    setBankContracts(filteredContracts);
  };

  // Handle back to bank list
  const handleBackToBanks = () => {
    setSelectedBank(null);
    setBankContracts([]);
  };

  // Format dates safely
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) return dateString; // Return original if invalid
      return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
    } catch {
      return dateString; // Return original if parsing fails
    }
  };

  // Loading screen
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#070e27] mx-auto mb-4"></div>
          <p className="text-gray-600">Loading bank partners...</p>
        </div>
      </div>
    );
  }

  // Error screen
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 mb-4">
            <AlertTriangleIcon className="w-12 h-12 mx-auto" />
          </div>
          <p className="text-gray-600 mb-4">Error loading bank partners: {error}</p>
          <Button onClick={() => window.location.reload()} className="bg-[#070e27] hover:bg-[#070e27]/90">
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section with Dark Background */}
      <div 
        className="h-40 bg-cover bg-center relative"
     
      >
        <img src="/Rectangle 53.png" className="max-w-full h-full" alt="" />
        <div className="absolute inset-0 grad"></div>
      </div>

      {/* Content Section */}
      <div className=" max-lg:px-8 py-8 max-w-[1152px] w-full mx-auto  relative z-10">
        {/* Search Bar */}
        {!selectedBank && (
          <div className="mb-8">
            <div className="flex gap-4 mb-4">
              <div className="relative flex-1">
                <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="Find a customer"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full h-12 pl-12 pr-4 bg-white border border-gray-200 rounded-lg shadow-sm"
                />
              </div>
              <Button 
                onClick={() => {
                  setBankPartners([]);
                  setLoading(true);
                  setError(null);
                  // Trigger a re-fetch instead of full page reload
                  const fetchBankPartners = async () => {
                    try {
                      setLoading(true);
                      setError(null);
                      const result = await getAllContracts();
                      
                      if (result.success && result.data) {
                        console.log('API Response:', result.data);
                        let contractsData;
                        if (result.data.data && Array.isArray(result.data.data)) {
                          contractsData = result.data.data;
                        } else if (Array.isArray(result.data)) {
                          contractsData = result.data;
                        } else {
                          contractsData = [result.data];
                        }
                        console.log('Contracts Data:', contractsData);
                        
                        // Filter contracts by logged-in user's ID (contractOwner) OR name (legalName)
                        const userContracts = contractsData.filter((contract: any) => {
                          return contract.contractOwner === currentUser?.id || contract.legalName === currentUser?.name;
                        });
                        
                        console.log('Filtered contracts for user:', currentUser?.id, userContracts);
                        
                        const contractsByLegalName = userContracts.reduce((acc: any, contract: any) => {
                          let displayName;
                          
                          // If contract was sent TO current user, show the sender (contractOwner) as the bank name
                          if (contract.legalName === currentUser?.name) {
                            // Find counterparty by ID to get the proper name
                            const counterparty = counterparties.find(cp => cp.id === contract.contractOwner);
                            displayName = counterparty?.name || contract.contractOwner || 'Unknown Company';
                          } else {
                            // If current user owns the contract, show the recipient (legalName) as the bank name
                            displayName = contract.legalName || 'Unknown Company';
                          }
                          
                          if (!acc[displayName]) {
                            acc[displayName] = [];
                          }
                          acc[displayName].push(contract);
                          return acc;
                        }, {});
                        
                        const bankPartnersData = Object.entries(contractsByLegalName)
                          .map(([legalName, contracts]: [string, any]) => {
                            const totalValue = contracts.reduce((sum: number, contract: any) => {
                              const nominalValue = contract.transactionAmount || contract.nominalValue || 0;
                              const quantityStr = contract.quantity || '1';
                              const quantityMatch = quantityStr.match(/(\d+)/);
                              const quantity = quantityMatch ? parseFloat(quantityMatch[1]) : 1;
                              return sum + (nominalValue * quantity);
                            }, 0);
                            
                            const signedContractsCount = contracts.length;
                            const counterparty = counterparties.find(cp => cp.name === legalName);
                            const logo = counterparty?.logo || `https://via.placeholder.com/94x94/4F46E5/FFFFFF?text=${legalName.charAt(0)}`;
                            
                            const formatValue = (value: number) => {
                              if (value >= 1000000000) {
                                return `${(value / 1000000000).toFixed(0)} B$`;
                              } else if (value >= 1000000) {
                                return `${(value / 1000000).toFixed(0)} M$`;
                              } else if (value >= 1000) {
                                return `${(value / 1000).toFixed(0)} K$`;
                              } else {
                                return `${value.toFixed(0)}$`;
                              }
                            };
                            
                            const bgColors = ['bg-red-50', 'bg-green-50', 'bg-purple-50', 'bg-blue-50', 'bg-gray-50', 'bg-yellow-50'];
                            const bgColor = bgColors[Math.floor(Math.random() * bgColors.length)];
                            
                            return {
                              id: legalName.replace(/\s+/g, '-').toUpperCase(),
                              name: legalName,
                              type: 'Investment Bank',
                              logo: logo,
                              contractsValue: formatValue(totalValue),
                              signedContracts: signedContractsCount.toString(),
                              bgColor: bgColor
                            };
                          })
                          .sort((a, b) => a.name.localeCompare(b.name));
                        
                        console.log('Final Bank Partners Data:', bankPartnersData);
                        
                        setAllContracts(userContracts);
                        
                        if (bankPartnersData.length > 0) {
                          console.log('Setting backend data - NO MOCK DATA USED');
                          setBankPartners(bankPartnersData);
                        } else {
                          console.log('No contracts found in backend data');
                          setBankPartners([]);
                        }
                      } else {
                        setError(result.error || 'Failed to fetch contracts');
                      }
                    } catch (err) {
                      setError(err instanceof Error ? err.message : 'Unknown error occurred');
                    } finally {
                      setLoading(false);
                    }
                  };
                  fetchBankPartners();
                }} 
                variant="outline"
                className="border-[#070e27] text-[#070e27] hover:bg-[#070e27] hover:text-white"
              >
                Refresh
              </Button>
            </div>
            
          </div>
        )}

        {/* Bank Partners Grid */}
        {!selectedBank && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-[17px]">
            {filteredBanks.map((bank) => (
            <div
              key={bank.id}
              onClick={() => handleBankClick(bank)}
              className={` border border-[#CFCFCF] rounded-2xl p-6 hover:shadow-lg transition-all duration-300 cursor-pointer  `}
            >
              {/* Bank Logo and Info */}
              <div className="flex items-center gap-4 mb-6">
                  <img
                    src={bank.logo}
                    alt={bank.name}
                    className="w-[94px] h-[94px] object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = `https://via.placeholder.com/32x32/4F46E5/FFFFFF?text=${bank.name.charAt(0)}`;
                    }}
                  />
                <div>
                  <h3 className="font-semibold text-gray-900 text-xs leading-tight">
                    {bank.name}
                  </h3>
                  <p className="text-xs text-gray-600 mt-1">
                    {bank.type}
                  </p>
                </div>
              </div>

              {/* Contract Value */}
              <div className="flex justify-between">

              <div className="mb-4 ">
                <div className="text-[26px] font-medium text-[#5C5C5C] mb-1">
                  {bank.contractsValue}
                </div>
                <div className="text-xs text-gray-600">
                  Contracts value
                </div>
              </div>

              {/* Signed Contracts */}
              <div>
                <div className="text-[26px] font-medium text-[#5C5C5C] mb-1">
                  {bank.signedContracts}
                </div>
                <div className="text-xs text-gray-600">
                  Signed contracts
                </div>
              </div>
              </div>

            </div>
          ))}
          </div>
        )}

        {/* Contract List View */}
        {selectedBank && (
          <div className="mt-8">
            {/* Back Button and Header */}
            <div className="flex items-center gap-4 mb-6">
              <Button
                onClick={handleBackToBanks}
                variant="outline"
                className="flex items-center gap-2 border-[#070e27] text-[#070e27] hover:bg-[#070e27] hover:text-white"
              >
                <ArrowLeftIcon className="w-4 h-4" />
                Back to Banks
              </Button>
              <div>
                <h2 className="text-2xl font-semibold text-gray-900">
                  Contracts for {selectedBank.name}
                </h2>
                <p className="text-gray-600">
                  {bankContracts.length} contract{bankContracts.length !== 1 ? 's' : ''} found
                </p>
              </div>
            </div>

            {/* Contracts Table */}
            {bankContracts.length > 0 ? (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Contract ID
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Asset Type
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Trade Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Maturity Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Nominal Value
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Quantity
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {bankContracts.map((contract, index) => (
                        <tr key={contract.id || index} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            C_{String(index).padStart(2, '0')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {contract.assetType || 'Unknown'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-pink-600 font-bold">
                            {formatDate(contract.effectiveDateOfContract)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 font-bold">
                            {formatDate(contract.maturityDate)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-bold">
                            {contract.transactionAmount ? 
                              contract.transactionAmount.toLocaleString() : 
                              contract.nominalValue ? 
                                contract.nominalValue.toLocaleString() : 
                                'N/A'
                            }
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {contract.quantity || 'N/A'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center">
                <div className="text-gray-500 mb-4">
                  <EyeIcon className="w-12 h-12 mx-auto mb-2" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No contracts found</h3>
                <p className="text-gray-600">
                  No contracts are available for {selectedBank.name} at the moment.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};