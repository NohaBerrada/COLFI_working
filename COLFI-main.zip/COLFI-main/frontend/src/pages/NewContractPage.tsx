import React, { useState } from "react";
import { ArrowLeftIcon } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { Button } from "../components/ui/button";
import { ContractFormProvider, useContractForm } from "../contexts/ContractFormContext";
import {
  Step1ClientInformation,
  Step2TransactionDetails,
  Step3SecurityWarranties,
  Step4AdditionalProvisions,
  Step5ExecutionDetails
} from "../components/contract-steps";
import { submitContractToBackend } from "../utils/contractFormUtils";

const NewContractPageContent: React.FC = (): JSX.Element => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const { getFormData } = useContractForm();

  const steps = [
    { id: 1, title: "Client information", isActive: currentStep === 1 },
    { id: 2, title: "Obligations & Laws", isActive: currentStep === 2 },
    { id: 3, title: "Security & Warranties", isActive: currentStep === 3 },
    { id: 4, title: "Additional Provisions", isActive: currentStep === 4 },
    { id: 5, title: "Execution Details", isActive: currentStep === 5 },
  ];


  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    } else {
      navigate('/contracts');
    }
  };

  const handleSubmit = async () => {
    const formData = getFormData();
    console.log('Creating contract:', formData);
    
    // Show loading toast
    const loadingToast = toast.loading('Creating smart contract...');
    
    try {
      // Submit to backend
      const result = await submitContractToBackend(formData);
      
      // Dismiss loading toast
      toast.dismiss(loadingToast);
      
      if (result.success) {
        console.log('Contract created successfully:', result.contractId);
        toast.success('Smart contract created successfully!', {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
        navigate('/contracts');
      } else {
        console.error('Failed to create contract:', result.error);
        toast.error(`Failed to create contract: ${result.error}`, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
        });
      }
    } catch (error) {
      // Dismiss loading toast
      toast.dismiss(loadingToast);
      
      console.error('Unexpected error:', error);
      toast.error('An unexpected error occurred. Please try again.', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return <Step1ClientInformation />;
      case 2:
        return <Step2TransactionDetails />;
      case 3:
        return <Step3SecurityWarranties />;
      case 4:
        return <Step4AdditionalProvisions />;
      case 5:
        return <Step5ExecutionDetails />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-white  flex">
      {/* Left Sidebar with Background Image */}
      <img src="/assets/pic1.png" className="max-w-[330px] h-screen w-full object-cover" alt="" />
      <div
        className=" px-10 pt-[40px]  border-r border-[#E6E6E6] relative bg-cover bg-center"
      >
        <div className="relative w-[193px] flex-shrink-0 z-10 text-[#222222] h-full flex flex-col">
          <div className="mb-8">
            <h2 className="text-[18px] font-semibold mb-4">Creation steps</h2>
            <div className="w-12 h-1 bg-orange-400 mb-8"></div>

            <div className="space-y-4">
              {steps.map((step) => (
                <button
                  key={step.id}
                  onClick={() => setCurrentStep(step.id)}
                  className="flex items-center gap-0.5 w-full text-left hover:text-black"
                >
                  <span
                    className={`text-[13px] ${currentStep === step.id ? 'text-[#000000] font-semibold' : 'text-[#737373]'
                      }`}
                  >
                    {step.id}.
                  </span>
                  <span
                    className={`text-[13px] ${currentStep === step.id ? 'text-black font-semibold' : 'text-[#737373]'
                      }`}
                  >
                    {step.title}
                  </span>
                </button>
              ))}
            </div>

            <div className="mt-[80px]">
              <button className="text-orange-400 text-sm hover:text-orange-300 transition-colors">
                See the appendices
              </button>
            </div>
          </div>


        </div>
      </div>


      {/* Right Content Area */}
      <div className="flex-1 p-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={handleBack}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
          >
            <ArrowLeftIcon className="w-4 h-4" />
            {currentStep === 1 ? 'Return to contracts' : 'Back'}
          </button>

          <h1 className="text-3xl font-bold text-gray-900 mb-6">Create a contract</h1>

          {/* Step Indicator */}
          <div className="grid grid-cols-5 gap-2 mb-8">
            {[...Array(5)].map((_, index) => (
              <div
                key={index}
                className={`h-2 rounded-full w-full transition-all duration-300 ${index === currentStep - 1 ? "bg-orange-500" : "bg-gray-200"
                  }`}
              ></div>
            ))}
          </div>


        </div>

        {/* Form Content */}
        <div className="  ">
          {renderStepContent()}
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-end mt-8">
          {currentStep < 5 ? (
            <Button
              onClick={handleNext}
              className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-2"
            >
              {currentStep === 1 ? 'Validate the step' :
                currentStep === 2 ? 'Go to next step' :
                  currentStep === 3 ? 'Confirm Information' :
                    'Proceed to final step'}
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-2"
            >
              Generate the smart contract
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export const NewContractPage = (): JSX.Element => {
  return (
    <ContractFormProvider>
      <NewContractPageContent />
    </ContractFormProvider>
  );
};