import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDownIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { useCounterparty } from "../contexts/CounterpartyContext";
import { useAuth } from "../contexts/AuthContext";

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { counterparties } = useCounterparty();
  const { login, loading, error } = useAuth();
  const [selectedCounterparty, setSelectedCounterparty] = useState<string>("");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleLogin = async () => {
    if (!selectedCounterparty) {
      alert("Please select a counterparty");
      return;
    }

    if (!counterparties || !Array.isArray(counterparties)) {
      alert("Counterparties not loaded yet. Please try again.");
      return;
    }

    const counterparty = counterparties.find(cp => cp.id === selectedCounterparty);
    if (counterparty) {
      const success = await login(counterparty);
      if (success) {
        navigate("/");
      }
    } else {
      alert("Selected counterparty not found");
    }
  };

  const handleCounterpartySelect = (counterpartyId: string) => {
    setSelectedCounterparty(counterpartyId);
    setIsDropdownOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-gray-800 rounded-lg flex items-center justify-center">
            <img 
              src="/66aa5a053038ebef7d393fa4-colfi-2-3.png" 
              alt="COLFI Logo" 
              className="w-10 h-10 object-contain"
            />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-2xl font-bold text-center text-gray-900 mb-8">
          Login to COLFI
        </h1>

        {/* Counterparty Dropdown */}
        <div className="relative mb-6">
          <button
            type="button"
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-white text-left focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent hover:border-gray-400 transition-colors"
          >
            <span className={selectedCounterparty ? "text-gray-900" : "text-gray-500"}>
              {selectedCounterparty && counterparties && Array.isArray(counterparties)
                ? counterparties.find(cp => cp.id === selectedCounterparty)?.name || "Select a counterparty"
                : "Select a counterparty"
              }
            </span>
            <ChevronDownIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          </button>

          {/* Dropdown Menu */}
          {isDropdownOpen && (
            <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
              {!counterparties || !Array.isArray(counterparties) || counterparties.length === 0 ? (
                <div className="px-4 py-3 text-gray-500 text-center">
                  No counterparties available
                </div>
              ) : (
                counterparties.map((counterparty) => (
                  <button
                    key={counterparty.id}
                    type="button"
                    onClick={() => handleCounterpartySelect(counterparty.id)}
                    className="w-full px-4 py-3 text-left hover:bg-gray-50 focus:outline-none focus:bg-gray-50 transition-colors"
                  >
                    <div className="font-medium text-gray-900">{counterparty.name}</div>
                    <div className="text-sm text-gray-500">ID: {counterparty.id}</div>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        {/* Login Button */}
        <Button
          onClick={handleLogin}
          disabled={loading}
          className="w-full bg-black text-white py-3 rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Logging in...
            </>
          ) : (
            'Login'
          )}
        </Button>

        {/* Status Indicators */}
        <div className="mt-8 flex justify-center space-x-8">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Server</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Blockchain</span>
          </div>
        </div>
      </div>
    </div>
  );
};
