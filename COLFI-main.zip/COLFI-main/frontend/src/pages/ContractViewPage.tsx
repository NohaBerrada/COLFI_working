import { useState, useEffect } from "react";
import { ArrowLeftIcon, SearchIcon, AlertTriangleIcon, EyeIcon, TargetIcon, SettingsIcon, TrashIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { getAllContracts, deleteContract } from "../utils/backendApi";
import { useNavigate } from "react-router-dom";
import { useCounterparty } from "../contexts/CounterpartyContext";
import { useAuth } from "../contexts/AuthContext";

interface ContractDisplayData {
  id: string;
  originalId: string; // Store the original contract ID from backend
  legalEntity: string;
  logo: string;
  assetType: string;
  tradeDate: string;
  maturityDate: string;
  nominalValue: string;
  marketValue: string;
  quantity: string;
}

export const ContractViewPage = (): JSX.Element => {
  const navigate = useNavigate();
  const { counterparties } = useCounterparty();
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode] = useState<'detailed' | 'tracking' | 'chart'>('detailed');
  const [contracts, setContracts] = useState<ContractDisplayData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deletingContractId, setDeletingContractId] = useState<string | null>(null);

  // Fetch contracts from backend
  useEffect(() => {
    const fetchContracts = async () => {
      try {
        setLoading(true);
        setError(null);
        const result = await getAllContracts();
        
        if (result.success && result.data) {
          // Handle the actual API response structure
          let contractsData;
          if (result.data.data && Array.isArray(result.data.data)) {
            // API returns { status: "success", data: [...] }
            contractsData = result.data.data;
          } else if (Array.isArray(result.data)) {
            // Direct array response
            contractsData = result.data;
          } else {
            // Single contract object
            contractsData = [result.data];
          }
          
          // Filter contracts by logged-in user's ID (contractOwner) OR name (legalName)
          const userContracts = contractsData.filter((contract: any) => {
            return contract.contractOwner === currentUser?.id || contract.legalName === currentUser?.name;
          });
          
          console.log('Filtered contracts for user:', currentUser?.id, userContracts);
          
          const transformedContracts = userContracts.map((contract: any, index: number) => {
            // Generate contract ID starting with C_00, C_01, C_02, etc.
            const contractId = `C_${String(index).padStart(2, '0')}`;
            
            // Safely get legal name and create logo
            const legalName = contract.legalName || 'Unknown Company';
            const counterparty = counterparties.find(cp => cp.name === legalName);
            const logo = counterparty?.logo || `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${legalName.charAt(0)}`;
            
            // Get nominal value - use transactionAmount as the base value
            const nominalValue = contract.transactionAmount || contract.nominalValue || 0;
            const quantityStr = contract.quantity || '1';
            
            // Parse quantity - handle both clean numbers and strings with text
            let quantity = 1;
            if (quantityStr) {
              // If it's already a clean number string, parse it directly
              if (/^\d+$/.test(quantityStr.trim())) {
                quantity = parseFloat(quantityStr);
              } else {
                // Extract numeric value from quantity string (e.g., "100 shares" -> 100)
                const quantityMatch = quantityStr.match(/(\d+)/);
                quantity = quantityMatch ? parseFloat(quantityMatch[1]) : 1;
              }
            }
            
            // Debug logging
            console.log(`Contract ${legalName}:`, {
              transactionAmount: contract.transactionAmount,
              nominalValue: contract.nominalValue,
              quantity: contract.quantity,
              quantityStr: quantityStr,
              parsedNominalValue: nominalValue,
              parsedQuantity: quantity,
              calculatedMarketValue: nominalValue * quantity
            });
            
            // Market value should be nominalValue * quantity
            const marketValue = (nominalValue * quantity).toLocaleString();
            
            // Format dates
            const formatDate = (dateString: string) => {
              if (!dateString) return '';
              try {
                const date = new Date(dateString);
                if (isNaN(date.getTime())) return dateString; // Return original if invalid
                return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
              } catch {
                return dateString; // Return original if parsing fails
              }
            };
            
            return {
              id: contractId, // Display ID for UI
              originalId: contract.id || contract._id || contractId, // Original ID from backend
              legalEntity: legalName,
              logo: logo,
              assetType: contract.assetType || 'Unknown',
              tradeDate: formatDate(contract.effectiveDateOfContract),
              maturityDate: formatDate(contract.maturityDate || ''),
              nominalValue: nominalValue.toLocaleString(),
              marketValue: `${marketValue} USD`,
              quantity: quantity.toLocaleString()
            };
          });
          
          setContracts(transformedContracts);
        } else {
          setError(result.error || 'Failed to fetch contracts');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchContracts();
  }, [counterparties, currentUser]);

  const filteredContracts = contracts.filter((contract) => {
    const matchesSearch = contract.legalEntity.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contract.assetType.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const handleDeleteContract = async (contractId: string) => {
    console.log('Deleting contract:', contractId);
    if (!window.confirm('Are you sure you want to delete this contract? This action cannot be undone.')) {
      return;
    }

    try {
      setDeletingContractId(contractId);
      
      // Find the contract to get its original ID
      const contract = contracts.find(c => c.id === contractId);
      if (!contract) {
        console.error('Contract not found');
        alert('Contract not found. Please try again.');
        return;
      }
      
      console.log('Using original ID for deletion:', contract.originalId);
      const result = await deleteContract(contract.originalId);
      
      if (result.success) {
        // Remove the contract from the local state
        setContracts(prev => prev.filter(c => c.id !== contractId));
        console.log('Contract deleted successfully');
      } else {
        console.error('Failed to delete contract:', result.error);
        alert('Failed to delete contract. Please try again.');
      }
    } catch (error) {
      console.error('Error deleting contract:', error);
      alert('An error occurred while deleting the contract. Please try again.');
    } finally {
      setDeletingContractId(null);
    }
  };



  const renderChartView = () => {
    return (
      <div className="space-y-6">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-6">
          <span>List of clients</span>
          <span className="text-gray-400">See all</span>
          <span className="text-gray-400">›</span>
          <div className="flex items-center gap-2">
            <img
              src="https://logos-world.net/wp-content/uploads/2020/12/Citi-Logo.png"
              alt="Citi Bank"
              className="w-6 h-6 object-contain"
            />
            <div>
              <span className="font-medium text-gray-900">Citi Bank</span>
              <div className="text-xs text-gray-500">Contracts</div>
            </div>
          </div>
          <span className="text-gray-400">›</span>
          <div>
            <span className="font-medium text-gray-900">Contract 1</span>
            <div className="text-xs text-green-600">Verified</div>
          </div>
        </div>

        {/* Action Icons */}
        <div className="flex justify-end gap-3 mb-6">
          <button className="p-2 hover:bg-orange-50 rounded text-orange-500">
            <div className="w-5 h-5 border-2 border-current rounded"></div>
          </button>
          <button className="p-2 hover:bg-orange-50 rounded text-orange-500">
            <SettingsIcon className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-pink-50 rounded text-pink-500">
            <TargetIcon className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-pink-50 rounded text-pink-500">
            <EyeIcon className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-pink-50 rounded text-pink-500">
            <ArrowLeftIcon className="w-5 h-5 rotate-90" />
          </button>
        </div>

        {/* Contract Valuation Chart */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-1">Contract Valuation</h3>
              <p className="text-sm text-gray-600">Operational and non-operational data</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
                <span className="text-sm text-gray-600">CSA 1</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                <span className="text-sm text-gray-600">CSA 2</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-pink-500 rounded-full"></div>
                <span className="text-sm text-gray-600">CSA 3</span>
              </div>
            </div>
          </div>

          {/* Chart Container */}
          <div className="relative h-80">
            <svg className="w-full h-full" viewBox="0 0 800 300">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="100" height="60" patternUnits="userSpaceOnUse">
                  <path d="M 100 0 L 0 0 0 60" fill="none" stroke="#f3f4f6" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Y-axis labels */}
              <text x="30" y="50" className="text-xs fill-gray-500">5000</text>
              <text x="30" y="110" className="text-xs fill-gray-500">4000</text>
              <text x="30" y="170" className="text-xs fill-gray-500">3000</text>
              <text x="30" y="230" className="text-xs fill-gray-500">2000</text>
              <text x="30" y="290" className="text-xs fill-gray-500">1000</text>

              {/* X-axis labels */}
              <text x="80" y="320" className="text-xs fill-gray-500">MAR</text>
              <text x="180" y="320" className="text-xs fill-gray-500">APR</text>
              <text x="280" y="320" className="text-xs fill-gray-500">MAY</text>
              <text x="380" y="320" className="text-xs fill-gray-500">JUN</text>
              <text x="480" y="320" className="text-xs fill-gray-500">JUL</text>
              <text x="580" y="320" className="text-xs fill-gray-500">AUG</text>
              <text x="680" y="320" className="text-xs fill-gray-500">SEP</text>
              <text x="780" y="320" className="text-xs fill-gray-500">OCT</text>

              {/* CSA 1 Line (Orange) */}
              <polyline
                fill="none"
                stroke="#fb923c"
                strokeWidth="3"
                points="80,180 180,200 280,160 380,140 480,180 580,160 680,140 780,120"
              />
              <circle cx="80" cy="180" r="4" fill="#fb923c" />
              <circle cx="180" cy="200" r="4" fill="#fb923c" />
              <circle cx="280" cy="160" r="4" fill="#fb923c" />
              <circle cx="380" cy="140" r="4" fill="#fb923c" />
              <circle cx="480" cy="180" r="4" fill="#fb923c" />
              <circle cx="580" cy="160" r="4" fill="#fb923c" />
              <circle cx="680" cy="140" r="4" fill="#fb923c" />
              <circle cx="780" cy="120" r="4" fill="#fb923c" />

              {/* CSA 2 Line (Red) */}
              <polyline
                fill="none"
                stroke="#ef4444"
                strokeWidth="3"
                points="80,220 180,240 280,200 380,180 480,220 580,200 680,180 780,160"
              />
              <circle cx="80" cy="220" r="4" fill="#ef4444" />
              <circle cx="180" cy="240" r="4" fill="#ef4444" />
              <circle cx="280" cy="200" r="4" fill="#ef4444" />
              <circle cx="380" cy="180" r="4" fill="#ef4444" />
              <circle cx="480" cy="220" r="4" fill="#ef4444" />
              <circle cx="580" cy="200" r="4" fill="#ef4444" />
              <circle cx="680" cy="180" r="4" fill="#ef4444" />
              <circle cx="780" cy="160" r="4" fill="#ef4444" />

              {/* CSA 3 Line (Pink) */}
              <polyline
                fill="none"
                stroke="#ec4899"
                strokeWidth="3"
                points="80,260 180,240 280,220 380,140 480,200 580,180 680,160 780,80"
              />
              <circle cx="80" cy="260" r="4" fill="#ec4899" />
              <circle cx="180" cy="240" r="4" fill="#ec4899" />
              <circle cx="280" cy="220" r="4" fill="#ec4899" />
              <circle cx="380" cy="140" r="4" fill="#ec4899" />
              <circle cx="480" cy="200" r="4" fill="#ec4899" />
              <circle cx="580" cy="180" r="4" fill="#ec4899" />
              <circle cx="680" cy="160" r="4" fill="#ec4899" />
              <circle cx="780" cy="80" r="4" fill="#ec4899" />
            </svg>
          </div>
        </div>

        {/* Monthly Valuation by Client Chart */}
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Monthly Valuation by Client</h3>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
                <span className="text-sm text-gray-600">Product: <strong>Bond</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-pink-500 rounded-full"></div>
                <span className="text-sm text-gray-600">Year: <strong>2024</strong></span>
              </div>
              <div className="text-sm text-gray-600">
                Collateral Eligibility: <span className="text-green-600 font-medium">Yes</span>
              </div>
            </div>
          </div>

          {/* Chart Container */}
          <div className="relative h-80">
            <svg className="w-full h-full" viewBox="0 0 800 300">
              {/* Grid lines */}
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Y-axis labels */}
              <text x="30" y="50" className="text-xs fill-gray-500">5000</text>
              <text x="30" y="110" className="text-xs fill-gray-500">4000</text>
              <text x="30" y="170" className="text-xs fill-gray-500">3000</text>
              <text x="30" y="230" className="text-xs fill-gray-500">2000</text>
              <text x="30" y="290" className="text-xs fill-gray-500">1000</text>

              {/* X-axis labels */}
              <text x="80" y="320" className="text-xs fill-gray-500">MAR</text>
              <text x="180" y="320" className="text-xs fill-gray-500">APR</text>
              <text x="280" y="320" className="text-xs fill-gray-500">MAY</text>
              <text x="380" y="320" className="text-xs fill-gray-500">JUN</text>
              <text x="480" y="320" className="text-xs fill-gray-500">JUL</text>
              <text x="580" y="320" className="text-xs fill-gray-500">AUG</text>
              <text x="680" y="320" className="text-xs fill-gray-500">SEP</text>
              <text x="780" y="320" className="text-xs fill-gray-500">OCT</text>

              {/* Single Pink Line */}
              <polyline
                fill="none"
                stroke="#ec4899"
                strokeWidth="3"
                points="80,280 180,240 280,220 380,140 480,200 580,180 680,160 780,80"
              />
              <circle cx="80" cy="280" r="4" fill="#ec4899" />
              <circle cx="180" cy="240" r="4" fill="#ec4899" />
              <circle cx="280" cy="220" r="4" fill="#ec4899" />
              <circle cx="380" cy="140" r="4" fill="#ec4899" />
              <circle cx="480" cy="200" r="4" fill="#ec4899" />
              <circle cx="580" cy="180" r="4" fill="#ec4899" />
              <circle cx="680" cy="160" r="4" fill="#ec4899" />
              <circle cx="780" cy="80" r="4" fill="#ec4899" />
            </svg>
          </div>
        </div>
      </div>
    );
  };

  // Loading screen
  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading contracts...</p>
        </div>
      </div>
    );
  }

  // Error screen
  if (error) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 mb-4">
            <AlertTriangleIcon className="w-12 h-12 mx-auto" />
          </div>
          <p className="text-gray-600 mb-4">Error loading contracts: {error}</p>
          <Button onClick={() => window.location.reload()} className="bg-orange-500 hover:bg-orange-600">
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-gray-600 hover:text-gray-900"
            onClick={() => navigate('/customers')}
          >
            <ArrowLeftIcon className="w-4 h-4 mr-2" />
            See all clients
          </Button>
        </div>

        {/* Title */}
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 mb-6">All Contracts</h1>
        </div>

        {/* Search and View Toggle */}
        <div className="flex items-center justify-between">
          <div className="relative max-w-[530px] w-full">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search for a contract"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-[#F4F8FA]  border-none"
            />
          </div>
          
        </div>

        {/* Content based on view mode */}
        {viewMode === 'chart' ? (
          renderChartView()
        ) : (
          <div className="bg-transparent rounded-lg    overflow-hidden max-w-full">
            <div className="overflow-x-auto max-w-full">
              <table className="w-full">
                {viewMode === 'tracking' ? (
                  <thead className="  border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Contract ID
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Legal Entity/Counterparty
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Entity London
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Wharehouse
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Back Office
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Client
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Final settlement
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                ) : (
                  <thead className=" bg-transparent border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Contract ID
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Legal Entity/Counterparty
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Type of Asset
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Trade Date
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Maturity Date
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Nominal Value
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Market Value
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Quantity
                      </th>
                      <th className="px-6 py-3 text-left text-[11px] truncate font-medium text-black uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                )}
                <tbody className="bg-transparent divide-y divide-gray-200">
                  {filteredContracts.map((contract) => (
                    viewMode === 'tracking' ? (
                      <tr key={contract.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {contract.id}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-3">
                            <img
                              src={contract.logo}
                              alt={contract.legalEntity}
                              className="w-6 h-6 object-contain"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${contract.legalEntity.charAt(0)}`;
                              }}
                            />
                            <span className="text-sm text-gray-900">{contract.legalEntity}</span>
                          </div>
                        </td>
                        {/* Timeline Progress Columns */}
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col items-center relative">
                            <div className="w-4 h-4 bg-pink-500 rounded-full mb-2 z-10 relative"></div>
                            {/* Connecting line to next milestone */}
                            <div className="absolute top-2 left-1/2 w-[calc(100%+3rem)] h-1 bg-pink-400"></div>
                            <span className="text-xs text-pink-600">23/10/2024</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col items-center relative">
                            <div className="w-4 h-4 bg-pink-500 rounded-full mb-2 z-10 relative"></div>
                            {/* Connecting line to next milestone */}
                            <div className="absolute top-2 left-1/2 w-[calc(100%+3rem)] h-1 bg-pink-400"></div>
                            <span className="text-xs text-pink-600">23/10/2024</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col items-center relative">
                            <div className="w-4 h-4 bg-pink-500 rounded-full mb-2 z-10 relative"></div>
                            {/* Connecting line to next milestone */}
                            <div className="absolute top-2 left-1/2 w-[calc(100%+3rem)] h-1 bg-pink-400"></div>
                            <span className="text-xs text-pink-600">24/10/2024</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col items-center relative">
                            <div className="w-4 h-4 bg-pink-200 rounded-full mb-2 z-10 relative"></div>
                            {/* Connecting line to next milestone */}
                            <div className="absolute top-2 left-1/2 w-[calc(100%+3rem)] h-1 bg-pink-300"></div>
                            <span className="text-xs text-pink-300">25/10/2024</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col items-center relative">
                            <div className="w-4 h-4 bg-pink-200 rounded-full mb-2 z-10 relative"></div>
                            {/* No connecting line for the last milestone */}
                            <span className="text-xs text-pink-300">25/10/2024</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                          <div className="flex items-center justify-center">
                            {/* Action menu disabled - shows nothing when clicked */}
                          </div>
                        </td>
                      </tr>
                    ) : (
                      <tr key={contract.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {contract.id}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-3">
                            <img
                              src={contract.logo}
                              alt={contract.legalEntity}
                              className="w-6 h-6 object-contain"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${contract.legalEntity.charAt(0)}`;
                              }}
                            />
                            <span className="text-sm text-gray-900">{contract.legalEntity}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {contract.assetType}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-pink-600 font-bold">
                          {contract.tradeDate}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 font-bold">
                          {contract.maturityDate}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-bold">
                          {contract.nominalValue}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="bg-[#FCE9F3] py-[3px] px-[5px]  rounded-[6px] text-sm font-medium text-pink-600">

                            {contract.marketValue}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {contract.quantity}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                          <div className="flex items-center justify-center">
                            <Button
                              onClick={() => handleDeleteContract(contract.id)}
                              disabled={deletingContractId === contract.id}
                              variant="ghost"
                              size="sm"
                              className="text-red-600 hover:text-red-800 hover:bg-red-50"
                            >
                              {deletingContractId === contract.id ? (
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
                              ) : (
                                <TrashIcon className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        </td>
                      </tr>
                    )
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Bottom Form Section - only show for table views */}
        {viewMode !== 'chart' && (
          <div className="bg-pink-50 rounded-lg p-6">
            <div className="flex justify-center items-center">
              <div>
                <label className="block text-sm font-medium text-[#E02787] mb-2 text-center">
                  Operation
                </label>
                <Button
                  className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-3 text-lg font-medium"
                  onClick={() => navigate('/new-contract')}
                >
                  Create a contract
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};