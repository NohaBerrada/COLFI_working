import React, { useState, useRef } from "react";
import { PlusIcon, SearchIcon, ChevronUpIcon, ChevronDownIcon, XIcon, ChevronLeftIcon, ChevronRightIcon, UploadIcon, ImageIcon } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { useCounterparty } from "../contexts/CounterpartyContext";
import { toast } from "react-toastify";
import { uploadImageToIPFS, getIPFSUrl } from "../utils/pinataApi";

export const CounterpartyManagementPage: React.FC = () => {
  const { counterparties, loading, error, addCounterparty, removeCounterparty } = useCounterparty();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState<"id" | "name" | "logo">("id");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newCounterparty, setNewCounterparty] = useState({ id: "", name: "", logo: "" });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [isRemoving, setIsRemoving] = useState<string | null>(null);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(9);

  const filteredCounterparties = counterparties.filter(
    (counterparty) =>
      counterparty.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      counterparty.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const sortedCounterparties = [...filteredCounterparties].sort((a, b) => {
    let aValue: string;
    let bValue: string;
    
    if (sortField === "logo") {
      // For logo field, sort by whether logo exists or not
      aValue = a.logo ? "1" : "0";
      bValue = b.logo ? "1" : "0";
    } else {
      aValue = a[sortField].toLowerCase();
      bValue = b[sortField].toLowerCase();
    }
    
    if (sortDirection === "asc") {
      return aValue.localeCompare(bValue);
    } else {
      return bValue.localeCompare(aValue);
    }
  });

  // Pagination calculations
  const totalPages = Math.ceil(sortedCounterparties.length / rowsPerPage);
  const startIndex = (currentPage - 1) * rowsPerPage;
  const endIndex = startIndex + rowsPerPage;
  const paginatedCounterparties = sortedCounterparties.slice(startIndex, endIndex);

  // Reset to first page when search changes
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, rowsPerPage]);

  const handleSort = (field: "id" | "name" | "logo") => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const SortIcon = ({ field }: { field: "id" | "name" | "logo" }) => {
    if (sortField !== field) {
      return <ChevronUpIcon className="w-4 h-4 opacity-50" />;
    }
    return sortDirection === "asc" ? 
      <ChevronUpIcon className="w-4 h-4" /> : 
      <ChevronDownIcon className="w-4 h-4" />;
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      // Auto-upload the image
      await handleImageUploadWithFile(file);
    }
  };

  const handleImageUploadWithFile = async (file: File) => {
    setUploadingImage(true);
    try {
      const result = await uploadImageToIPFS(file);
      
      if (result.success && result.data) {
        setNewCounterparty(prev => ({ ...prev, logo: result.data!.IpfsHash }));
        toast.success("Image uploaded successfully!");
      } else {
        toast.error(result.error || "Failed to upload image");
      }
    } catch (error) {
      toast.error("Failed to upload image");
    } finally {
      setUploadingImage(false);
    }
  };

  const handleImageUpload = async () => {
    if (!selectedFile) return;
    await handleImageUploadWithFile(selectedFile);
  };

  // Helper function to get the correct logo URL
  const getLogoUrl = (logo: string | undefined): string | undefined => {
    if (!logo || !logo.trim()) return undefined;
    // If it's already a full URL, return as is
    if (logo.startsWith('http')) return logo;
    // If it's a hash, convert to IPFS URL
    return getIPFSUrl(logo);
  };

  const handleAddCounterparty = async () => {
    if (!newCounterparty.id.trim() || !newCounterparty.name.trim()) {
      toast.error("Please fill in both ID and Name");
      return;
    }

    setIsAdding(true);
    try {
      const counterpartyData = {
        id: newCounterparty.id.trim().toUpperCase(),
        name: newCounterparty.name.trim(),
        logo: newCounterparty.logo && newCounterparty.logo.trim() ? getIPFSUrl(newCounterparty.logo) : undefined
      };
      
      await addCounterparty(counterpartyData);
      setNewCounterparty({ id: "", name: "", logo: "" });
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      setIsAddModalOpen(false);
      toast.success("Counterparty added successfully");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add counterparty");
    } finally {
      setIsAdding(false);
    }
  };

  const handleRemoveCounterparty = async (id: string) => {
    if (window.confirm(`Are you sure you want to remove counterparty "${id}"?`)) {
      setIsRemoving(id);
      try {
        await removeCounterparty(id);
        toast.success("Counterparty removed successfully");
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Failed to remove counterparty");
      } finally {
        setIsRemoving(null);
      }
    }
  };

  // Pagination handlers
  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleRowsPerPageChange = (newRowsPerPage: number) => {
    setRowsPerPage(newRowsPerPage);
    setCurrentPage(1); // Reset to first page
  };

  // Show loading state
  if (loading) {
    return (
      <div className="p-8 bg-white min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading counterparties...</p>
        </div>
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="p-8 bg-white min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-600 mb-4">
            <svg className="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.5 0L4.268 19.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Error Loading Counterparties</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button 
            onClick={() => window.location.reload()}
            className="bg-black text-white hover:bg-gray-800"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 bg-white min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">
          Counterparty Management
        </h1>
        
        {/* Search and Add Button */}
        <div className="flex justify-between items-center">
          <div className="relative w-96">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Search by ID or name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <Button 
            onClick={() => setIsAddModalOpen(true)}
            className="bg-black text-white px-6 py-2 rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-2"
          >
            <PlusIcon className="w-5 h-5" />
            Add New Counterparty
          </Button>
        </div>
      </div>

      {/* Counterparties List */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-100 rounded flex items-center justify-center">
              <svg className="w-4 h-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
              </svg>
            </div>
            Counterparties List
          </h2>
        </div>
        
        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-left">
                  <button
                    onClick={() => handleSort("id")}
                    className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                  >
                    ID
                    <SortIcon field="id" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    onClick={() => handleSort("name")}
                    className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                  >
                    Name
                    <SortIcon field="name" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-gray-700">
                    Logo
                  </span>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-gray-700">
                    Actions
                  </span>
                </th>
              </tr>
            </thead>
                <tbody className="divide-y divide-gray-200">
                  {paginatedCounterparties.map((counterparty) => (
                <tr key={counterparty.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {counterparty.id}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {counterparty.name}
                  </td>
                  <td className="px-6 py-4">
                    {counterparty.logo ? (
                      <div className="flex items-center">
                        <img
                          src={getLogoUrl(counterparty.logo)}
                          alt={`${counterparty.name} logo`}
                          className="w-8 h-8 rounded-full object-cover border border-gray-200"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            target.nextElementSibling?.classList.remove('hidden');
                          }}
                        />
                        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center hidden">
                          <ImageIcon className="w-4 h-4 text-gray-400" />
                        </div>
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                        <ImageIcon className="w-4 h-4 text-gray-400" />
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    <button
                      onClick={() => handleRemoveCounterparty(counterparty.id)}
                      disabled={isRemoving === counterparty.id}
                      className="text-red-600 hover:text-red-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      title="Remove counterparty"
                    >
                      {isRemoving === counterparty.id ? (
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
                      ) : (
                        <XIcon className="w-4 h-4" />
                      )}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination Controls */}
      <div className="mt-6 flex items-center justify-between">
        {/* Rows per page */}
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-700">Rows per page</span>
          <select
            value={rowsPerPage}
            onChange={(e) => handleRowsPerPageChange(Number(e.target.value))}
            className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value={5}>5</option>
            <option value={9}>9</option>
            <option value={15}>15</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
        </div>

        {/* Page navigation */}
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
            className="flex items-center space-x-1 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronLeftIcon className="w-4 h-4" />
            <span>Previous</span>
          </Button>
          
          <span className="text-sm text-gray-700 px-3">
            Page {currentPage} of {totalPages}
          </span>
          
          <Button
            variant="outline"
            size="sm"
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
            className="flex items-center space-x-1 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span>Next</span>
            <ChevronRightIcon className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Add Counterparty Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold mb-4">Add New Counterparty</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ID
                </label>
                <Input
                  type="text"
                  placeholder="Enter counterparty ID (e.g., BNP)"
                  value={newCounterparty.id}
                  onChange={(e) => setNewCounterparty(prev => ({ ...prev, id: e.target.value }))}
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Name
                </label>
                <Input
                  type="text"
                  placeholder="Enter counterparty name (e.g., BNP Paribas)"
                  value={newCounterparty.name}
                  onChange={(e) => setNewCounterparty(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Logo (Optional)
                </label>
                <div className="space-y-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <div className="flex items-center space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center space-x-2"
                    >
                      <UploadIcon className="w-4 h-4" />
                      <span>Choose Image</span>
                    </Button>
                    {selectedFile && (
                      <Button
                        type="button"
                        onClick={handleImageUpload}
                        disabled={uploadingImage}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        {uploadingImage ? "Uploading..." : "Upload"}
                      </Button>
                    )}
                  </div>
                  {selectedFile && !newCounterparty.logo && (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        Selected: {selectedFile.name}
                      </p>
                      <div className="flex items-center space-x-2">
                        <img
                          src={URL.createObjectURL(selectedFile)}
                          alt="Selected logo preview"
                          className="w-8 h-8 rounded-full object-cover border border-gray-200"
                        />
                        <span className="text-sm text-blue-600">Ready to upload</span>
                      </div>
                    </div>
                  )}
                  {newCounterparty.logo && (
                    <div className="flex items-center space-x-2">
                      <img
                        src={getIPFSUrl(newCounterparty.logo)}
                        alt="Uploaded logo"
                        className="w-8 h-8 rounded-full object-cover border border-gray-200"
                      />
                      <span className="text-sm text-green-600">✓ Logo uploaded</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddModalOpen(false);
                  setNewCounterparty({ id: "", name: "", logo: "" });
                  setSelectedFile(null);
                  if (fileInputRef.current) {
                    fileInputRef.current.value = "";
                  }
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddCounterparty}
                disabled={isAdding}
                className="bg-black text-white hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isAdding ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Adding...
                  </>
                ) : (
                  'Add Counterparty'
                )}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
