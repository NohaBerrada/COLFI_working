'use client';
import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import { useSearch } from "../../hooks/useSearch";
import {
  mockCustomers,
  mockContracts,
  mockCollateralAssets,
  mockOperations,
} from "../../data/mockData";
import { HeaderSection } from "./sections/HeaderSection/HeaderSection";
import { SidebarMenuSection } from "./sections/SidebarMenuSection/SidebarMenuSection";

interface VueCollateralProps {
  children: React.ReactNode;
}

export const VueCollateral = ({ children }: VueCollateralProps): JSX.Element => {
  const location = useLocation();
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(true);

  // ✅ detect if we're on /new-contract
  const isNewContractPage = location.pathname === "/new-contract";

  // Determine which data to search based on current route
  const getSearchData = () => {
    switch (location.pathname) {
      case "/customers":
        return { data: mockCustomers, fields: ["name", "email"] as const };
      case "/contracts":
        return { data: mockContracts, fields: ["title", "customer"] as const };
      case "/collateral-assets":
        return { data: mockCollateralAssets, fields: ["name", "type"] as const };
      case "/operations":
        return { data: mockOperations, fields: ["type", "description"] as const };
      default:
        return null;
    }
  };

  const searchData = getSearchData();
  const { searchQuery, setSearchQuery } = useSearch(
    searchData?.data || [],
    searchData?.fields || [],
    ""
  );

  const shouldShowSearch = searchData !== null;

  const handleMenuClick = (path: string) => {
    if (isNewContractPage) return; // 🚫 don't toggle on /new-contract
    if (path === "/") {
      setIsSidebarExpanded(true); // Expand sidebar when clicking Welcome
    } else {
      setIsSidebarExpanded(false); // Collapse sidebar otherwise
    }
  };

  return (
    <div
      className={`${
        location.pathname == "/contracts" ? "bg-white" : "bg-[#f8fafb]"
      } w-full min-h-screen`}
    >
      {/* Sidebar (fixed) */}
      <SidebarMenuSection
        onMenuClick={handleMenuClick}
        isExpanded={isNewContractPage ? false : isSidebarExpanded} // ✅ force collapsed on /new-contract
      />

      {/* Main content */}
      <div
        className={`flex flex-col transition-all duration-300 ${
          isNewContractPage
            ? "ml-[80px]" // ✅ force content shift for /new-contract
            : isSidebarExpanded
              ? "ml-[237px]"
              : "ml-[80px]"
        }`}
      >
        {/* Show Header only if not on /contracts */}
        {location.pathname !== "/contracts" &&  location.pathname !== "/new-contract" && (
          <HeaderSection
            searchQuery={shouldShowSearch ? searchQuery : undefined}
            onSearchChange={shouldShowSearch ? setSearchQuery : undefined}
          />
        )}

        {children}
      </div>
    </div>
  );
};
