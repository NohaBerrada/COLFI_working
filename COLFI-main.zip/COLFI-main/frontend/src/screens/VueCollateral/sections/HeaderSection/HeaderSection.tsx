import { BellIcon, ChevronDownIcon, SearchIcon, LogOutIcon } from "lucide-react";
import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../../../contexts/AuthContext";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "../../../../components/ui/avatar";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Input } from "../../../../components/ui/input";
import { Separator } from "../../../../components/ui/separator";
import { SearchBar } from "../../../../components/SearchBar";

interface HeaderSectionProps {
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
}
export const HeaderSection = ({ 
  searchQuery = "", 
  onSearchChange 
}: HeaderSectionProps): JSX.Element => {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };
  
  const getSearchPlaceholder = () => {
    switch (location.pathname) {
      case '/customers':
        return 'Find a customer';
      case '/contracts':
        return 'Search contracts...';
      case '/collateral-assets':
        return 'Search assets...';
      case '/operations':
        return 'Search operations...';
      default:
        return 'Look for an investor, a summary...';
    }
  };

  return (
    <header className="w-full h-[111px] bg-white relative">
      <div className="flex items-center justify-between h-full px-16 max-w-[1162px] w-full mx-auto">
        <div className="relative w-[530px]">
          {onSearchChange ? (
            <SearchBar
              value={searchQuery}
              onChange={onSearchChange}
              placeholder={getSearchPlaceholder()}
            />
          ) : (
            <div className="relative">
              <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-text-input" />
              <Input
                className="w-full h-12 pl-12 pr-4 bg-input-background border-0 rounded-lg [font-family:'Montserrat',Helvetica] font-medium text-sm text-text-input placeholder:text-text-input"
                placeholder={getSearchPlaceholder()}
              />
            </div>
          )}
        </div>

        <div className="flex items-center gap-6">
          <div className="relative">
            <Button
              variant="ghost"
              size="icon"
              className="w-11 h-11 p-0 bg-[url(/group-7.png)] bg-[100%_100%]"
            >
             <img src="/bell.png" alt="" />
            </Button>
            <Badge className="absolute top-[2px] right-[5px] w-[17px] h-[17px] bg-[#e02787] hover:bg-[#e02787] text-white text-[10.2px] font-bold [font-family:'Poppins',Helvetica] rounded-[8.5px] flex items-center justify-center p-0 min-w-0">
              3
            </Badge>
          </div>

          <Separator orientation="vertical" className="h-[46px] w-px" />

          <div className="flex items-center gap-4 relative">
            <Avatar className="w-12 h-12">
              <AvatarImage src="/ellipse-1.svg" alt={currentUser?.name || "User"} />
              <AvatarFallback>
                {currentUser?.name ? currentUser.name.split(' ').map(n => n[0]).join('').toUpperCase() : 'U'}
              </AvatarFallback>
            </Avatar>

            <div className="flex flex-col">
              <div className="[font-family:'Montserrat',Helvetica] font-semibold text-black text-sm">
                {currentUser?.name || "User"}
              </div>
              <div className="[font-family:'Montserrat',Helvetica] font-medium text-[#818181] text-sm">
                {currentUser?.id || "ID"}
              </div>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="w-[18px] h-[18px] p-0"
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            >
              <ChevronDownIcon className="w-[18px] h-[18px]" />
            </Button>

            {/* Dropdown Menu */}
            {isDropdownOpen && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
                <button
                  onClick={handleLogout}
                  className="w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center gap-3 text-red-600"
                >
                  <LogOutIcon className="w-4 h-4" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
