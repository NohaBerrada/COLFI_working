import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

export const MainContentSection = (): JSX.Element => {
  const navigate = useNavigate();

  const cardData = [
    {
      title: "Customers",
      image:
        "/-freepicdownloader-com--skyscrapers-high-buildings-new-york-down.png",
      menuItems: [
        { label: "Customer list", path: "/customers" },
        { label: "Find a customer", path: "/customers" }
      ],
    },
    {
      title: "Contracts",
      image:
        "/-freepicdownloader-com--cityscape-frankfurt-downtown-sunset-germ.png",
      menuItems: [
        // { label: "Collateral management", path: "/collateral-assets" },
        { label: "Client management", path: "/counterparty-management" },
        { label: "Contracts management", path: "/contracts" },
      ],
    },
    {
      title: "Operations",
      image: "/unsplash-5fzp0ufxjmw.png",
      menuItems: [
        { label: "Create a contract", path: "/new-contract" },
      ],
    },
  ];

  const handleCardClick = (title: string) => {
    switch (title) {
      case "Customers":
        navigate("/customers");
        break;
      case "Contracts":
        navigate("/contracts");
        break;
      case "Operations":
        navigate("/operations");
        break;
    }
  };

  const handleMenuItemClick = (path: string) => {
    navigate(path);
  };

  return (
    <section className="grid grid-cols-1 lg:grid-cols-3 gap-[32px]">
      {cardData.map((card, index) => (
        <Card
          key={index}
          className="flex-1 bg-white rounded-[10px] overflow-hidden shadow-[0px_22px_55px_#00000008] border-0 hover:shadow-[0px_22px_55px_#00000015] transition-shadow cursor-pointer"
          onClick={() => handleCardClick(card.title)}
        >
          <div className="relative">
            <img
              className="w-full h-[236px] object-cover"
              alt={`${card.title} header image`}
              src={card.image}
            />
          </div>

          <CardContent className="p-0">
            <div className="pt-6 pb-8">
              <h2 className="text-center [font-family:'Montserrat',Helvetica] font-semibold text-black text-xl tracking-[0] leading-[normal] mb-8">
                {card.title}
              </h2>

              <nav className="px-8">
                <ul className="flex flex-col gap-2">
                  {card.menuItems.map((item, itemIndex) => (
                    <li key={itemIndex}>
                      <button
                        className="w-full flex items-center text-[13px] font-medium justify-between py-2 group hover:bg-gray-50 transition-colors rounded-md px-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMenuItemClick(item.path);
                        }}
                      >
                        <span>{item.label}</span>
                        <ChevronRightIcon className="w-5 h-5 text-black group-hover:translate-x-1 transition-transform" />
                      </button>
                      {itemIndex < card.menuItems.length - 1 && (
                        <Separator className="my-2" />
                      )}
                    </li>
                  ))}
                </ul>
              </nav>
            </div>
          </CardContent>
        </Card>
      ))}
    </section>
  );
};
