import {
  BuildingIcon,
  FileTextIcon,
  HomeIcon,
  UsersIcon,
  LayersIcon,
  UserCheckIcon,
} from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "../../../../components/ui/button";
import { MenuItem } from "../../../../types";

interface SidebarMenuSectionProps {
  onMenuClick?: (path: string) => void;
  isExpanded?: boolean;
}

const mainMenuItems: MenuItem[] = [
  {
    id: "welcome",
    label: "Welcome",
    icon: HomeIcon,
    isActive: false,
    path: "/",
  },
  {
    id: "customers",
    label: "Customers",
    icon: UsersIcon,
    isActive: false,
    path: "/customers",
  },
  // {
  //   id: "collateral-management",
  //   label: "Collateral Assets",
  //   icon: BuildingIcon,
  //   isActive: false,
  //   path: "/collateral-management",
  // },
  {
    id: "contracts-management",
    label: "Contracts",
    icon: FileTextIcon,
    isActive: false,
    path: "/contracts",
  },
];

const administrationMenuItems: MenuItem[] = [
  {
    id: "underlying-management",
    label: "Underlying Management",
    icon: LayersIcon,
    isActive: false,
    path: "/underlying-management",
  },
  {
    id: "counterparty-management",
    label: "Counterparty Management",
    icon: UserCheckIcon,
    isActive: false,
    path: "/counterparty-management",
  },
];

export const SidebarMenuSection = ({
  onMenuClick,
  isExpanded = true,
}: SidebarMenuSectionProps): JSX.Element => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleMenuClick = (path: string) => {
    onMenuClick?.(path);
    navigate(path);
  };

  // ✅ check if current page is /new-contract
  const isNewContractPage = location.pathname === "/new-contract";

  return (
    <aside
      className={`
        ${isNewContractPage
          ? "w-[80px]"
          : isExpanded
            ? "w-[237px]"
            : "w-[80px]"
        }
        fixed top-0 left-0 h-screen transition-all duration-300
      `}
    >
      <nav
        className={`
          ${isNewContractPage
            ? "w-[80px]"
            : isExpanded
              ? "w-[211px]"
              : "w-[80px]"
          }
          h-full bg-[#070e27] shadow-[0px_2px_41px_#0000000a] 
          flex flex-col transition-all duration-300
        `}
      >
        {/* Logo */}
        <div
          className={`flex items-center gap-3.5 pt-[37px] pb-6 ${isExpanded && !isNewContractPage ? "pl-[38px]" : "pl-[22px]"
            }`}
        >
          <img
            className="w-[30px] h-[30px]"
            alt="COLFI Logo"
            src="/66aa5a053038ebef7d393fa4-colfi-2-3.png"
          />
          {/* Hide text if sidebar is collapsed OR /new-contract */}
          {isExpanded && !isNewContractPage && (
            <h1 className="[font-family:'Sora',Helvetica] font-bold text-white text-xl">
              COLFI
            </h1>
          )}
        </div>

        {/* BNP PARIBAS User Context */}
        {isExpanded && !isNewContractPage && (
          <div className="px-[38px] pb-8">
            {/* <p className="text-white text-sm font-medium">BNP PARIBAS</p> */}
          </div>
        )}

        {/* Main Menu */}
        <div className={`flex flex-col gap-6 ${isExpanded && !isNewContractPage ? "px-3" : "px-2"}`}>
          {mainMenuItems.map((item) => {
            const IconComponent = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => handleMenuClick(item.path)}
                className={`h-auto ${isExpanded && !isNewContractPage
                  ? "justify-start gap-4 px-4"
                  : "justify-center px-2"
                  } py-3 rounded-[11px] transition-colors duration-200
  ${isActive
                    ? "bg-[#1b1b36] text-white hover:bg-[#1b1b36]"
                    : "bg-transparent text-gray-400 hover:bg-[#1b1b36]/50 hover:text-white"
                  }`}
                title={!isExpanded || isNewContractPage ? item.label : undefined}
              >
                {item.label == 'Customers' ?
                  <img src="/Frame 12.png" alt="" /> : item.label == 'Contracts' ?
                    <img src="/Frame 13.png" alt="" /> : item.label == 'Collateral Assets' ?
                      <img src="/Frame 13.png" alt="" /> :
                        <IconComponent className="w-6 h-6" />
                }
                {isExpanded && !isNewContractPage && (
                  <span className="[font-family:'Montserrat',Helvetica] font-semibold text-base">
                    {item.label}
                  </span>
                )}
              </Button>
            );
          })}
        </div>

        {/* Administration Section */}
        {isExpanded && !isNewContractPage && (
          <div className="mt-8">
            <div className="px-[38px] pb-4">
              <h3 className="text-gray-400 text-xs font-semibold uppercase tracking-wider">
                ADMINISTRATION
              </h3>
            </div>
            <div className="flex flex-col gap-6 px-3">
              {administrationMenuItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Button
                    key={item.id}
                    variant="ghost"
                    onClick={() => handleMenuClick(item.path)}
                    className={`min-h-auto h-auto flex items-start gap-4 px-4 py-3 rounded-[11px] transition-colors duration-200
  ${isActive
                      ? "bg-[#1b1b36] text-white hover:bg-[#1b1b36]"
                      : "bg-transparent text-gray-400 hover:bg-[#1b1b36]/50 hover:text-white"
                    }`}
                  >
                    <IconComponent className="w-6 h-6" />
                    <span className="[font-family:'Montserrat',Helvetica] font-semibold text-base leading-tight whitespace-normal break-words flex-1 min-w-0">
                      {item.label}
                    </span>
                  </Button>
                );
              })}
            </div>
          </div>
        )}

        {/* Collapsed Administration Menu */}
        {(!isExpanded || isNewContractPage) && (
          <div className="mt-8 flex flex-col gap-6 px-2">
            {administrationMenuItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Button
                  key={item.id}
                  variant="ghost"
                  onClick={() => handleMenuClick(item.path)}
                  className={`h-auto justify-center px-2 py-3 rounded-[11px] transition-colors duration-200
  ${isActive
                    ? "bg-[#1b1b36] text-white hover:bg-[#1b1b36]"
                    : "bg-transparent text-gray-400 hover:bg-[#1b1b36]/50 hover:text-white"
                  }`}
                  title={item.label}
                >
                  <IconComponent className="w-6 h-6" />
                </Button>
              );
            })}
          </div>
        )}
      </nav>
    </aside>
  );
};

