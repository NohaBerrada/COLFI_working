// Finnhub API service for fetching real-time financial data
import { FINNHUB_API_KEY, FRED_API_KEY } from './config';

const FINNHUB_BASE_URL = "https://finnhub.io/api/v1";
const FRED_BASE_URL = "https://api.stlouisfed.org/fred";

// Default values for European stocks and commodities (not available in Finnhub free tier)
const DEFAULT_VALUES: Record<string, number> = {
  "TTE.PA": 51.57,  // TotalEnergies SE
  "SAN.PA": 0.66,   // Sanofi
  "XAU/USD": 3754   // Gold
};

// Fallback values for government bonds (in case FRED API fails)
const BOND_FALLBACK_VALUES: Record<string, number> = {
  "US10Y": 4.14,  // Recent 10-year Treasury yield
  "DE10Y": 2.67,  // Recent German 10-year yield
  "UK10Y": 4.64   // Recent UK 10-year yield
};

// Fallback values for FX pairs (in case forex API fails)
const FX_FALLBACK_VALUES: Record<string, number> = {
  "EUR/USD": 1.18,   // EUR/USD rate
  "GBP/USD": 1.35,   // GBP/USD rate  
  "USD/JPY": 0.0068  // USD/JPY rate (inverted for display)
};

// Symbol conversion functions
const convertSymbolForFinnhub = (symbol: string): string => {
  // Convert FX symbols: EUR/USD → EURUSD
  if (symbol.includes('/')) {
    return symbol.replace('/', '');
  }
  return symbol;
};

const getDefaultValue = (symbol: string): number | null => {
  return DEFAULT_VALUES[symbol] || null;
};

const getBondFallbackValue = (symbol: string): number | null => {
  return BOND_FALLBACK_VALUES[symbol] || null;
};

const getFxFallbackValue = (symbol: string): number | null => {
  return FX_FALLBACK_VALUES[symbol] || null;
};


// Cache for storing fetched prices
interface PriceCache {
  [symbol: string]: {
    price: number;
    timestamp: number;
    currency: string;
  };
}

const priceCache: PriceCache = {};
const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes in milliseconds

// Cache management functions
const isCacheValid = (symbol: string): boolean => {
  const cached = priceCache[symbol];
  if (!cached) return false;
  
  const now = Date.now();
  return (now - cached.timestamp) < CACHE_DURATION;
};

const getCachedPrice = (symbol: string): number | null => {
  if (isCacheValid(symbol)) {
    return priceCache[symbol].price;
  }
  return null;
};

const setCachedPrice = (symbol: string, price: number, currency: string = 'USD'): void => {
  priceCache[symbol] = {
    price,
    timestamp: Date.now(),
    currency
  };
};

const clearExpiredCache = (): void => {
  const now = Date.now();
  Object.keys(priceCache).forEach(symbol => {
    if ((now - priceCache[symbol].timestamp) >= CACHE_DURATION) {
      delete priceCache[symbol];
    }
  });
};

export interface FinnhubQuote {
  c: number;  // Current price
  d: number;  // Change
  dp: number; // Percent change
  h: number;  // High price of the day
  l: number;  // Low price of the day
  o: number;  // Open price of the day
  pc: number; // Previous close price
  t: number;  // Timestamp
}

export interface FredResponse {
  realtime_start: string;
  realtime_end: string;
  observation_start: string;
  observation_end: string;
  units: string;
  output_type: number;
  file_type: string;
  order_by: string;
  sort_order: string;
  count: number;
  offset: number;
  limit: number;
  observations: Array<{
    realtime_start: string;
    realtime_end: string;
    date: string;
    value: string;
  }>;
}

export interface FinnhubForexRates {
  base: string;
  quote: {
    [currency: string]: number;
  };
}

export interface FinnhubApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * Fetch forex rates from Finnhub API
 */
export const getForexRates = async (): Promise<FinnhubApiResponse<FinnhubForexRates>> => {
  try {
    console.log('Fetching forex rates from Finnhub...');
    const url = `${FINNHUB_BASE_URL}/forex/rates?base=USD&token=${FINNHUB_API_KEY}`;
    console.log(`Forex API URL: ${url}`);
    
    const response = await rateLimitedFetch(url);
    console.log(`Forex API response status: ${response.status} ${response.statusText}`);
    
    if (!response.ok) {
      return {
        success: false,
        error: `Forex API error: ${response.status} ${response.statusText}`
      };
    }

    const data: FinnhubForexRates = await response.json();
    console.log(`Forex API response data:`, data);
    
    return {
      success: true,
      data: data
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown forex API error'
    };
  }
};

/**
 * Get forex rate for a specific pair
 */
export const getForexRate = async (symbol: string): Promise<FinnhubApiResponse<FinnhubQuote>> => {
  // Map FX symbols to currency codes
  const fxSymbolMap: Record<string, string> = {
    "EUR/USD": "EUR",
    "GBP/USD": "GBP", 
    "USD/JPY": "JPY"
  };

  const currency = fxSymbolMap[symbol];
  if (!currency) {
    return {
      success: false,
      error: `Unsupported FX symbol: ${symbol}`
    };
  }

  try {
    const forexResult = await getForexRates();
    
    if (forexResult.success && forexResult.data) {
      const rate = forexResult.data.quote[currency];
      
      if (rate && rate > 0) {
        let displayRate = rate;
        
        // For USD/JPY, we need to invert the rate (1/rate) for proper display
        if (symbol === "USD/JPY") {
          displayRate = 1 / rate;
        }
        
        console.log(`Forex rate for ${symbol}: ${displayRate} (raw: ${rate})`);
        setCachedPrice(symbol, displayRate);
        
        return {
          success: true,
          data: {
            c: displayRate,
            d: 0,
            dp: 0,
            h: displayRate,
            l: displayRate,
            o: displayRate,
            pc: displayRate,
            t: Date.now()
          }
        };
      }
    }
    
    // If forex API fails, use fallback value
    const fallbackValue = FX_FALLBACK_VALUES[symbol];
    if (fallbackValue !== undefined) {
      console.log(`Using fallback value for ${symbol}: ${fallbackValue}`);
      setCachedPrice(symbol, fallbackValue);
      
      return {
        success: true,
        data: {
          c: fallbackValue,
          d: 0,
          dp: 0,
          h: fallbackValue,
          l: fallbackValue,
          o: fallbackValue,
          pc: fallbackValue,
          t: Date.now()
        }
      };
    }
    
    return {
      success: false,
      error: `No forex rate available for ${symbol}`
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown forex error'
    };
  }
};

/**
 * Fetch government bond data from FRED API
 */
export const getFredBondData = async (symbol: string): Promise<FinnhubApiResponse<FinnhubQuote>> => {
  // Map bond symbols to FRED series IDs
  const fredSeriesMap: Record<string, string> = {
    "US10Y": "DGS10",  // 10-Year Treasury Constant Maturity Rate
    "DE10Y": "IRLTLT01DEM156N", // Long-term government bond yields: 10-year: Main (including benchmark) for Germany
    "UK10Y": "IRLTLT01GBM156N"  // Long-term government bond yields: 10-year: Main (including benchmark) for United Kingdom
  };

  const fredSeriesId = fredSeriesMap[symbol];
  if (!fredSeriesId) {
    return {
      success: false,
      error: `No FRED series mapping for ${symbol}`
    };
  }

  try {
    console.log(`Fetching FRED data for ${symbol} (${fredSeriesId})...`);
    
    // Use CORS proxy to bypass CORS restrictions
    const fredUrl = `${FRED_BASE_URL}/series/observations?series_id=${fredSeriesId}&api_key=${FRED_API_KEY}&file_type=json&limit=1&sort_order=desc`;
    const corsProxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(fredUrl)}`;
    
    console.log(`FRED API URL: ${fredUrl}`);
    console.log(`CORS Proxy URL: ${corsProxyUrl}`);
    
    const response = await fetch(corsProxyUrl);
    console.log(`FRED API response status: ${response.status} ${response.statusText}`);
    
    if (!response.ok) {
      return {
        success: false,
        error: `FRED API error: ${response.status} ${response.statusText}`
      };
    }

    const data: FredResponse = await response.json();
    console.log(`FRED API response data:`, data);
    
    if (data.observations && data.observations.length > 0) {
      const latestObservation = data.observations[0];
      console.log(`Latest observation for ${symbol}:`, latestObservation);
      
      const value = parseFloat(latestObservation.value);
      console.log(`Parsed value for ${symbol}: ${value}`);
      
      if (!isNaN(value) && value > 0) {
        // Cache the result
        setCachedPrice(symbol, value);
        console.log(`Successfully fetched FRED data for ${symbol}: ${value}`);
        
        return {
          success: true,
          data: {
            c: value,
            d: 0,
            dp: 0,
            h: value,
            l: value,
            o: value,
            pc: value,
            t: Date.now()
          }
        };
      } else {
        console.warn(`Invalid value for ${symbol}: ${value} (isNaN: ${isNaN(value)}, > 0: ${value > 0})`);
      }
    } else {
      console.warn(`No observations found for ${symbol}`);
    }
    
    return {
      success: false,
      error: 'No valid FRED data available'
    };
  } catch (error) {
    console.warn(`FRED API failed for ${symbol}:`, error);
    
    // Don't use fallback values automatically - keep value at 0
    // Only log the error and return failure
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown FRED API error'
    };
  }
};

/**
 * Fetch real-time quote for a given symbol with caching and multiple data sources
 */
export const getQuote = async (symbol: string, forceRefresh: boolean = false): Promise<FinnhubApiResponse<FinnhubQuote>> => {
  // Check cache first (unless force refresh)
  if (!forceRefresh) {
    const cachedPrice = getCachedPrice(symbol);
    if (cachedPrice !== null) {
      console.log(`Using cached price for ${symbol}: ${cachedPrice}`);
      return {
        success: true,
        data: {
          c: cachedPrice,
          d: 0,
          dp: 0,
          h: cachedPrice,
          l: cachedPrice,
          o: cachedPrice,
          pc: cachedPrice,
          t: Date.now()
        }
      };
    }
  }

  // Check for default values (European stocks and commodities)
  const defaultValue = getDefaultValue(symbol);
  if (defaultValue !== null) {
    console.log(`Using default value for ${symbol}: ${defaultValue}`);
    setCachedPrice(symbol, defaultValue);
    return {
      success: true,
      data: {
        c: defaultValue,
        d: 0,
        dp: 0,
        h: defaultValue,
        l: defaultValue,
        o: defaultValue,
        pc: defaultValue,
        t: Date.now()
      }
    };
  }

  // Check if this is an FX pair and use forex API
  if (symbol.includes('/') && ['EUR/USD', 'GBP/USD', 'USD/JPY'].includes(symbol)) {
    console.log(`Using forex API for ${symbol}...`);
    return await getForexRate(symbol);
  }

  // Convert symbol for Finnhub (other symbols)
  const finnhubSymbol = convertSymbolForFinnhub(symbol);

  try {
    console.log(`Fetching fresh price for ${symbol} (Finnhub symbol: ${finnhubSymbol})...`);
    const response = await rateLimitedFetch(`${FINNHUB_BASE_URL}/quote?symbol=${finnhubSymbol}&token=${FINNHUB_API_KEY}`);
    
    if (!response.ok) {
      const errorMsg = `HTTP ${response.status}: ${response.statusText}`;
      console.warn(`Failed to fetch price for ${symbol}: ${errorMsg}`);
      
      // If 403 Forbidden, the symbol might not be available in free tier
      if (response.status === 403) {
        return {
          success: false,
          error: `Symbol ${symbol} not available in free tier or invalid symbol`
        };
      }
      
      return {
        success: false,
        error: errorMsg
      };
    }

    const data = await response.json();
    
    // Check if the response contains valid data
    if (data && typeof data.c === 'number' && data.c > 0) {
      // Cache the successful result
      setCachedPrice(symbol, data.c);
      console.log(`Successfully fetched and cached price for ${symbol}: ${data.c}`);
      
      return {
        success: true,
        data: data
      };
    } else {
      console.warn(`Invalid price data for ${symbol}:`, data);
      return {
        success: false,
        error: 'Invalid or missing price data'
      };
    }
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : 'Unknown error occurred';
    console.error(`Error fetching price for ${symbol}:`, errorMsg);
    return {
      success: false,
      error: errorMsg
    };
  }
};

// Rate limiting helper
let lastApiCall = 0;
const MIN_API_INTERVAL = 100; // Minimum 100ms between API calls

const rateLimitedFetch = async (url: string): Promise<Response> => {
  const now = Date.now();
  const timeSinceLastCall = now - lastApiCall;
  
  if (timeSinceLastCall < MIN_API_INTERVAL) {
    await new Promise(resolve => setTimeout(resolve, MIN_API_INTERVAL - timeSinceLastCall));
  }
  
  lastApiCall = Date.now();
  return fetch(url);
};

/**
 * Get cached prices for multiple symbols (no API calls)
 */
export const getCachedQuotes = (symbols: string[]): Record<string, FinnhubApiResponse<FinnhubQuote>> => {
  const results: Record<string, FinnhubApiResponse<FinnhubQuote>> = {};
  
  symbols.forEach(symbol => {
    const cachedPrice = getCachedPrice(symbol);
    if (cachedPrice !== null) {
      results[symbol] = {
        success: true,
        data: {
          c: cachedPrice,
          d: 0,
          dp: 0,
          h: cachedPrice,
          l: cachedPrice,
          o: cachedPrice,
          pc: cachedPrice,
          t: Date.now()
        }
      };
    } else {
      results[symbol] = {
        success: false,
        error: 'No cached price available'
      };
    }
  });
  
  return results;
};

/**
 * Fetch multiple quotes with rate limiting and caching
 */
export const getMultipleQuotes = async (symbols: string[], forceRefresh: boolean = false): Promise<Record<string, FinnhubApiResponse<FinnhubQuote>>> => {
  const results: Record<string, FinnhubApiResponse<FinnhubQuote>> = {};
  
  // First, check cache for all symbols
  if (!forceRefresh) {
    const cachedResults = getCachedQuotes(symbols);
    const symbolsNeedingFetch = symbols.filter(symbol => !cachedResults[symbol].success);
    
    // Add cached results
    Object.assign(results, cachedResults);
    
    // If all symbols are cached, return early
    if (symbolsNeedingFetch.length === 0) {
      console.log('All prices found in cache');
      return results;
    }
    
    console.log(`Found ${symbols.length - symbolsNeedingFetch.length} cached prices, fetching ${symbolsNeedingFetch.length} fresh prices`);
    symbols = symbolsNeedingFetch; // Only fetch symbols not in cache
  }
  
  // Process remaining symbols in batches of 3 (reduced from 5 to be more conservative)
  const batchSize = 3;
  const delay = 2000; // 2 second delay between batches
  
  for (let i = 0; i < symbols.length; i += batchSize) {
    const batch = symbols.slice(i, i + batchSize);
    console.log(`Processing batch ${Math.floor(i/batchSize) + 1}: ${batch.join(', ')}`);
    
    // Process batch in parallel
    const batchPromises = batch.map(async (symbol) => {
      const result = await getQuote(symbol, forceRefresh);
      return { symbol, result };
    });
    
    const batchResults = await Promise.all(batchPromises);
    
    // Add results to main results object
    batchResults.forEach(({ symbol, result }) => {
      results[symbol] = result;
    });
    
    // Add delay between batches (except for the last batch)
    if (i + batchSize < symbols.length) {
      console.log(`Waiting ${delay}ms before next batch...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  return results;
};

/**
 * Check if a symbol exists and is valid
 */
export const validateSymbol = async (symbol: string): Promise<boolean> => {
  try {
    const response = await rateLimitedFetch(`${FINNHUB_BASE_URL}/stock/profile2?symbol=${symbol}&token=${FINNHUB_API_KEY}`);
    
    if (!response.ok) {
      return false;
    }

    const data = await response.json();
    return data && data.name && data.name !== 'N/A';
  } catch (error) {
    return false;
  }
};

// Export cache management functions
export const clearAllCache = (): void => {
  Object.keys(priceCache).forEach(symbol => {
    delete priceCache[symbol];
  });
  console.log('Price cache cleared');
};

export const getCacheInfo = (): { totalEntries: number; validEntries: number; expiredEntries: number } => {
  const now = Date.now();
  let validEntries = 0;
  let expiredEntries = 0;
  
  Object.values(priceCache).forEach(cached => {
    if ((now - cached.timestamp) < CACHE_DURATION) {
      validEntries++;
    } else {
      expiredEntries++;
    }
  });
  
  return {
    totalEntries: Object.keys(priceCache).length,
    validEntries,
    expiredEntries
  };
};

// Clean up expired cache entries periodically
setInterval(clearExpiredCache, 5 * 60 * 1000); // Every 5 minutes

// Test function for debugging FRED API (can be called from browser console)
export const testFredApi = async (symbol: string = "US10Y") => {
  console.log(`Testing FRED API for ${symbol}...`);
  try {
    const result = await getFredBondData(symbol);
    console.log(`FRED API test result for ${symbol}:`, result);
    return result;
  } catch (error) {
    console.error(`FRED API test error for ${symbol}:`, error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
};

// Function to get default values for European stocks (explicit call)
export const getDefaultStockPrice = (symbol: string): FinnhubApiResponse<FinnhubQuote> => {
  const defaultValue = getDefaultValue(symbol);
  
  if (defaultValue !== null) {
    console.log(`Using default value for ${symbol}: ${defaultValue}`);
    setCachedPrice(symbol, defaultValue);
    
    return {
      success: true,
      data: {
        c: defaultValue,
        d: 0,
        dp: 0,
        h: defaultValue,
        l: defaultValue,
        o: defaultValue,
        pc: defaultValue,
        t: Date.now()
      }
    };
  }
  
  return {
    success: false,
    error: `No default value available for ${symbol}`
  };
};

// Function to get fallback values for government bonds (explicit call)
export const getBondFallbackPrice = (symbol: string): FinnhubApiResponse<FinnhubQuote> => {
  const fallbackValue = getBondFallbackValue(symbol);
  
  if (fallbackValue !== null) {
    console.log(`Using immediate fallback value for ${symbol}: ${fallbackValue}`);
    setCachedPrice(symbol, fallbackValue);
    
    return {
      success: true,
      data: {
        c: fallbackValue,
        d: 0,
        dp: 0,
        h: fallbackValue,
        l: fallbackValue,
        o: fallbackValue,
        pc: fallbackValue,
        t: Date.now()
      }
    };
  }
  
  return {
    success: false,
    error: `No fallback value available for ${symbol}`
  };
};

// Function to get fallback values for FX pairs (explicit call)
export const getFxFallbackPrice = (symbol: string): FinnhubApiResponse<FinnhubQuote> => {
  const fallbackValue = getFxFallbackValue(symbol);
  
  if (fallbackValue !== null) {
    console.log(`Using immediate fallback value for ${symbol}: ${fallbackValue}`);
    setCachedPrice(symbol, fallbackValue);
    
    return {
      success: true,
      data: {
        c: fallbackValue,
        d: 0,
        dp: 0,
        h: fallbackValue,
        l: fallbackValue,
        o: fallbackValue,
        pc: fallbackValue,
        t: Date.now()
      }
    };
  }
  
  return {
    success: false,
    error: `No fallback value available for ${symbol}`
  };
};

// Make test functions available globally for browser console testing
if (typeof window !== 'undefined') {
  (window as any).testFredApi = testFredApi;
  (window as any).getBondFallbackPrice = getBondFallbackPrice;
  (window as any).getDefaultStockPrice = getDefaultStockPrice;
  (window as any).getFxFallbackPrice = getFxFallbackPrice;
  (window as any).getForexRates = getForexRates;
}
