/**
 * Backend API integration utilities
 * Based on the backend API documentation and testCreate function
 */

const API_BASE = 'https://backend.colfi.io';

export interface BackendApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface ContractData {
  legalName: string;
  address: string;
  phone: string;
  email: string;
  contractOwner: string;
  assetType: string;
  termsAndConditionsOfTransaction?: string;
  nominalValue: number;
  quantity?: string;
  obligationDetails?: string;
  deliveryTimelines?: string;
  precedentCondition?: string;
  terminationCondition?: string;
  terminationEventDefault?: string;
  terminationNotice?: string;
  lawGoverning: string;
  jurisdictionForDispute: string;
  specificRepresentation?: string;
  representationDisclaimer?: string;
  collateralDetails?: string;
  collateralConditions?: string;
  signingAuthority?: string;
  requiredSupportingDocuments?: string;
  conditionsOfRatings?: string;
  thirdPartyInvolvementDetails?: string;
  miscellaneousClauses?: string;
  methodOfExecution?: string;
  effectiveDateOfContract: string;
  maturityDate?: string;
}

export interface Counterparty {
  id: string;
  name: string;
  logo?: string; // Full IPFS URL for the logo (e.g., https://gateway.pinata.cloud/ipfs/{hash})
}

export interface Underlying {
  id: string;
  type: string;
  name: string;
  value: number;
  currency: string;
  termsAndConditionsOfTransaction?: string;
}

export interface User {
  id: string;
  name: string;
}

/**
 * Check API health status
 */
export const checkApiHealth = async (): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/health`);
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Health check failed' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Create a new contract
 * Based on the testCreate function from backend documentation
 */
export const createContract = async (contractData: ContractData): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/contracts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(contractData)
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to create contract' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Get all contracts
 */
export const getAllContracts = async (): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/contracts`);
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to fetch contracts' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Get contract by ID
 */
export const getContractById = async (contractId: string): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/contracts/${contractId}`);
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to fetch contract' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Get contracts by email
 */
export const getContractsByEmail = async (email: string): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/contracts/email/${encodeURIComponent(email)}`);
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to fetch contracts by email' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Update contract
 */
export const updateContract = async (contractId: string, updateData: Partial<ContractData>): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/contracts/${contractId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updateData)
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to update contract' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Delete contract
 */
export const deleteContract = async (contractId: string): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/contracts/${contractId}`, {
      method: 'DELETE'
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to delete contract' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

// ===== COUNTERPARTY MANAGEMENT API =====

/**
 * Get all counterparties (users)
 */
export const getAllCounterparties = async (): Promise<BackendApiResponse<Counterparty[]>> => {
  try {
    const response = await fetch(`${API_BASE}/api/users`);
    const data = await response.json();
    
    if (response.ok) {
      // Handle different response formats
      let counterparties: Counterparty[] = [];
      
      if (Array.isArray(data)) {
        // Direct array response
        counterparties = data;
      } else if (data.data && Array.isArray(data.data)) {
        // Wrapped in data property (your backend format)
        counterparties = data.data;
      } else if (data.users && Array.isArray(data.users)) {
        // Wrapped in users property
        counterparties = data.users;
      } else if (data.counterparties && Array.isArray(data.counterparties)) {
        // Wrapped in counterparties property
        counterparties = data.counterparties;
      } else {
        // Fallback: try to use data as is if it's an object with id and name
        counterparties = [data].filter(item => item && item.id && item.name);
      }
      
      return { success: true, data: counterparties };
    } else {
      return { success: false, error: data.message || 'Failed to fetch counterparties' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Add a new counterparty
 */
export const addCounterparty = async (counterparty: Counterparty): Promise<BackendApiResponse<Counterparty>> => {
  try {
    const response = await fetch(`${API_BASE}/api/users`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(counterparty)
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data: data.user || counterparty };
    } else {
      return { success: false, error: data.message || 'Failed to add counterparty' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Remove a counterparty by ID
 */
export const removeCounterparty = async (id: string): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/users/${id}`, {
      method: 'DELETE'
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to remove counterparty' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

// ===== UNDERLYING MANAGEMENT API (using /api/assets endpoints) =====

/**
 * Get all underlyings (assets)
 */
export const getAllUnderlyings = async (): Promise<BackendApiResponse<Underlying[]>> => {
  try {
    const response = await fetch(`${API_BASE}/api/assets`);
    const data = await response.json();
    
    if (response.ok) {
      // Handle different response formats
      let underlyings: Underlying[] = [];
      
      if (Array.isArray(data)) {
        // Direct array response
        underlyings = data;
      } else if (data.data && Array.isArray(data.data)) {
        // Wrapped in data property (your backend format)
        underlyings = data.data;
      } else if (data.underlyings && Array.isArray(data.underlyings)) {
        // Wrapped in underlyings property
        underlyings = data.underlyings;
      } else {
        // Fallback: try to use data as is if it's an object with id and name
        underlyings = [data].filter(item => item && item.id && item.name);
      }
      
      // Convert string values to numbers
      const processedUnderlyings = underlyings.map(underlying => ({
        ...underlying,
        value: typeof underlying.value === 'string' ? parseFloat(underlying.value) || 0 : underlying.value
      }));
      
      return { success: true, data: processedUnderlyings };
    } else {
      return { success: false, error: data.message || 'Failed to fetch underlyings' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};

/**
 * Add a new underlying (asset)
 */
export const addUnderlying = async (underlying: Underlying): Promise<BackendApiResponse<Underlying>> => {
  try {
    const response = await fetch(`${API_BASE}/api/assets`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(underlying)
    });

    const data = await response.json();

    if (response.ok) {
      const result = data.asset || underlying;
      // Ensure value is a number
      const processedResult = {
        ...result,
        value: typeof result.value === 'string' ? parseFloat(result.value) || 0 : result.value
      };
      return { success: true, data: processedResult };
    } else {
      return { success: false, error: data.message || 'Failed to add underlying' };
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};

/**
 * Remove an underlying (asset) by ID
 */
export const removeUnderlying = async (id: string): Promise<BackendApiResponse> => {
  try {
    const response = await fetch(`${API_BASE}/api/assets/${id}`, {
      method: 'DELETE'
    });

    const data = await response.json();

    if (response.ok) {
      return { success: true, data };
    } else {
      return { success: false, error: data.message || 'Failed to remove underlying' };
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};

// ===== AUTHENTICATION API =====

/**
 * Login with user credentials
 */
export const loginUser = async (credentials: { id: string; name: string }): Promise<BackendApiResponse<User>> => {
  try {
    const response = await fetch(`${API_BASE}/api/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials)
    });
    
    const data = await response.json();
    
    if (response.ok) {
      return { success: true, data: data.user || credentials };
    } else {
      return { success: false, error: data.message || 'Login failed' };
    }
  } catch (error) {
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred' 
    };
  }
};
