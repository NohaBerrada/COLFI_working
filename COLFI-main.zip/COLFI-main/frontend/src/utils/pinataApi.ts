/**
 * Pinata IPFS API integration for uploading images
 */

import { PINATA_API_KEY } from './config';

export interface PinataResponse {
  success: boolean;
  data?: {
    IpfsHash: string;
    PinSize: number;
    Timestamp: string;
  };
  error?: string;
}

/**
 * Upload image to IPFS using Pinata API
 * @param file - The image file to upload
 * @returns Promise with IPFS hash or error
 */
export const uploadImageToIPFS = async (file: File): Promise<PinataResponse> => {
  try {
    // Validate file type
    if (!file.type.startsWith('image/')) {
      return {
        success: false,
        error: 'File must be an image'
      };
    }

    // Validate file size (max 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      return {
        success: false,
        error: 'File size must be less than 10MB'
      };
    }

    // Create form data
    const formData = new FormData();
    formData.append('file', file);

    // Add metadata
    const metadata = JSON.stringify({
      name: file.name,
      keyvalues: {
        type: 'counterparty-logo',
        uploadedAt: new Date().toISOString()
      }
    });
    formData.append('pinataMetadata', metadata);

    // Add options
    const options = JSON.stringify({
      cidVersion: 0
    });
    formData.append('pinataOptions', options);

    // Upload to Pinata
    const response = await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${PINATA_API_KEY}`
      },
      body: formData
    });

    const data = await response.json();

    if (response.ok) {
      return {
        success: true,
        data: {
          IpfsHash: data.IpfsHash,
          PinSize: data.PinSize,
          Timestamp: data.Timestamp
        }
      };
    } else {
      return {
        success: false,
        error: data.error?.details || data.error?.message || 'Failed to upload to IPFS'
      };
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};

/**
 * Get IPFS URL from hash
 * @param hash - IPFS hash
 * @returns IPFS URL
 */
export const getIPFSUrl = (hash: string): string => {
  return `https://gateway.pinata.cloud/ipfs/${hash}`;
};

/**
 * Validate IPFS hash format
 * @param hash - IPFS hash to validate
 * @returns boolean indicating if hash is valid
 */
export const isValidIPFSHash = (hash: string): boolean => {
  // Basic IPFS hash validation (starts with Qm or bafy)
  return /^(Qm[1-9A-HJ-NP-Za-km-z]{44}|bafy[a-z2-7]{56})$/.test(hash);
};
