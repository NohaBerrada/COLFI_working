import { ContractFormData } from '../contexts/ContractFormContext';
import { createContract, ContractData } from './backendApi';

/**
 * Utility functions for contract form data handling
 */

/**
 * Validates the contract form data before submission
 * @param formData - The contract form data to validate
 * @returns Object with validation result and error messages
 */
export const validateContractForm = (formData: ContractFormData): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];

  // Validate only the specified fields
  if (!formData.legalName.trim()) {
    errors.push('Legal name is required');
  }
  if (!formData.assetType.trim()) {
    errors.push('Asset type is required');
  }
  if (!formData.nominalValue.trim()) {
    errors.push('Nominal value is required');
  }
  if (!formData.quantity.trim()) {
    errors.push('Quantity is required');
  }
  if (!formData.effectiveDateOfContract.trim()) {
    errors.push('Effective date is required');
  }
  if (!formData.maturityDate.trim()) {
    errors.push('Maturity date is required');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

/**
 * Transforms contract form data for backend submission
 * @param formData - The contract form data
 * @returns Transformed data ready for API submission
 */
export const transformContractDataForBackend = (formData: ContractFormData) => {
  return {
    legalName: formData.legalName,
    address: formData.address,
    phone: formData.phone,
    email: formData.email,
    contractOwner: formData.contractOwner,
    assetType: formData.assetType,
    termsAndConditionsOfTransaction: formData.termsAndConditionsOfTransaction,
    nominalValue: parseFloat(formData.nominalValue.replace(/[^0-9.-]/g, '')) || 0,
    quantity: formData.quantity,
    obligationDetails: formData.obligationDetails,
    deliveryTimelines: formData.deliveryTimelines,
    precedentCondition: formData.precedentCondition,
    terminationCondition: formData.terminationCondition,
    terminationEventDefault: formData.terminationEventDefault,
    terminationNotice: formData.terminationNotice,
    lawGoverning: formData.lawGoverning,
    jurisdictionForDispute: formData.jurisdictionForDispute,
    specificRepresentation: formData.specificRepresentation,
    representationDisclaimer: formData.representationDisclaimer,
    collateralDetails: formData.collateralDetails,
    collateralConditions: formData.collateralConditions,
    signingAuthority: formData.signingAuthority,
    requiredSupportingDocuments: formData.requiredSupportingDocuments,
    conditionsOfRatings: formData.conditionsOfRatings,
    thirdPartyInvolvementDetails: formData.thirdPartyInvolvementDetails,
    miscellaneousClauses: formData.miscellaneousClauses,
    methodOfExecution: formData.methodOfExecution,
    effectiveDateOfContract: formData.effectiveDateOfContract,
    maturityDate: formData.maturityDate,
    lastTransactionHash: "",
    creationTransactionHash: "",
    creationTimeStamp: Date.now(),
    lastUpdateTimeStamp: Date.now()
  };
};

/**
 * Submit contract data to backend API using the new backend integration
 * @param formData - The contract form data
 * @returns Promise with submission result
 */
export const submitContractToBackend = async (formData: ContractFormData): Promise<{ success: boolean; contractId?: string; error?: string }> => {
  try {
    // Validate form data
    const validation = validateContractForm(formData);
    if (!validation.isValid) {
      return {
        success: false,
        error: `Validation failed: ${validation.errors.join(', ')}`
      };
    }

    // Transform data for backend
    console.log('Transforming contract data for backend:', formData);
    const backendData = transformContractDataForBackend(formData);
    console.log('Transformed backend data:', backendData);

    // Use the new backend API integration
    console.log('Calling createContract with data:', backendData);
    const result = await createContract(backendData as ContractData);
    console.log('Backend response:', result);
    
    if (result.success) {
      return {
        success: true,
        contractId: result.data?.contractId || result.data?.id || result.data?._id || 'Contract created successfully'
      };
    } else {
      return {
        success: false,
        error: result.error || 'Failed to create contract'
      };
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};
