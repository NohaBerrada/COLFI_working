import React from 'react';
import { Input } from '../ui/input';
import { useContractForm } from '../../contexts/ContractFormContext';

export const Step4AdditionalProvisions: React.FC = () => {
  const { formData, updateField } = useContractForm();

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Additional Provisions</h2>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Any specific conditions related to ratings or creditworthiness
          </label>
          <textarea
            value={formData.conditionsOfRatings}
            onChange={(e) => updateField('conditionsOfRatings', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-20 resize-none"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Details of any third-party involvements, such as trustees or agents
          </label>
          <Input
            value={formData.thirdPartyInvolvementDetails}
            onChange={(e) => updateField('thirdPartyInvolvementDetails', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Miscellaneous clauses, such as confidentiality, amendments, and waiver of rights
          </label>
          <textarea
            value={formData.miscellaneousClauses}
            onChange={(e) => updateField('miscellaneousClauses', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-20 resize-none"
          />
        </div>
      </div>
    </div>
  );
};
