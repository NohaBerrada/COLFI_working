import React from 'react';
import { Input } from '../ui/input';
import { DatePicker } from '../ui/datepicker';
import { useContractForm } from '../../contexts/ContractFormContext';

export const Step5ExecutionDetails: React.FC = () => {
  const { formData, updateField } = useContractForm();

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Execution Details</h2>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Method of execution
          </label>
          <Input
            value={formData.methodOfExecution}
            onChange={(e) => updateField('methodOfExecution', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Date the contract will be effective
          </label>
          <DatePicker
            value={formData.effectiveDateOfContract}
            onChange={(value) => updateField('effectiveDateOfContract', value)}
            className="bg-transparent border-[#D9D9D9]"
            format="DD/MM/YYYY"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Maturity Date
          </label>
          <DatePicker
            value={formData.maturityDate}
            onChange={(value) => updateField('maturityDate', value)}
            className="bg-transparent border-[#D9D9D9]"
            format="DD/MM/YYYY"
          />
        </div>
      </div>
    </div>
  );
};
