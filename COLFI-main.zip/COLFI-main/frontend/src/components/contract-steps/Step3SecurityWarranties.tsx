import React from 'react';
import { Input } from '../ui/input';
import { useContractForm } from '../../contexts/ContractFormContext';

export const Step3SecurityWarranties: React.FC = () => {
  const { formData, updateField } = useContractForm();

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Representations and Warranties</h2>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Specific representations each party needs to make
          </label>
          <textarea
            value={formData.specificRepresentation}
            onChange={(e) => updateField('specificRepresentation', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-20 resize-none"
          />
        </div>

        <div className="mb-8">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Any disclaimer or conditions attached to these representations
          </label>
          <Input
            value={formData.representationDisclaimer}
            onChange={(e) => updateField('representationDisclaimer', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-4">Collateral or Security (if applicable)</h3>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Details of any collateral or security required
          </label>
          <Input
            value={formData.collateralDetails}
            onChange={(e) => updateField('collateralDetails', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <div className="mb-8">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Conditions under which collateral will be called upon
          </label>
          <Input
            value={formData.collateralConditions}
            onChange={(e) => updateField('collateralConditions', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-4">Signatory Authority</h3>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Names and titles of individuals authorized to sign the contract on behalf of each party
          </label>
          <textarea
            value={formData.signingAuthority}
            onChange={(e) => updateField('signingAuthority', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-16 resize-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Any required supporting documents
          </label>
          <Input
            value={formData.requiredSupportingDocuments}
            onChange={(e) => updateField('requiredSupportingDocuments', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>
      </div>
    </div>
  );
};
