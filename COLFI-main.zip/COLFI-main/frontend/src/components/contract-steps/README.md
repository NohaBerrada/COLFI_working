# Contract Form Steps Components

This directory contains the individual step components for the contract creation form. Each component is responsible for rendering a specific step of the multi-step form and managing its own input fields through the ContractFormContext.

## Components

### Step1ClientInformation
- **Purpose**: Handles client/entity information and contact details
- **Fields**: Legal name, address, email, phone number
- **Context Fields**: `legalName`, `address`, `email`, `phone`

### Step2TransactionDetails
- **Purpose**: Manages transaction details, obligations, and legal provisions
- **Fields**: Transaction description, terms, payment details, obligations, termination conditions, governing law
- **Context Fields**: `transactionDescription`, `termsAndConditionsOfTransaction`, `transactionAmount`, `paymentTerms`, `obligationDetails`, `deliveryTimelines`, `precedentCondition`, `terminationCondition`, `terminationEventDefault`, `terminationNotice`, `lawGoverning`, `jurisdictionForDispute`

### Step3SecurityWarranties
- **Purpose**: Handles representations, warranties, and security details
- **Fields**: Representations, disclaimers, collateral details, signatory authority
- **Context Fields**: `specificRepresentation`, `representationDisclaimer`, `collateralDetails`, `collateralConditions`, `signingAuthority`, `requiredSupportingDocuments`

### Step4AdditionalProvisions
- **Purpose**: Manages additional provisions and miscellaneous clauses
- **Fields**: Creditworthiness conditions, third-party involvements, miscellaneous clauses
- **Context Fields**: `conditionsOfRatings`, `thirdPartyInvolvementDetails`, `miscellaneousClauses`

### Step5ExecutionDetails
- **Purpose**: Handles final execution details and deadlines
- **Fields**: Execution method, effective date, documentation deadlines
- **Context Fields**: `methodOfExecution`, `effectiveDateOfContract`, `deadlineForDocumentationCompletion`

## Usage

Each component automatically connects to the `ContractFormContext` and uses the `useContractForm` hook to:
- Access current form data
- Update field values through the `updateField` function

```tsx
import { Step1ClientInformation } from './contract-steps';

// In your component
<Step1ClientInformation />
```

## Context Integration

All components use the `useContractForm` hook from `ContractFormContext`:

```tsx
const { formData, updateField } = useContractForm();

// Update a field
updateField('legalName', 'New Company Name');

// Access current value
const currentValue = formData.legalName;
```

## Form Data Structure

The complete form data structure is defined in `ContractFormContext.tsx` and includes all fields from all 5 steps. The context provides:

- `formData`: Current form state
- `updateField(field, value)`: Update a single field
- `updateMultipleFields(fields)`: Update multiple fields at once
- `resetForm()`: Reset form to default values
- `getFormData()`: Get current form data

## Backend Integration

Use the utility functions in `contractFormUtils.ts` to:
- Validate form data before submission
- Transform data for backend API
- Submit contract data to backend

```tsx
import { submitContractToBackend, validateContractForm } from '../utils/contractFormUtils';

const formData = getFormData();
const result = await submitContractToBackend(formData);
```
