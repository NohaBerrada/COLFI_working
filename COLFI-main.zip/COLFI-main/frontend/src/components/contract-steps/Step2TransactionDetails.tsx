import React from 'react';
import { Input } from '../ui/input';
import { Select, SelectOption } from '../ui/select';
import { useContractForm } from '../../contexts/ContractFormContext';
import { useUnderlying } from '../../contexts/UnderlyingContext';

export const Step2TransactionDetails: React.FC = () => {
  const { formData, updateField } = useContractForm();
  const { underlyings, loading: underlyingsLoading } = useUnderlying();

  // Get unique asset types from underlyings
  const assetTypes = Array.from(new Set(underlyings.map(ul => ul.type))).filter(Boolean);
  
  // Get assets filtered by selected type
  const filteredAssets = formData.assetType 
    ? underlyings.filter(ul => ul.type === formData.assetType)
    : underlyings;

  // Handle asset name selection and update terms from data
  const handleAssetNameChange = (assetName: string) => {
    updateField('assetName', assetName);
    
    // Find the selected asset and update terms from its data
    const selectedAsset = underlyings.find(ul => ul.name === assetName);
    if (selectedAsset && selectedAsset.termsAndConditionsOfTransaction) {
      updateField('termsAndConditionsOfTransaction', selectedAsset.termsAndConditionsOfTransaction);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">Transaction Details</h2>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Type of Asset
          </label>
          <Select
            value={formData.assetType}
            onChange={(e) => updateField('assetType', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
            disabled={underlyingsLoading}
          >
            <SelectOption value="">Select asset type...</SelectOption>
            {assetTypes.map((type) => (
              <SelectOption key={type} value={type}>
                {type}
              </SelectOption>
            ))}
          </Select>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Name of Asset
          </label>
          <Select
            value={formData.assetName || ''}
            onChange={(e) => handleAssetNameChange(e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
            disabled={underlyingsLoading || !formData.assetType}
          >
            <SelectOption value="">Select asset name...</SelectOption>
            {filteredAssets.map((underlying) => (
              <SelectOption key={underlying.id} value={underlying.name}>
                {underlying.name}
              </SelectOption>
            ))}
          </Select>
        </div>


        <div className="grid grid-cols-2 gap-6 mb-8">
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Nominal Value
            </label>
            <Input
              value={formData.nominalValue}
              onChange={(e) => updateField('nominalValue', e.target.value)}
              placeholder="Enter the nominal value (e.g., 1,000,000)"
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Quantity
            </label>
            <Input
              value={formData.quantity}
              onChange={(e) => updateField('quantity', e.target.value)}
              placeholder="Enter the quantity (e.g., 100)"
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-4">Obligations of Each Party</h3>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Detailed obligations and responsibilities of each party under the contract
          </label>
          <textarea
            value={formData.obligationDetails}
            onChange={(e) => updateField('obligationDetails', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-16 resize-none"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Delivery timelines (if applicable)
          </label>
          <Input
            value={formData.deliveryTimelines}
            onChange={(e) => updateField('deliveryTimelines', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Any conditions precedent to be fulfilled before obligations are enforced
          </label>
          <textarea
            value={formData.precedentCondition}
            onChange={(e) => updateField('precedentCondition', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-16 resize-none"
          />
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-4">Termination Provisions</h3>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Conditions under which the contract can be terminated
          </label>
          <textarea
            value={formData.terminationCondition}
            onChange={(e) => updateField('terminationCondition', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-16 resize-none"
          />
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Events of default for each party
          </label>
          <textarea
            value={formData.terminationEventDefault}
            onChange={(e) => updateField('terminationEventDefault', e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 h-16 resize-none"
          />
        </div>

        <div className="mb-8">
          <label className="block text-sm font-medium text-[#787878] mb-2">
            Termination events and related notices required
          </label>
          <Input
            value={formData.terminationNotice}
            onChange={(e) => updateField('terminationNotice', e.target.value)}
            className="bg-transparent border-[#D9D9D9]"
          />
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-4">Governing Law and Jurisdiction</h3>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Specific law governing the contract
            </label>
            <Input
              value={formData.lawGoverning}
              onChange={(e) => updateField('lawGoverning', e.target.value)}
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Jurisdiction for dispute resolution
            </label>
            <Input
              value={formData.jurisdictionForDispute}
              onChange={(e) => updateField('jurisdictionForDispute', e.target.value)}
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
