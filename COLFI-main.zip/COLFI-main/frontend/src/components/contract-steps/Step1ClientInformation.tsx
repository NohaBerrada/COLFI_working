import React, { useState, useEffect } from 'react';
import { Input } from '../ui/input';
import { Select, SelectOption } from '../ui/select';
import { useContractForm } from '../../contexts/ContractFormContext';
import { useAuth } from '../../contexts/AuthContext';
import { getAllCounterparties, Counterparty } from '../../utils/backendApi';

export const Step1ClientInformation: React.FC = () => {
  const { formData, updateField } = useContractForm();
  const { currentUser } = useAuth();
  const [counterparties, setCounterparties] = useState<Counterparty[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [displayValue, setDisplayValue] = useState<string>('');

  useEffect(() => {
    const fetchCounterparties = async () => {
      try {
        setLoading(true);
        const result = await getAllCounterparties();
        if (result.success && result.data) {
          setCounterparties(result.data);
        } else {
          setError(result.error || 'Failed to fetch counterparties');
        }
      } catch (err) {
        setError('An unexpected error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchCounterparties();
  }, []);

  // Always set contractOwner to logged-in user's ID (regardless of what user types)
  useEffect(() => {
    if (currentUser?.id) {
      updateField('contractOwner', currentUser.id);
    }
  }, [currentUser, updateField]);

  // Handle input change - update display value but keep formData.contractOwner as user ID
  const handleContractOwnerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDisplayValue(e.target.value);
    // Always keep formData.contractOwner as the logged-in user's ID
    if (currentUser?.id) {
      updateField('contractOwner', currentUser.id);
    }
  };

  const handleCounterpartyChange = (counterpartyId: string) => {
    const selectedCounterparty = counterparties.find(cp => cp.id === counterpartyId);
    if (selectedCounterparty) {
      updateField('legalName', selectedCounterparty.name);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-gray-900 mb-6">General information</h2>

        <div className="grid grid-cols-2 gap-6 mb-14">
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Full legal name of the entity (or trust)
            </label>
            {loading ? (
              <div className="w-full px-3 py-2 border border-gray-200 rounded-md bg-gray-50 text-gray-500">
                Loading counterparties...
              </div>
            ) : error ? (
              <div className="w-full px-3 py-2 border border-red-200 rounded-md bg-red-50 text-red-600">
                {error}
              </div>
            ) : (
              <Select
                value={counterparties.find(cp => cp.name === formData.legalName)?.id || ''}
                onChange={(e) => handleCounterpartyChange(e.target.value)}
                className="bg-transparent border-[#D9D9D9]"
              >
                <SelectOption value="">Select a counterparty...</SelectOption>
                {counterparties.map((counterparty) => (
                  <SelectOption key={counterparty.id} value={counterparty.id}>
                    {counterparty.name}
                  </SelectOption>
                ))}
              </Select>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Address for legal notices
            </label>
            <Input
              value={formData.address}
              onChange={(e) => updateField('address', e.target.value)}
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
        </div>

        <h3 className="text-xl font-semibold text-gray-900 mb-4">Contact details</h3>

        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              E-mail address
            </label>
            <Input
              value={formData.email}
              onChange={(e) => updateField('email', e.target.value)}
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Phone number
            </label>
            <Input
              value={formData.phone}
              onChange={(e) => updateField('phone', e.target.value)}
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-[#787878] mb-2">
              Contract Owner
            </label>
            <Input
              value={displayValue}
              onChange={handleContractOwnerChange}
              className="bg-transparent border-[#D9D9D9]"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
