import React, { forwardRef } from 'react';
import { Input } from './input';

interface DatePickerProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'value' | 'onChange'> {
  value?: string;
  onChange?: (value: string) => void;
  format?: 'DD/MM/YYYY' | 'MM/DD/YYYY';
}

export const DatePicker = forwardRef<HTMLInputElement, DatePickerProps>(
  ({ value, onChange, format = 'DD/MM/YYYY', className, ...props }, ref) => {
    const formatDateForInput = (dateString: string): string => {
      if (!dateString) return '';
      
      // If it's already in DD/MM/YYYY format, convert to YYYY-MM-DD for input
      if (format === 'DD/MM/YYYY' && dateString.includes('/')) {
        const parts = dateString.split('/');
        if (parts.length === 3) {
          const [day, month, year] = parts;
          return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }
      }
      
      // If it's already in YYYY-MM-DD format, return as is
      if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
        return dateString;
      }
      
      // Try to parse as a date and convert to YYYY-MM-DD
      const date = new Date(dateString);
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
      
      return '';
    };

    const formatDateForDisplay = (dateString: string): string => {
      if (!dateString) return '';
      
      // If it's in YYYY-MM-DD format, convert to DD/MM/YYYY
      if (dateString.match(/^\d{4}-\d{2}-\d{2}$/)) {
        const [year, month, day] = dateString.split('-');
        return `${day}/${month}/${year}`;
      }
      
      // If it's already in DD/MM/YYYY format, return as is
      if (dateString.includes('/')) {
        return dateString;
      }
      
      return dateString;
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const inputValue = e.target.value;
      if (onChange) {
        // Convert from YYYY-MM-DD to DD/MM/YYYY for storage
        if (inputValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
          const [year, month, day] = inputValue.split('-');
          onChange(`${day}/${month}/${year}`);
        } else {
          onChange(inputValue);
        }
      }
    };

    return (
      <Input
        ref={ref}
        type="date"
        value={formatDateForInput(value || '')}
        onChange={handleChange}
        className={className}
        {...props}
      />
    );
  }
);

DatePicker.displayName = 'DatePicker';
