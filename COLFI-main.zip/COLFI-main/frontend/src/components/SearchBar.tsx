import React from "react";
import { SearchIcon } from "lucide-react";
import { Input } from "./ui/input";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export const SearchBar = ({ 
  value, 
  onChange, 
  placeholder = "Search...",
  className = ""
}: SearchBarProps): JSX.Element => {
  return (
    <div className={`relative ${className}`}>
      <SearchIcon className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-text-input" />
      <Input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-12 pl-12 pr-4 bg-input-background border-0 rounded-lg [font-family:'Montserrat',Helvetica] font-medium text-sm text-text-input placeholder:text-text-input"
        placeholder={placeholder}
      />
    </div>
  );
};