import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { VueCollateral } from "./screens/VueCollateral/VueCollateral";
import { WelcomePage } from "./pages/WelcomePage";
import { MasterViewPage } from "./pages/MasterViewPage";
import { ContractViewPage } from "./pages/ContractViewPage";
import { NewContractPage } from "./pages/NewContractPage";
import { CollateralAssetsPage } from "./pages/CollateralAssetsPage";
import { OperationsPage } from "./pages/OperationsPage";
import { CounterpartyManagementPage } from "./pages/CounterpartyManagementPage";
import { UnderlyingManagementPage } from "./pages/UnderlyingManagementPage";
import { LoginPage } from "./pages/LoginPage";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { AuthProvider } from "./contexts/AuthContext";
import { CounterpartyProvider } from "./contexts/CounterpartyContext";
import { UnderlyingProvider } from "./contexts/UnderlyingContext";

export const App = (): JSX.Element => {
  return (
    <Router>
      <AuthProvider>
        <CounterpartyProvider>
          <UnderlyingProvider>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <WelcomePage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/customers" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <MasterViewPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/contracts" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <ContractViewPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/new-contract" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <NewContractPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/collateral-assets" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <CollateralAssetsPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/operations" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <OperationsPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/counterparty-management" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <CounterpartyManagementPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              <Route path="/underlying-management" element={
                <ProtectedRoute>
                  <VueCollateral>
                    <UnderlyingManagementPage />
                  </VueCollateral>
                </ProtectedRoute>
              } />
              {/* <Route path="*" element={<Navigate to="/login" replace />} /> */}
            </Routes>
            <ToastContainer
              position="top-right"
              autoClose={5000}
              hideProgressBar={false}
              newestOnTop={false}
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              theme="light"
            />
          </UnderlyingProvider>
        </CounterpartyProvider>
      </AuthProvider>
    </Router >
  );
};