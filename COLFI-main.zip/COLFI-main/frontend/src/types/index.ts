export interface MenuItem {
  id: string;
  label: string;
  icon: any;
  isActive: boolean;
  path: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  status: 'active' | 'inactive';
  joinDate: string;
}

export interface Contract {
  id: string;
  title: string;
  customerName?: string;
  customer?: string;
  status: 'active' | 'pending' | 'completed';
  value: number;
  startDate: string;
  type?: 'collateral' | 'loan' | 'investment';
  riskLevel?: 'low' | 'medium' | 'high';
  endDate?: string;
}

export interface NewContractForm {
  customerId: string;
  title: string;
  type: 'collateral' | 'loan' | 'investment';
  value: number;
  startDate: string;
  endDate: string;
  collateralAssets: string[];
  riskLevel: 'low' | 'medium' | 'high';
  description: string;
  terms: string;
}

export interface CollateralAsset {
  id: string;
  name: string;
  type: string;
  value: number;
  status: 'available' | 'locked' | 'liquidated';
}

export interface Operation {
  id: string;
  type: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  createdAt: string;
}