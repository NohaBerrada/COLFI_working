import { Customer, Contract, CollateralAsset, Operation } from '../types';

export const mockBankPartners = [
  {
    id: 'HSBC-001',
    name: 'HSBC Holdings',
    type: 'Investment Bank',
    logo: '/assets/1.png',
    contractsValue: '100 M$',
    signedContracts: '4G',
    bgColor: 'bg-red-50'
  },
  {
    id: 'LLOYDS-001',
    name: 'Lloyds Banking Group',
    type: 'Bank',
    logo: '/assets/2.png',
    contractsValue: '300 M$',
    signedContracts: '24',
    bgColor: 'bg-green-50'
  },
  {
    id: 'NATWEST-001',
    name: 'NatWest Banking Group',
    type: 'Company / Bank',
    logo: '/assets/3.png',
    contractsValue: '10M$',
    signedContracts: '4',
    bgColor: 'bg-purple-50'
  },
  {
    id: 'BARCLAYS-001',
    name: 'Barclays Bank',
    type: 'Investment bank',
    logo: '/assets/4.png',
    contractsValue: '970 M$',
    signedContracts: '24',
    bgColor: 'bg-blue-50'
  },
  {
    id: 'STATE-001',
    name: 'State Street',
    type: 'Custodian',
    logo: '/assets/Frame 405.png',
    contractsValue: '90 M$',
    signedContracts: '24',
    bgColor: 'bg-blue-50'
  },
  {
    id: 'CITI-001',
    name: 'Citi Bank',
    type: 'Investment Bank',
    logo: '/assets/6.png',
    contractsValue: '550 M$',
    signedContracts: '33',
    bgColor: 'bg-red-50'
  },
  {
    id: 'BOA-001',
    name: 'Bank of America',
    type: 'Bank',
    logo: '/assets/7.png',
    contractsValue: '100 M$',
    signedContracts: '76',
    bgColor: 'bg-red-50'
  },
  {
    id: 'BLACKROCK-001',
    name: 'BlackRock',
    type: 'Asset Manager',
    logo: '/assets/8.png',
    contractsValue: '450 k$',
    signedContracts: '2',
    bgColor: 'bg-gray-50'
  },
  {
    id: 'CAIXA-001',
    name: 'CAIXA Bank',
    type: 'Bank',
    logo: '/assets/9.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-blue-50'
  },
  {
    id: 'PIMCO-001',
    name: 'PIMCO',
    type: 'Investment Fund',
    logo: '/assets/10.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-gray-50'
  },
  {
    id: 'UBS-001',
    name: 'UBS',
    type: 'Bank',
    logo: '/assets/11.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-red-50'
  },
  {
    id: 'AXIS-001',
    name: 'Axis Bank',
    type: 'Bank',
    logo: '/assets/12.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-purple-50'
  },
  {
    id: 'BNI-001',
    name: 'Bank Negara Indonesia',
    type: 'Bank',
    logo: '/assets/13.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-orange-50'
  },
  {
    id: 'HCYC-001',
    name: 'HCYC Bank',
    type: 'Bank',
    logo: '/assets/14.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-red-50'
  },
  {
    id: 'ICICI-001',
    name: 'ICICI Bank',
    type: 'Bank',
    logo: '/assets/15.png',
    contractsValue: '100k',
    signedContracts: '24',
    bgColor: 'bg-orange-50'
  }
];

export const mockCustomers: (Customer & {
  company: string;
  phone: string;
  totalContracts: number;
  totalValue: number;
  status: 'active' | 'inactive' | 'pending'
})[] = mockBankPartners.map(bank => ({
  id: bank.id,
  name: bank.name,
  email: `contact@${bank.name.toLowerCase().replace(/\s+/g, '')}.com`,
  company: bank.name,
  phone: '+1 (555) 123-4567',
  totalContracts: parseInt(bank.signedContracts.replace(/[^0-9]/g, '')) || 24,
  totalValue: parseInt(bank.contractsValue.replace(/[^0-9]/g, '')) * (bank.contractsValue.includes('M') ? 1000000 : bank.contractsValue.includes('k') ? 1000 : 1),
  status: 'active' as const,
  joinDate: '2023-08-15',
}));

export const mockContracts: (Contract & {
  customerName: string;
  type: 'collateral' | 'loan' | 'investment';
  riskLevel: 'low' | 'medium' | 'high';
  endDate: string;
})[] = [
    {
      id: 'C_001',
      title: 'HSBC Holdings Bond Contract',
      customerName: 'HSBC Holdings',
      type: 'collateral',
      status: 'pending',
      value: 1050000,
      riskLevel: 'low',
      startDate: '2024-01-10',
      endDate: '2025-01-10',
    },
    {
      id: 'C_002',
      title: 'PIMCO Corporate Bond',
      customerName: 'PIMCO',
      type: 'collateral',
      status: 'active',
      value: 1900000,
      riskLevel: 'medium',
      startDate: '2024-01-12',
      endDate: '2026-01-12',
    },
    {
      id: 'C_003',
      title: 'State Street Whisky Cask',
      customerName: 'State Street',
      type: 'collateral',
      status: 'completed',
      value: 480000,
      riskLevel: 'low',
      startDate: '2024-12-15',
      endDate: '2025-12-15',
    },
    {
      id: 'C_004',
      title: 'Blackrock Gold Contract',
      customerName: 'BlackRock',
      type: 'collateral',
      status: 'pending',
      value: 295000,
      riskLevel: 'medium',
      startDate: '2024-02-10',
      endDate: '2024-02-20',
    },
    {
      id: 'C_005',
      title: 'Bank of London Government Bond',
      customerName: 'The Bank of London',
      type: 'collateral',
      status: 'pending',
      value: 1480000,
      riskLevel: 'low',
      startDate: '2024-03-01',
      endDate: '2025-03-01',
    },
    {
      id: 'C_006',
      title: 'Citi Bank Equity Contract',
      customerName: 'Citi Bank',
      type: 'collateral',
      status: 'pending',
      value: 720000,
      riskLevel: 'medium',
      startDate: '2024-03-15',
      endDate: '2024-09-15',
    },
    {
      id: 'C_007',
      title: 'Bank of America Corporate Bond',
      customerName: 'Bank of America',
      type: 'collateral',
      status: 'pending',
      value: 1150000,
      riskLevel: 'low',
      startDate: '2024-03-20',
      endDate: '2026-03-20',
    },
  ];

export const contractsTableData = [
  {
    id: 'C_001',
    legalEntity: 'HSBC Holdings',
    logo: '/assets/1.png',
    assetType: 'Bond',
    tradeDate: '10/01/2024',
    maturityDate: '10/01/2025',
    nominalValue: '1000000',
    marketValue: '1050000 USD',
    quantity: '2000',
    status: 'Posted by sales',
    statusColor: 'orange'
  },
  {
    id: 'C_002',
    legalEntity: 'PIMCO',
    logo: '/assets/2.png',
    assetType: 'Corporate Bond',
    tradeDate: '12/01/2024',
    maturityDate: '12/01/2026',
    nominalValue: '2000000',
    marketValue: '1900000 EUR',
    quantity: '15',
    status: 'Signed by customer',
    statusColor: 'green'
  },
  {
    id: 'C_003',
    legalEntity: 'State Street',
    logo: '/assets/3.png',
    assetType: 'Whisky Cask',
    tradeDate: '15/01/2024',
    maturityDate: '15/12/2025',
    nominalValue: '500000',
    marketValue: '480000 GBP',
    quantity: '950',
    status: 'Verified',
    statusColor: 'teal'
  },
  {
    id: 'C_004',
    legalEntity: 'Blackrock',
    logo: '/assets/4.png',
    assetType: 'Gold',
    tradeDate: '10/02/2024',
    maturityDate: '20/02/2024',
    nominalValue: '300000',
    marketValue: '295000 USD',
    quantity: '5000',
    status: 'Created by sales',
    statusColor: 'gray'
  },
  {
    id: 'C_005',
    legalEntity: 'The Bank of London',
    logo: '/assets/Frame 405.png',
    assetType: 'Government Bond',
    tradeDate: '01/03/2024',
    maturityDate: '01/03/2025',
    nominalValue: '1500000',
    marketValue: '1480000 EUR',
    quantity: '10',
    status: 'Created by sales',
    statusColor: 'gray'
  },
  {
    id: 'C_006',
    legalEntity: 'Citi Bank',
    logo: '/assets/6.png',
    assetType: 'Equity',
    tradeDate: '15/03/2024',
    maturityDate: '15/09/2024',
    nominalValue: '750000',
    marketValue: '720000 GBP',
    quantity: '25000',
    status: 'Posted by sales',
    statusColor: 'orange'
  },
  {
    id: 'C_007',
    legalEntity: 'Bank of America',
    logo: '/assets/7.png',
    assetType: 'Corporate Bond',
    tradeDate: '20/03/2024',
    maturityDate: '20/03/2026',
    nominalValue: '1200000',
    marketValue: '1150000 USD',
    quantity: '500',
    status: 'Created by sales',
    statusColor: 'gray'
  },
];

export const mockCollateralAssets: CollateralAsset[] = [
  {
    id: '1',
    name: 'Downtown Office Building',
    type: 'Real Estate',
    value: 2500000,
    status: 'available',
  },
  {
    id: '2',
    name: 'Manufacturing Equipment',
    type: 'Equipment',
    value: 450000,
    status: 'locked',
  },
  {
    id: '3',
    name: 'Luxury Vehicle Fleet',
    type: 'Vehicles',
    value: 180000,
    status: 'liquidated',
  },
];

export const mockOperations: Operation[] = [
  {
    id: '1',
    type: 'Contract Creation',
    description: 'New collateral agreement with Acme Corporation',
    status: 'completed',
    createdAt: '2024-01-20T10:30:00Z',
  },
  {
    id: '2',
    type: 'Asset Valuation',
    description: 'Quarterly valuation of downtown office building',
    status: 'in-progress',
    createdAt: '2024-03-01T14:15:00Z',
  },
  {
    id: '3',
    type: 'Contract Validation',
    description: 'Validation process for TechStart Inc. contract',
    status: 'pending',
    createdAt: '2024-03-05T09:00:00Z',
  },
];