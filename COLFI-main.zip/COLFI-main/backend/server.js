const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');
const { Gateway } = require('fabric-network');
const { FileSystemWallet } = require('fabric-network');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// File paths for persistent storage
const USERS_FILE = path.join(__dirname, 'users.json');
const ASSETS_FILE = path.join(__dirname, 'assets.json');

// Helper functions for file operations
function readUsers() {
  try {
    const data = fs.readFileSync(USERS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading users file:', error);
    return [];
  }
}

function writeUsers(users) {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  } catch (error) {
    console.error('Error writing users file:', error);
    throw error;
  }
}

function readAssets() {
  try {
    const data = fs.readFileSync(ASSETS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading assets file:', error);
    return [];
  }
}

function writeAssets(assets) {
  try {
    fs.writeFileSync(ASSETS_FILE, JSON.stringify(assets, null, 2));
  } catch (error) {
    console.error('Error writing assets file:', error);
    throw error;
  }
}

// Middleware
app.use(cors());
app.use(express.json());

// Swagger configuration
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Contract Management API',
      version: '1.0.0',
      description: 'Node.js API for Contract Management Chaincode',
    },
    servers: [
      {
        url: `http://localhost:${PORT}`,
        description: 'Development server',
      },
    ],
  },
  apis: ['./server.js'], // paths to files containing OpenAPI definitions
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Fabric connection configuration
const CONNECTION_PROFILE_PATH = '/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json';
const WALLET_PATH = '/root/fabric-wallet';
const CHANNEL_NAME = 'mychannel';
const CHAINCODE_NAME = 'ContractManagementChaincode';

// Helper function to get gateway
async function getGateway() {
  try {
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Check if admin identity exists in wallet
    const adminExists = await wallet.exists('admin');
    if (!adminExists) {
      console.log('Admin identity not found in wallet. Creating...');
      
      // Create admin identity from certificates
      const certificate = fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/Admin@org1.example.com-cert.pem').toString();
      const privateKey = fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/priv_sk').toString();
      
      const identity = {
        certificate,
        privateKey,
        mspId: 'Org1MSP',
        type: 'X.509',
      };
      
      await wallet.import('admin', identity);
      console.log('Admin identity created in wallet');
    }
    
    // Create gateway
    const gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    return gateway;
  } catch (error) {
    console.error('Error connecting to Fabric network:', error);
    throw error;
  }
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Contract Management API is running' });
});

/**
 * @swagger
 * /api/contracts:
 *   get:
 *     summary: Get all contracts
 *     description: Retrieve all contracts from the blockchain
 *     responses:
 *       200:
 *         description: List of contracts
 *       500:
 *         description: Server error
 */
app.get('/api/contracts', async (req, res) => {
  try {
    const gateway = await getGateway();
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.evaluateTransaction('getAllContracts');
    const contracts = JSON.parse(result.toString());
    
    await gateway.disconnect();
    res.json({ status: 'success', data: contracts });
  } catch (error) {
    console.error('Error getting contracts:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/contracts:
 *   post:
 *     summary: Create a new contract
 *     description: Create a new contract on the blockchain
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               legalName:
 *                 type: string
 *               address:
 *                 type: string
 *               phone:
 *                 type: string
 *               email:
 *                 type: string
 *               assetType:
 *                 type: string
 *               termsAndConditionsOfTransaction:
 *                 type: string
 *               transactionAmount:
 *                 type: number
 *               quantity:
 *                 type: string
 *               obligationDetails:
 *                 type: string
 *               deliveryTimelines:
 *                 type: string
 *               precedentCondition:
 *                 type: string
 *               terminationCondition:
 *                 type: string
 *               terminationEventDefault:
 *                 type: string
 *               terminationNotice:
 *                 type: string
 *               lawGoverning:
 *                 type: string
 *               jurisdictionForDispute:
 *                 type: string
 *               specificRepresentation:
 *                 type: string
 *               representationDisclaimer:
 *                 type: string
 *               collateralDetails:
 *                 type: string
 *               collateralConditions:
 *                 type: string
 *               signingAuthority:
 *                 type: string
 *               requiredSupportingDocuments:
 *                 type: string
 *               conditionsOfRatings:
 *                 type: string
 *               thirdPartyInvolvementDetails:
 *                 type: string
 *               miscellaneousClauses:
 *                 type: string
 *               methodOfExecution:
 *                 type: string
 *               effectiveDateOfContract:
 *                 type: string
 *               maturityDate:
 *                 type: string
 *               contractOwner:
 *                 type: string
 *               nominalValue:
 *                 type: number
 *                 description: Nominal value (mapped to transactionAmount in chaincode)
 *     responses:
 *       200:
 *         description: Contract created successfully
 *       500:
 *         description: Server error
 */
app.post('/api/contracts', async (req, res) => {
  try {
    const gateway = await getGateway();
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    // Transform the request body to match chaincode expectations
    const transformedData = { ...req.body };
    
    // Map nominalValue to transactionAmount for chaincode compatibility
    if (transformedData.nominalValue !== undefined) {
      transformedData.transactionAmount = parseFloat(transformedData.nominalValue);
      delete transformedData.nominalValue;
    }
    
    const contractData = JSON.stringify(transformedData);
    const result = await contract.submitTransaction('contractRegistration', contractData);
    
    await gateway.disconnect();
    res.json({ status: 'success', message: 'Contract created successfully', data: result.toString() });
  } catch (error) {
    console.error('Error creating contract:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/contracts/{contractId}:
 *   get:
 *     summary: Get a specific contract
 *     description: Retrieve a specific contract by ID
 *     parameters:
 *       - in: path
 *         name: contractId
 *         required: true
 *         schema:
 *           type: string
 *         description: Contract ID
 *     responses:
 *       200:
 *         description: Contract details
 *       404:
 *         description: Contract not found
 *       500:
 *         description: Server error
 */
app.get('/api/contracts/:contractId', async (req, res) => {
  try {
    const gateway = await getGateway();
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.evaluateTransaction('getContractById', req.params.contractId);
    const contractData = JSON.parse(result.toString());
    
    await gateway.disconnect();
    res.json({ status: 'success', data: contractData });
  } catch (error) {
    console.error('Error getting contract:', error);
    if (error.message.includes('contract not found')) {
      res.status(404).json({ status: 'error', message: 'Contract not found' });
    } else {
      res.status(500).json({ status: 'error', message: error.message });
    }
  }
});

/**
 * @swagger
 * /api/contracts/{contractId}:
 *   delete:
 *     summary: Delete a specific contract
 *     description: Remove a specific contract by ID
 *     parameters:
 *       - in: path
 *         name: contractId
 *         required: true
 *         schema:
 *           type: string
 *         description: Contract ID
 *     responses:
 *       200:
 *         description: Contract deleted successfully
 *       404:
 *         description: Contract not found
 *       500:
 *         description: Server error
 */
app.delete('/api/contracts/:contractId', async (req, res) => {
  try {
    const gateway = await getGateway();
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.submitTransaction('deleteContractById', req.params.contractId);
    
    await gateway.disconnect();
    res.json({ status: 'success', message: 'Contract deleted successfully', data: result.toString() });
  } catch (error) {
    console.error('Error deleting contract:', error);
    if (error.message.includes('contract not found')) {
      res.status(404).json({ status: 'error', message: 'Contract not found' });
    } else {
      res.status(500).json({ status: 'error', message: error.message });
    }
  }
});

/**
 * @swagger
 * /api/contracts/{contractId}:
 *   put:
 *     summary: Update a specific contract
 *     description: Update an existing contract by ID
 *     parameters:
 *       - in: path
 *         name: contractId
 *         required: true
 *         schema:
 *           type: string
 *         description: Contract ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               legalName:
 *                 type: string
 *               address:
 *                 type: string
 *               phone:
 *                 type: string
 *               email:
 *                 type: string
 *               assetType:
 *                 type: string
 *               termsAndConditionsOfTransaction:
 *                 type: string
 *               nominalValue:
 *                 type: number
 *               quantity:
 *                 type: string
 *               obligationDetails:
 *                 type: string
 *               deliveryTimelines:
 *                 type: string
 *               precedentCondition:
 *                 type: string
 *               terminationCondition:
 *                 type: string
 *               terminationEventDefault:
 *                 type: string
 *               terminationNotice:
 *                 type: string
 *               lawGoverning:
 *                 type: string
 *               jurisdictionForDispute:
 *                 type: string
 *               specificRepresentation:
 *                 type: string
 *               representationDisclaimer:
 *                 type: string
 *               collateralDetails:
 *                 type: string
 *               collateralConditions:
 *                 type: string
 *               signingAuthority:
 *                 type: string
 *               requiredSupportingDocuments:
 *                 type: string
 *               conditionsOfRatings:
 *                 type: string
 *               thirdPartyInvolvementDetails:
 *                 type: string
 *               miscellaneousClauses:
 *                 type: string
 *               methodOfExecution:
 *                 type: string
 *               effectiveDateOfContract:
 *                 type: string
 *               maturityDate:
 *                 type: string
 *               contractOwner:
 *                 type: string
 *     responses:
 *       200:
 *         description: Contract updated successfully
 *       404:
 *         description: Contract not found
 *       500:
 *         description: Server error
 */
app.put('/api/contracts/:contractId', async (req, res) => {
  try {
    const gateway = await getGateway();
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    // Transform the request body to match chaincode expectations
    const transformedData = { ...req.body, id: req.params.contractId };
    
    // Map nominalValue to transactionAmount for chaincode compatibility
    if (transformedData.nominalValue !== undefined) {
      transformedData.transactionAmount = parseFloat(transformedData.nominalValue);
      delete transformedData.nominalValue;
    }
    
    const contractData = JSON.stringify(transformedData);
    const result = await contract.submitTransaction('contractUpdate', contractData);
    
    await gateway.disconnect();
    res.json({ status: 'success', message: 'Contract updated successfully', data: result.toString() });
  } catch (error) {
    console.error('Error updating contract:', error);
    if (error.message.includes('contract not found')) {
      res.status(404).json({ status: 'error', message: 'Contract not found' });
    } else {
      res.status(500).json({ status: 'error', message: error.message });
    }
  }
});

/**
 * @swagger
 * /api/contracts/email/{email}:
 *   get:
 *     summary: Get contracts by email
 *     description: Retrieve all contracts associated with a specific email
 *     parameters:
 *       - in: path
 *         name: email
 *         required: true
 *         schema:
 *           type: string
 *         description: Email address
 *     responses:
 *       200:
 *         description: List of contracts for the email
 *       500:
 *         description: Server error
 */
app.get('/api/contracts/email/:email', async (req, res) => {
  try {
    const gateway = await getGateway();
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.evaluateTransaction('getContractsByEmail', req.params.email);
    const contracts = JSON.parse(result.toString());
    
    await gateway.disconnect();
    res.json({ status: 'success', data: contracts });
  } catch (error) {
    console.error('Error getting contracts by email:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/login:
 *   post:
 *     summary: Login with user credentials
 *     description: Authenticate user with id and name
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               name:
 *                 type: string
 *     responses:
 *       200:
 *         description: Login successful
 *       401:
 *         description: Invalid credentials
 *       500:
 *         description: Server error
 */
app.post('/api/login', (req, res) => {
  try {
    const { id, name } = req.body;
    
    if (!id || !name) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'Both id and name are required' 
      });
    }
    
    // Read users from file
    const users = readUsers();
    
    // Check if user exists
    const user = users.find(u => u.id === id && u.name === name);
    
    if (user) {
      res.json({ 
        status: 'success', 
        message: 'Login successful', 
        user: user 
      });
    } else {
      res.status(401).json({ 
        status: 'error', 
        message: 'Invalid credentials' 
      });
    }
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/users:
 *   get:
 *     summary: Get all users
 *     description: Retrieve all registered users
 *     responses:
 *       200:
 *         description: List of users
 *       500:
 *         description: Server error
 */
app.get('/api/users', (req, res) => {
  try {
    const users = readUsers();
    res.json({ status: 'success', data: users });
  } catch (error) {
    console.error('Error getting users:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/users:
 *   post:
 *     summary: Create a new user
 *     description: Add a new user to the system
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               name:
 *                 type: string
 *               logo:
 *                 type: string
 *                 description: Logo URL or path for the user
 *     responses:
 *       200:
 *         description: User created successfully
 *       400:
 *         description: User already exists or invalid data
 *       500:
 *         description: Server error
 */
app.post('/api/users', (req, res) => {
  try {
    const { id, name, logo } = req.body;
    
    if (!id || !name) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'Both id and name are required' 
      });
    }
    
    // Read current users from file
    const users = readUsers();
    
    // Check if user already exists
    const existingUser = users.find(u => u.id === id);
    if (existingUser) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'User with this ID already exists' 
      });
    }
    
    // Add new user
    const newUser = { id, name, logo: logo || "" };
    users.push(newUser);
    
    // Write updated users back to file
    writeUsers(users);
    
    res.json({ 
      status: 'success', 
      message: 'User created successfully', 
      user: newUser 
    });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/users/{userId}:
 *   delete:
 *     summary: Delete a user
 *     description: Remove a user from the system
 *     parameters:
 *       - in: path
 *         name: userId
 *         required: true
 *         schema:
 *           type: string
 *         description: User ID
 *     responses:
 *       200:
 *         description: User deleted successfully
 *       404:
 *         description: User not found
 *       500:
 *         description: Server error
 */
app.delete('/api/users/:userId', (req, res) => {
  try {
    const { userId } = req.params;
    
    // Read current users from file
    const users = readUsers();
    
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
      return res.status(404).json({ 
        status: 'error', 
        message: 'User not found' 
      });
    }
    
    const deletedUser = users.splice(userIndex, 1)[0];
    
    // Write updated users back to file
    writeUsers(users);
    
    res.json({ 
      status: 'success', 
      message: 'User deleted successfully', 
      user: deletedUser 
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/assets:
 *   get:
 *     summary: Get all assets
 *     description: Retrieve all financial assets
 *     responses:
 *       200:
 *         description: List of assets
 *       500:
 *         description: Server error
 */
app.get('/api/assets', (req, res) => {
  try {
    const assets = readAssets();
    res.json({ status: 'success', data: assets });
  } catch (error) {
    console.error('Error getting assets:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/assets:
 *   post:
 *     summary: Create a new asset
 *     description: Add a new financial asset to the system
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               id:
 *                 type: string
 *               type:
 *                 type: string
 *                 enum: [Equity, Gov Bond, FX, Commodity, Alternative]
 *               name:
 *                 type: string
 *               value:
 *                 type: string
 *               currency:
 *                 type: string
 *                 enum: [USD, EUR, GBP, JPY]
 *     responses:
 *       200:
 *         description: Asset created successfully
 *       400:
 *         description: Asset already exists or invalid data
 *       500:
 *         description: Server error
 */
app.post('/api/assets', (req, res) => {
  try {
    const { id, type, name, value, currency } = req.body;
    
    if (!id || !type || !name || !currency) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'id, type, name, and currency are required' 
      });
    }
    
    // Validate asset type
    const validTypes = ['Equity', 'Gov Bond', 'FX', 'Commodity', 'Alternative'];
    if (!validTypes.includes(type)) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'Invalid asset type. Must be one of: ' + validTypes.join(', ') 
      });
    }
    
    // Validate currency
    const validCurrencies = ['USD', 'EUR', 'GBP', 'JPY'];
    if (!validCurrencies.includes(currency)) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'Invalid currency. Must be one of: ' + validCurrencies.join(', ') 
      });
    }
    
    // Read current assets from file
    const assets = readAssets();
    
    // Check if asset already exists
    const existingAsset = assets.find(a => a.id === id);
    if (existingAsset) {
      return res.status(400).json({ 
        status: 'error', 
        message: 'Asset with this ID already exists' 
      });
    }
    
    // Add new asset with default value if not provided
    const newAsset = { 
      id, 
      type, 
      name, 
      value: value || "0", 
      currency 
    };
    assets.push(newAsset);
    
    // Write updated assets back to file
    writeAssets(assets);
    
    res.json({ 
      status: 'success', 
      message: 'Asset created successfully', 
      asset: newAsset 
    });
  } catch (error) {
    console.error('Error creating asset:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/assets/{assetId}:
 *   delete:
 *     summary: Delete an asset
 *     description: Remove an asset from the system
 *     parameters:
 *       - in: path
 *         name: assetId
 *         required: true
 *         schema:
 *           type: string
 *         description: Asset ID
 *     responses:
 *       200:
 *         description: Asset deleted successfully
 *       404:
 *         description: Asset not found
 *       500:
 *         description: Server error
 */
app.delete('/api/assets/:assetId', (req, res) => {
  try {
    const { assetId } = req.params;
    
    // Read current assets from file
    const assets = readAssets();
    
    const assetIndex = assets.findIndex(a => a.id === assetId);
    
    if (assetIndex === -1) {
      return res.status(404).json({ 
        status: 'error', 
        message: 'Asset not found' 
      });
    }
    
    const deletedAsset = assets.splice(assetIndex, 1)[0];
    
    // Write updated assets back to file
    writeAssets(assets);
    
    res.json({ 
      status: 'success', 
      message: 'Asset deleted successfully', 
      asset: deletedAsset 
    });
  } catch (error) {
    console.error('Error deleting asset:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

/**
 * @swagger
 * /api/assets/{assetId}:
 *   put:
 *     summary: Update an asset
 *     description: Update an existing asset's information
 *     parameters:
 *       - in: path
 *         name: assetId
 *         required: true
 *         schema:
 *           type: string
 *         description: Asset ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [Equity, Gov Bond, FX, Commodity, Alternative]
 *               name:
 *                 type: string
 *               value:
 *                 type: string
 *               currency:
 *                 type: string
 *                 enum: [USD, EUR, GBP, JPY]
 *     responses:
 *       200:
 *         description: Asset updated successfully
 *       404:
 *         description: Asset not found
 *       400:
 *         description: Invalid data
 *       500:
 *         description: Server error
 */
app.put('/api/assets/:assetId', (req, res) => {
  try {
    const { assetId } = req.params;
    const { type, name, value, currency } = req.body;
    
    // Read current assets from file
    const assets = readAssets();
    
    const assetIndex = assets.findIndex(a => a.id === assetId);
    
    if (assetIndex === -1) {
      return res.status(404).json({ 
        status: 'error', 
        message: 'Asset not found' 
      });
    }
    
    // Validate asset type if provided
    if (type) {
      const validTypes = ['Equity', 'Gov Bond', 'FX', 'Commodity', 'Alternative'];
      if (!validTypes.includes(type)) {
        return res.status(400).json({ 
          status: 'error', 
          message: 'Invalid asset type. Must be one of: ' + validTypes.join(', ') 
        });
      }
    }
    
    // Validate currency if provided
    if (currency) {
      const validCurrencies = ['USD', 'EUR', 'GBP', 'JPY'];
      if (!validCurrencies.includes(currency)) {
        return res.status(400).json({ 
          status: 'error', 
          message: 'Invalid currency. Must be one of: ' + validCurrencies.join(', ') 
        });
      }
    }
    
    // Update asset
    const updatedAsset = { ...assets[assetIndex] };
    if (type) updatedAsset.type = type;
    if (name) updatedAsset.name = name;
    if (value !== undefined) updatedAsset.value = value;
    if (currency) updatedAsset.currency = currency;
    
    assets[assetIndex] = updatedAsset;
    
    // Write updated assets back to file
    writeAssets(assets);
    
    res.json({ 
      status: 'success', 
      message: 'Asset updated successfully', 
      asset: updatedAsset 
    });
  } catch (error) {
    console.error('Error updating asset:', error);
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Contract Management API server running on http://localhost:${PORT}`);
  console.log(`Swagger UI available at http://localhost:${PORT}/api-docs`);
});

module.exports = app;
