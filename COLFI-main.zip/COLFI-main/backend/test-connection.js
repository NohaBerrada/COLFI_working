const { Gateway } = require('fabric-network');
const { FileSystemWallet } = require('fabric-network');
const fs = require('fs');

async function testConnection() {
  try {
    console.log('Testing Fabric connection...');
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json', 'utf8'));
    console.log('Connection profile loaded');
    
    // Create wallet
    const wallet = new FileSystemWallet('/root/fabric-wallet');
    console.log('Wallet created');
    
    // Check if admin identity exists
    const adminExists = await wallet.exists('admin');
    console.log('Admin exists:', adminExists);
    
    if (!adminExists) {
      console.log('Creating admin identity...');
      const certificate = fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/Admin@org1.example.com-cert.pem').toString();
      const privateKey = fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/priv_sk').toString();
      
      const identity = {
        certificate,
        privateKey,
        mspId: 'Org1MSP',
        type: 'X.509',
      };
      
      await wallet.import('admin', identity);
      console.log('Admin identity created');
    }
    
    // Create gateway with discovery disabled
    const gateway = new Gateway();
    console.log('Connecting to gateway...');
    
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: false, asLocalhost: true }
    });
    
    console.log('Gateway connected successfully!');
    
    // Get network
    const network = await gateway.getNetwork('mychannel');
    console.log('Network obtained');
    
    // Get contract
    const contract = network.getContract('ContractManagementChaincode');
    console.log('Contract obtained');
    
    // Test query
    const result = await contract.evaluateTransaction('getAllContracts');
    console.log('Query result:', result.toString());
    
    await gateway.disconnect();
    console.log('Test completed successfully!');
    
  } catch (error) {
    console.error('Test failed:', error.message);
    console.error('Full error:', error);
  }
}

testConnection();
