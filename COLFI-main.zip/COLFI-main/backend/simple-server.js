const express = require('express');
const cors = require('cors');
const { Gateway } = require('fabric-network');
const { FileSystemWallet } = require('fabric-network');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Configuration
const CONNECTION_PROFILE_PATH = '/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json';
const WALLET_PATH = '/root/fabric-wallet';
const CHANNEL_NAME = 'mychannel';
const CHAINCODE_NAME = 'ContractManagementChaincode';

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'Contract Management API is running' });
});

// Get all contracts
app.get('/api/contracts', async (req, res) => {
  let gateway;
  try {
    console.log('Connecting to Fabric network...');
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Create gateway
    gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    console.log('Connected to Fabric network');
    
    // Get network and contract
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    console.log('Querying contracts...');
    const result = await contract.evaluateTransaction('getAllContracts');
    const contracts = JSON.parse(result.toString());
    
    console.log('Query successful');
    res.json({ status: 'success', data: contracts });
    
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ status: 'error', message: error.message });
  } finally {
    if (gateway) {
      await gateway.disconnect();
    }
  }
});

// Create contract
app.post('/api/contracts', async (req, res) => {
  let gateway;
  try {
    console.log('Creating contract...');
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Create gateway
    gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    // Get network and contract
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const contractData = JSON.stringify(req.body);
    const result = await contract.submitTransaction('contractRegistration', contractData);
    
    res.json({ status: 'success', message: 'Contract created successfully', data: result.toString() });
    
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ status: 'error', message: error.message });
  } finally {
    if (gateway) {
      await gateway.disconnect();
    }
  }
});

// Get contract by ID
app.get('/api/contracts/:contractId', async (req, res) => {
  let gateway;
  try {
    console.log(`Getting contract ${req.params.contractId}...`);
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Create gateway
    gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    // Get network and contract
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.evaluateTransaction('getContractById', req.params.contractId);
    const contractData = JSON.parse(result.toString());
    
    res.json({ status: 'success', data: contractData });
    
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ status: 'error', message: error.message });
  } finally {
    if (gateway) {
      await gateway.disconnect();
    }
  }
});

// Update contract
app.put('/api/contracts/:contractId', async (req, res) => {
  let gateway;
  try {
    console.log(`Updating contract ${req.params.contractId}...`);
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Create gateway
    gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    // Get network and contract
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    // Add the contract ID to the request body for update
    const contractData = { ...req.body, id: req.params.contractId };
    const result = await contract.submitTransaction('contractUpdate', JSON.stringify(contractData));
    
    res.json({ status: 'success', message: 'Contract updated successfully', data: result.toString() });
    
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ status: 'error', message: error.message });
  } finally {
    if (gateway) {
      await gateway.disconnect();
    }
  }
});

// Delete contract
app.delete('/api/contracts/:contractId', async (req, res) => {
  let gateway;
  try {
    console.log(`Deleting contract ${req.params.contractId}...`);
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Create gateway
    gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    // Get network and contract
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.submitTransaction('deleteContractById', req.params.contractId);
    
    res.json({ status: 'success', message: 'Contract deleted successfully', data: result.toString() });
    
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ status: 'error', message: error.message });
  } finally {
    if (gateway) {
      await gateway.disconnect();
    }
  }
});

// Get contracts by email
app.get('/api/contracts/email/:email', async (req, res) => {
  let gateway;
  try {
    console.log(`Getting contracts for email ${req.params.email}...`);
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync(CONNECTION_PROFILE_PATH, 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet(WALLET_PATH);
    
    // Create gateway
    gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    // Get network and contract
    const network = await gateway.getNetwork(CHANNEL_NAME);
    const contract = network.getContract(CHAINCODE_NAME);
    
    const result = await contract.evaluateTransaction('getContractsByEmail', req.params.email);
    const contracts = JSON.parse(result.toString());
    
    res.json({ status: 'success', data: contracts });
    
  } catch (error) {
    console.error('Error:', error.message);
    res.status(500).json({ status: 'error', message: error.message });
  } finally {
    if (gateway) {
      await gateway.disconnect();
    }
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Contract Management API server running on http://localhost:${PORT}`);
  console.log(`\nAvailable endpoints:`);
  console.log(`  GET    http://localhost:${PORT}/health                    - Health check`);
  console.log(`  GET    http://localhost:${PORT}/api/contracts             - Get all contracts`);
  console.log(`  POST   http://localhost:${PORT}/api/contracts             - Create contract`);
  console.log(`  GET    http://localhost:${PORT}/api/contracts/:id         - Get contract by ID`);
  console.log(`  PUT    http://localhost:${PORT}/api/contracts/:id         - Update contract`);
  console.log(`  DELETE http://localhost:${PORT}/api/contracts/:id         - Delete contract`);
  console.log(`  GET    http://localhost:${PORT}/api/contracts/email/:email - Get contracts by email`);
});
