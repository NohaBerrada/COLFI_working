const { Gateway } = require('fabric-network');
const { FileSystemWallet } = require('fabric-network');
const fs = require('fs');

async function enrollAdmin() {
  try {
    console.log('Starting admin enrollment...');
    
    // Load connection profile
    const connectionProfile = JSON.parse(fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json', 'utf8'));
    
    // Create wallet
    const wallet = new FileSystemWallet('/root/fabric-wallet');
    
    // Create admin identity from certificates
    console.log('Creating admin identity...');
    const certificate = fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/signcerts/Admin@org1.example.com-cert.pem').toString();
    const privateKey = fs.readFileSync('/root/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp/keystore/priv_sk').toString();
    
    const identity = {
      certificate,
      privateKey,
      mspId: 'Org1MSP',
      type: 'X.509',
    };
    
    await wallet.import('admin', identity);
    console.log('Admin identity created successfully!');
    
    // Test connection
    console.log('Testing connection...');
    const gateway = new Gateway();
    await gateway.connect(connectionProfile, {
      wallet,
      identity: 'admin',
      discovery: { enabled: true, asLocalhost: true }
    });
    
    console.log('Connection successful!');
    await gateway.disconnect();
    
  } catch (error) {
    console.error('Error:', error.message);
  }
}

enrollAdmin();


